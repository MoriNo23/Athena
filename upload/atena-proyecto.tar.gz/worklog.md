# Worklog

---
Task ID: 1
Agent: Super Z (main agent)
Task: Construir "Riel" — app web desktop-first que gamifica terminar libros digitales mediante un riel/barra de progreso configurable, con subida de PDF, zoom cómodo y filtros anti-fatiga visual.

Work Log:
- Inicializado entorno fullstack (init-fullstack.sh) y leída convención del scaffold (Next.js 16, Prisma+SQLite, shadcn/ui, solo ruta `/`).
- Instaladas dependencias: pdfjs-dist@6, canvas-confetti (+types). Worker copiado a `public/pdf.worker.min.mjs`.
- Prisma: modelos `Book` y `ReadingSession` (racha, páginas/minutos por día); `bun run db:push`.
- Tema "biblioteca nocturna": globals.css con paleta cálida oscura, estilos del riel (glow, destello de hito, cursor pulsante), scrollbar fina; layout.tsx con fuentes Geist + Fraunces, lang es, dark por defecto.
- APIs: `POST/GET /api/books` (subida multipart con portada generada client-side), `PATCH/DELETE /api/books/[id]` (progreso + sesiones, borrado con archivos).
- Store zustand persist (`riel-settings-v1`, v3 con migrate): posición/segmentos/tema/etiquetas/celebración del riel, filtros (brillo, contraste, sepia, saturación, inversión, tinte cálido), meta diaria.
- Componentes: `RailBar` (riel segmentado horizontal/vertical con hitos, cursor y destello por remount con key), `LibraryView` (drag&drop, diálogo de subida con portada, tarjetas con mini-riel + ETA, franja de hábitos), `PdfViewport` (render canvas con DPR, zoom Ctrl+rueda, ResizeObserver), `ReaderView` (navegación, guardado debounced de páginas/minutos, cronómetro de sesión, celebración de hitos con confetti y toasts, atajos de teclado), `ConfigPanel` (Sheet con 3 secciones).
- page.tsx: shell único que alterna Biblioteca ↔ Lector (restricción de ruta única `/`).
- Lint: 0 errores/0 warnings (excluidos public/ del lint; eliminado setState-en-effect de RailBar y ReaderView usando patrón ref + updater puro).
- Verificación end-to-end con Agent Browser: subida real de PDF de prueba de 24 páginas (portada generada), lectura con teclado, hitos con confetti ("Hito 2/4 de 10"), racha y meta actualizadas (25/20), ETA "terminas el 15 de octubre", panel de configuración aplicando posición bottom/tema esmeralda/etiquetas, y modo noche con inversión. Bugs corregidos durante la verificación: `doc.destroy()` inexistente en pdfjs v6 (→ loadingTask.destroy()), filtro `invert` no aplicado (→ campo invert + filterCss + migrate v3), toast dentro de updater de estado (→ goToPage puro con pageNumRef).
- Consola y dev.log limpios al cierre; archivos de subida persistidos en `public/uploads/`.

Stage Summary:
- App "Riel" completa y verificada en navegador: biblioteca con upload real de PDFs, lector con zoom/filtros/hitos, riel configurable en 4 posiciones, gamificación (racha, meta diaria, hitos celebrados, ETA de fin de libro).
- Decisiones clave: ruta única con vistas cliente (limitación del entorno), settings en localStorage con migraciones, progreso/sesiones en SQLite vía Prisma.
- Pendiente sugerido al usuario: EPUB/TXT, sprints pomodoro, estimación más fina, notas/resaltados (ver análisis en la respuesta).

---
Task ID: 2
Agent: Super Z (main agent)
Task: Corregir bugs reportados: hitos individuales por libro, PDF de paper en blanco, barra sin feedback de color (estilo Duolingo), falta pantalla completa + sprint de testing E2E.

Work Log:
- Diagnóstico del PDF en blanco con scripts Node (scripts/diagnose-*.mjs): el paper escaneado (DOSSIER, 84 pág) usa imágenes DCTDecode con perfiles ICC; pdf.js v6 decodifica ICC vía WASM (qcms) y la app no tenía cmaps/standard_fonts/wasm desplegados → operator list vacía → página en blanco. Verificado que en Node renderiza OK con los assets presentes.
- Fix PDF: copiados `cmaps`, `standard_fonts`, `wasm` de pdfjs-dist a `public/pdfjs/` (3.5MB, excluido quickjs); `getDocument` ahora recibe `cMapUrl/cMapPacked/standardFontDataUrl/wasmUrl` (const PDFJS_ASSETS en pdf-client.ts, aplicado a PdfViewport y probePdf). Red de seguridad anti-blank: muestreo del canvas a 48x64 tras render; si es uniforme, reintenta una vez.
- Hitos individuales: Prisma `Book.milestones Int?` (db:push), PATCH /api/books/[id] acepta `milestones` (null=heredar global, clamp 2..40), BookDTO con milestones, ConfigPanel con sección "Hitos de este libro" (switch + slider, requiere props book/onPatchBook), ReaderView.patchBook con actualización optimista + toast + confirmación de BD, RailBar/Library cards usan `book.milestones ?? rail.segments`. Slider global renombrado a "Tramos globales" (default para libros nuevos).
- Barra Duolingo: nuevo RailTheme "dynamic" (default + migración settings v3→v4), rampa de hue ámbar(55)→verde(150) según avance (dynamicSegmentColor/dynamicCursorColor en types.ts), shine recorriendo el tramo activo, pop elástico al completar tramo (key remount por estado done), cursor/glow/etiquetas siguen la rampa. CSS: rail-pop, rail-pop-v, rail-shine, rail-shine-v; pop solo en riel principal (.rail-main).
- Pantalla completa: botón en header del lector (Maximize/Minimize reactivo a fullscreenchange), atajo "M", title/aria con estado.
- Bugs extra corregidos durante testing: (a) riel vertical colapsado a 0px de alto (faltaba h-full en el root para left/right) — era invisible en posición izquierda/derecha; (b) teclas de flecha navegaban páginas mientras se usaban sliders del panel de ajustes (guard por role=dialog y role=slider en keydown); (c) `loaded.destroy()` inexistente en pdfjs v6 → task.destroy() (detectado por tsc).
- Testing E2E con Agent Browser: DOSSIER escaneado renderiza (antes blanco), BrainFM y libro nuevo con fuentes no incrustadas OK; hitos por libro (DOSSIER=6, BrainFM=10) persisten tras reload e independientes; rampa de color verificada por DOM (hue 64→140) y visualmente (screenshots); hito 5/10 y 9/10 celebrados con toast+flash+confetti; fullscreen true/false con cambio de icono; subida end-to-end de PDF nuevo de 30 pág + borrado; riel horizontal bottom con etiquetas; tsc y eslint limpios; consola sin errores.

Stage Summary:
- Los 4 bugs reportados corregidos y verificados en navegador; 3 bugs adicionales descubiertos y corregidos en el sprint de testing.
- Decisiones: hitos por libro opcionales (null = global) para no romper el flujo existente; tema dinámico como default tras migración v4; recursos pdf.js autohospedados en /public/pdfjs.
- Pendiente sugerido: aplicar filtros de lectura también a la portada del lector en modo noche global, EPUB/TXT, sprints pomodoro.

---
Task ID: 3
Agent: Super Z (main agent)
Task: Nuevas features — diccionario por selección de palabra (ES/EN con API gratuita) + modos de lectura con presets (Técnico, Literatura, Custom) con subfeatures activables/desactivables.

Work Log:
- Schema: Book.extras Json?, companionPath, companionPages (db:push). PATCH /api/books/[id] acepta extras (merge completo, límite 512KB).
- API /api/dictionary: proxy sin API key — RAE (rae-api.com) para español con fallback dictionaryapi.dev/es; dictionaryapi.dev + Datamuse (WordNet) para inglés. Modo auto consulta ambos idiomas en paralelo y prioriza ES. Caché en memoria (300 entradas). Normalización: entradas por categoría, ejemplos, sinónimos, origen, audio.
- API /api/books/[id]/companion POST/DELETE: sube PDF compañero para lectura dual.
- PdfViewport: capa de texto seleccionable (pdfjs v6 TextLayer + CSS .textLayer adaptado de pdf_viewer.css, --total-scale-factor) para habilitar el diccionario; nuevo prop onDoc expone PDFDocumentProxy.
- DictionaryPopover: mouseup sobre .textLayer → popover con definiciones, badge de idioma, switch ES/EN, pronunciación (audio), guardar en vocabulario; cierra con Escape/scroll/cambio de página (key remount). VocabularioSheet con lista global (palabra, idioma, libro, página, fecha).
- Settings v5 (migración v4→v5): modes {preset, toggles, customSaved, pauseMinutes} + vocabulary[]. Presets canónicos en types.ts (MODE_PRESETS + MODE_TOGGLE_META con corriente T/L/C). Memoria por libro en localStorage (mode-memory.ts).
- ModeDock: selector de presets, popover de opciones con 12 switches + "Guardar como mi preset Custom", pestañas con paneles activos.
- Paneles técnico: ThreePassPanel (guía Keshav con checklists y notas), NotationPanel (símbolos con salto de página), CodeRunnerPanel (sandbox iframe allow-scripts, console capturada por postMessage, código guardado por libro), ResultsPanel (tabla método/dataset/métrica/valor/pág), ReproPanel (8 ítems cíclicos pendiente→ok→na + progreso + notas).
- Paneles literatura: XrayPanel (fichas con desbloqueo por página, notas veladas con blur + peek), PausesPanel (objetivo de sesión, progreso, recap persistente), SkeletonPanel (predicción vs conclusión real con comparación al terminar), LockedNotesPanel (notas futuras veladas), DualPanel (subida de compañero + info de sincronización).
- OutlinePanel: getOutline → resolución de dests (string→getDestination→getPageIndex), árbol navegable; verificado con PDF con índice real via Node.
- DualViewport: segundo visor fit-width con página equivalente por progreso relativo (round((p-1)/total*compTotal)+1).
- ReaderView: dock integrado, banner sutil de pausa armada, diálogo en corte natural (page-turn con sesión cumplida) con recap + pausesTaken, pausa armada desde el cronómetro (sin setState-en-effect), guardado extras por libro, botón Modos + Vocabulario con badge.
- Testing E2E (agent-browser): selección de palabra en capa de texto → definición RAE/WordNet; guardar vocabulario (badge 1); 12 toggles; preset Literatura→tabs correctas; fichas con spoiler-lock al retroceder a pág. 3 (blur + reveal); notas candado pág. 15 veladas; predicción guardada; runner con salida; resultados (BERT-base/SQuAD/F1/80.9); repro 2/8; custom save + restore tras reload; extras persistidos en BD; dual sync 3/24→2/12 y 24/24→12/12; pausa: banner tras objetivo → diálogo al girar página → recap en BD con pausesTaken=1; regresión hitos (Hito 2/6 + confetti en DOSSIER); PDF escaneado sigue renderizando; console/dev.log limpios.
- Bugs corregidos durante testing: (a) sandbox enviaba args como string y el handler crasheaba (TypeError join) → args normalizado a array + hardening en ambos lados; (b) Prisma Client stale en el server hacía fallar PATCH extras → reinicio del dev server tras db:push; (c) dictionaryapi.dev inestable → respaldo Datamuse para inglés; (d) auto-detección priorizaba EN en palabras ES sin tilde → auto paralelo con prioridad ES.
- Nota: fullscreen verificado en Task 2; en esta sesión el navegador headless denegó el permiso (limitación del entorno, código intacto).

Stage Summary:
- Riel ahora tiene: diccionario integrado (seleccionar palabra → definición RAE/Wiktionary/WordNet, vocabulario global) y dos corrientes de lectura capturadas como presets con 12 subfeatures individuales (5 técnico + 5 literatura + 2 comunes) + Custom guardado, con datos por libro persistidos en BD (extras JSON) y memoria de modo por libro.
- Decisiones: extras como JSON en Book (una sola columna, merge client-side); diccionario via proxy server-side (evita CORS y permite caché); pausa por cronómetro del reader (sin timers intrusivos); lectura dual sincronizada por progreso relativo.
- Pendiente sugerido: EPUB/TXT (el diccionario y modos aplican igual), club de lectura real con spoiler-lock multiusuario, importar símbolos desde fuente LaTeX, X-Ray automático vía NER.

---
Task ID: 4
Agent: Super Z (main agent)
Task: Sprint de testing E2E sobre el libro nuevo añadido por el usuario («el mundo de sofia pdf compress», 657 pág, escaneado y cifrado) + correcciones/mejoras halladas + restauración del estado del usuario.

Work Log:
- Diagnóstico Node del PDF nuevo: 657 páginas, imágenes DCTDecode por página (0 caracteres de texto en muestra), cifrado estándar (empty user password), 30 MB, linealizado — el caso más exigente para render, navegación y diccionario.
- E2E (agent-browser, viewport 1600x900): biblioteca con portada/mini-riel/ETA correctos; render nítido de páginas escaneadas (pág. 18, 300, 657); navegación ←/→, salto por input (1, 82, 165, 300, 657), canvas 1120x1812 constante; zoom botones (89%→80%) y «Ajustar al ancho»; heap JS estable en 34 MB tras 5 navegaciones consecutivas; filtros aplicándose en vivo al escaneo; pantalla completa ON/OFF con icono reactivo.
- Hitos por libro: switch + slider per-libro (8 tramos → límites pág. 82/164/246/328/410/493/575/657) persiste en BD y el riel reacciona en vivo; celebración «Hito 2 de 8 alcanzado» con confetti + toast + flash tras recargar en pág. 83 y saltar a 165; «¡Libro terminado!» disparado en 657; maxHitRef confirmado como marca-alta de sesión (no re-celebra relecturas, igual que Duolingo).
- Fichas X-Ray: creada ficha «Sofía Amundsen» anclada a pág. 300; spoiler-lock reactivo (velada con blur y «se desbloqueará al llegar a pág. 300» en págs. < 300, desbloqueada en ≥ 300); paneles Pausas, Dual, Esquema (estado vacío correcto: «Este PDF no trae índice interno») verificados; memoria de modo por libro escribe/lee en localStorage.
- Diccionario: /api/dictionary responde ES (RAE: «casa» con etimología) y EN (WordNet/Wiktionary: «epistemology»); flujo completo en BrainFM con selección real de mouse → popover con fonética /əs/, 4 acepciones, ejemplos, audio, switch ES/EN y Guardar.
- Mejora implementada (DictionaryPopover): aviso «Libro escaneado detectado» una sola vez por libro (localStorage riel-hint-scan-<bookId>) cuando el usuario intenta seleccionar (drag > 6px) sobre una página sin capa de texto; verificado que dispara en el escaneo y NO dispara en libros con texto (258 spans) ni con clics simples.
- Falsas alarmas investigadas y descartadas: etiqueta 46% era progreso bajo el riel (no zoom); slider global vs por-libro (click en ref equivocada); selector incorrecto de toasts ([data-sonner-toast] vs ol.fixed de radix) que ocultaba toasts existentes.
- Restauración del estado del usuario tras el testing: Book sofia → currentPage=18, milestones=null, extras=null; eliminadas 11 ReadingSessions de prueba (sofia >= 14:23 y brainfm >= 14:36 UTC); localStorage → tramos globales 10, filtro Papel (103/96/18/95/22/0), preset global técnico, memoria por libro limpia, hint-key limpia (el usuario verá el aviso una vez); verificado en UI: 185/20 pág, pág. 18 de 657 · 3%, riel 10 tramos, preset Técnico marcado, filtro sepia(0.18).
- Calidad: tsc 0 errores en src/, eslint 0 problemas, consola y dev.log limpios durante toda la sesión.

Stage Summary:
- El libro nuevo (escaneado + cifrado + 657 pág) funciona de punta a punta: render, navegación, zoom, filtros, hitos por libro con celebración, fichas con spoiler-lock, degradación elegante del diccionario (con aviso nuevo) y rendimiento con 34 MB de heap.
- Única mejora de código: aviso una-vez-por-libro para libros escaneados en DictionaryPopover.
- Decisión: maxHitRef como marca-alta por sesión es diseño intencional; el aviso de escaneo usa localStorage por libro para no repetirse.
- Estado del usuario restaurado íntegro tras el sprint (BD + localStorage), verificado por UI y por Prisma.

---
Task ID: 5
Agent: Super Z (main agent)
Task: OCR bajo demanda para páginas escaneadas (solo-imagen) — decisión del usuario: "agregalo" tras comparar opciones (Tesseract.js CDN lazy elegido, 0 KB en bundle hasta que se usa).

Work Log:
- Nuevo módulo src/lib/ocr.ts: carga perezosa de Tesseract.js v6 desde jsdelivr (script injection una vez, timeout 45 s, re-intentable), datos de idioma tessdata_fast (spa/eng, ~1-2 MB vs 10-15 MB estándar), worker por idioma reutilizado en sesión, progreso mapeado por fases (core 0.05-0.34, idioma 0.38-0.6, recognizing 0.66-1), cancelOcr() destruye worker en vuelo (los datos de idioma quedan en IndexedDB de Tesseract).
- Caché propia en IndexedDB (`riel-ocr` / store `pages`): clave `${filePath}#${page}#${lang}`, TTL 6 meses, tolerante a fallos (sin caché → OCR funciona igual).
- runOcrPage(): render offscreen a ~1600 px de ancho (techo 4.2 Mpx), extracción de words con bbox+conf (conf<30 descartada), limpieza de puntuación en bordes (regex \p{L}/\p{N}, conserva acentos), texto completo des-hifenizado, avgConf.
- PdfViewport: detección de página sin texto (textContent de .textLayer < 8 chars tras render → pageHasText=false), botón flotante «OCR» (solo escaneos), píldora de progreso con fase+%, capa .ocrLayer con spans posicionados en % (escala con zoom, fontSize vía em relativo a root W/100 px), toolbar (badge de confianza, pills spa/eng, copiar, texto limpio, ocultar), panel de texto limpio con contador de palabras.
- Estado etiquetado por (page, filePath, lang): resultados viejos se invalidan solos al navegar sin setState-en-effect; guards por refs (ocrWorkingRef, ocrRunRef) para carreras; caché auto-aplicada al entrar en página (instantáneo); cambio de idioma re-OCR automático (autoOcrRef); ocultar capa → vuelve el botón; idioma recordado en localStorage `riel-ocr-lang` (lazy initializer, default spa).
- DictionaryPopover integrado: selecciones en .ocrLayer abren el diccionario (selectores .textLayer, .ocrLayer); aviso de libro escaneado ahora redirige al botón OCR.
- CSS .ocrLayer en globals.css (texto transparente, hover sutil, ::selection ámbar).
- Lint (React compiler rules): refactor completo a estado derivado etiquetado + lazy useState para localStorage; fallback de copia (execCommand) para entornos sin Clipboard API.
- Testing E2E (agent-browser, 1600x900): PDF escaneado sintético generado con PIL (3 páginas solo-JPEG, 0 operadores de texto, 383 KB) y subido vía API (id b4819ad5a96944c69). Verificado: botón OCR aparece solo en escaneo; progreso en vivo («Descargando motor OCR…2%»); pág.1 → 132 palabras 96% conf; panel de texto limpio con saltos de línea correctos; selección de «imprenta» sobre el overlay → popover RAE con 4 acepciones + sinónimos; caché: vuelta a pág.1 instantánea (<1 s, sin botón ni progreso) y tras HMR/reload; pág.2 (inglés) con modelo spa → 82 palabras 95%; switch spa→eng re-OCR automático (conf 96→93, pill activa, localStorage); copiar con feedback «Texto copiado»; pág.3 instantánea (motor cacheado); libro digital «El Riel de la Lectura» → SIN botón OCR y capa nativa presente; consola/dev.log limpios; tsc+eslint 0 problemas.
- Estado restaurado: localStorage riel-ocr-lang=spa; libro de prueba dejado en la biblioteca a propósito (playground de OCR para el usuario).

Stage Summary:
- Riel ahora reconoce texto de páginas escaneadas bajo demanda: peso real 0 KB para libros digitales, ~4-6 MB una sola vez (cacheado) solo al activar OCR en un escaneo. El texto OCR es seleccionable → diccionario EN/ES funciona también en libros escaneados; cada página se procesa una única vez por idioma.
- Decisiones: Tesseract.js por CDN (no bundle) con tessdata_fast; estado etiquetado en vez de resets; caché IndexedDB por filePath+página+idioma; cancelación al cambiar de página.
- Pendiente sugerido: OCR en lote (rango de páginas), auto-OCR opcional al navegar en libros 100% escaneados, exportar texto del libro completo.

---
Task ID: 6
Agent: Super Z (main agent)
Task: SDD del usuario — rediseño del riel, sincronización de progreso ("lo leí en otro lado"), overlay dock de páginas (peek carrusel), zooms predefinidos y modo inmersión (UI auto-oculta).

Work Log:
- RailBar v2: look gel (relleno con brillo superior + borde inferior 3D), puntos de hito sobre las etiquetas con pop al alcanzarlos, cursor perilla con anillo oscuro + glow dinámico, icono Milestone al final del riel (brilla al terminar el libro). Fix: conflicto w-full vs w-2.5 en riel vertical (segmentos de 63px → 10px).
- Sincronización de progreso: botón MapPin en la navegación → popover «¿Ya lo leías en otro lado?» → salto silencioso (no cuenta páginas, no celebra hitos retroactivos, maxHitRef ajustado, pending.pages=0). Bug de fondo descubierto y corregido: el flush periódico del cronómetro reenviaba currentPage aunque no cambiara, así cualquier cliente inactivo (u otro tab) REVERTÍA el progreso guardado por otro lado (la sync se perdía). Fix de higiene: lastFlushedPage ref → currentPage solo se envía cuando cambió (flushSave + unmount). Verificado: sync a 150/160 persiste tras salir y re-entrar al libro.
- PagePeek (nuevo componente): zona caliente fija de 20px en el borde inferior (hint al hover) → pointerdown + arrastre >44px hacia arriba abre el carrusel; miniaturas renderizadas bajo demanda con pdf.js (190px, JPEG 0.72, cache Map + LRU 48, cola secuencial con polling del sel, cache invalidado por doc); arrastre horizontal = hojear (~64px/página), teclado (←/→ ±1, Shift ±10, Enter salta, Esc cancela), soltar = goToPage, fondo = cancelar. Estado etiquetado (page, filePath) heredado del patrón OCR; sin setState síncrono en effects (reglas React compiler).
- Zooms predefinidos: DropdownMenu en el header con Lectura óptima (ancho 820px cap), Ancho completo, Alejar ×1/×2/×3 (70/55/42% del contenedor), activo marcado con check; manual queda en +/−/Ctrl-rueda (atajo «O» nuevo, «F» ancho). Botón Maximize2 redundante eliminado; el % ahora es el trigger del menú.
- Inmersión: settings v6 (immersion {enabled, idleSeconds}, default on/4s) + sección en ConfigPanel (switch + slider 2-12s). Listener mousemove/keydown/wheel rearma timer; oculta [data-chrome] (header, rieles, asides, dock, indicador busy) con fade 0.55s y cursor:none sobre el visor; guards: mouse sobre chrome, overlays abiertos (panel/pausa/vocabulario/peek/sync); wake instantáneo con cualquier movimiento.
- Bugs de entorno resueltos durante testing: (a) ESLint react-hooks/refs (acceso a ref en render) → estado espejo actualizado desde el loop async; (b) reglas CSS nuevas ausentes del bundle: caché persistente de Turbopack servía globals.css viejo → rm -rf .next + restart del dev server; (c) arnés de testing: downs fuera de la franja de 20px y pointerup faltantes falseaban el gesto del peek.
- Testing E2E (agent-browser, 1600×900) sobre «el mundo de sofia» (657 pág, escaneado): sync 103→150→160 con persistencia en BD y sin confeti retroactivo; zoom óptimo (820px/219%) y alejar ×3 (470px/126%) con canvas correcto; peek: apertura por gesto, 5 miniaturas (158-162) con actual-badge, scrub 160→162→160, salto al soltar, Esc cancela; inmersión: oculta header/riel/dock a opacity 0 tras 4s, wake con mouse, no oculta con mouse sobre chrome ni con popover abierto; hitos: Hito 3/10 con toast+confetti+flash en pág. 197; flechas del teclado OK; libro digital «El Riel de la Lectura»: capa de texto nativa, sin botón OCR, peek OK; biblioteca con mini-rieles gel.
- Estado del usuario restaurado: sofia currentPage=103, 9 sesiones de prueba eliminadas (scripts/restore-user-state.mjs), riel en Izquierda, consola/dev.log limpios, tsc+eslint 0.

Stage Summary:
- El riel tiene diseño gel premium con puntos de hito y bandera de meta; el progreso ya no puede ser revertido por flushes inactivos (bug real corregido); «lo leí en otro lado» resuelto con sincronización silenciosa; hojear páginas es un gesto natural desde el borde inferior con miniaturas reales del PDF; zoom con presets incluido el óptimo de lectura; y el modo inmersión deja solo el libro en pantalla.
- Decisiones: currentPage solo viaja al servidor cuando cambia; miniaturas del peek sin persistencia (cache en memoria por doc); inmersión on por defecto a 4s (configurable).
- Pendiente sugerido: EPUB/TXT (todo lo anterior aplica igual), OCR en lote, exportar texto completo, presets de zoom recordados por libro.

---
Task ID: 7
Agent: Super Z (main agent)
Task: SDD del usuario — fix selección de texto al arrastrar el dock de abajo, libro a pantalla completa en «Lectura óptima», riel v3 sin animaciones.

Work Log:
- Fix peek (el bug reportado): preventDefault() en pointerdown de la zona caliente (corta la selección nativa que empezaba al arrastrar), clase body.gesture-lock (user-select none global, CSS nuevo) activada SÍNCRONAMENTE en setPeek() + respaldo por useEffect, removeAllRanges() al abrir, select-none en hotzone y carrusel. Verificado en libro con capa de texto: 0 caracteres seleccionados durante y después del arrastre; el diccionario sigue funcionando con selección normal fuera del gesto.
- Zoom rediseñado: «Lectura óptima» ya NO recorta a 820px — llena el visor de borde a borde (bleed p-0, escala containerW-2/baseWidth, recalculada en resize); nuevo preset «Página completa» (contain: min(ancho,alto) del visor, centrada, sin scroll) que sustituye al duplicado «Ancho completo»; Alejar ×1/×2/×3 ahora son fracciones del ancho real (70/55/42%); teclas «O» óptima / «F» página completa. PdfViewport gana props bleed/center/onContainerHeight; ReaderView trackea baseHeight/containerH. Verificado: canvas 1182/1184 px en óptima, página completa 496×803 sin scroll en contenedor 1184×844.
- Riel v3 (RailBar reescrito): pista continua redondeada (adiós segmentos gel), relleno continuo con rampa dinámica ámbar→verde hasta el avance actual, muescas de hito SOBRE la pista (claras si pasadas, tenues si no), perilla-knob con anillo oscuro, etiquetas de frontera coloreadas por la rampa. CERO animaciones: eliminados shine, pop de tramo, pulso del cursor, glow de bandera, flash de hito y el remount por key; solo transición de 0.2s en relleno/perilla (desactivada mientras se arrastra). Mini-riel de biblioteca también continuo (h-1.5, sin knob).
- El riel ahora es scrubber: clic salta a esa página exacta y arrastrar previsualiza el salto en vivo (pointer capture, gesture-lock, preventDefault). Fix de centrado del riel vertical (faltaba justify-center tras el rewrite).
- Saltos silenciosos unificados: goToPage(target, {silent}) — riel, peek, input de página, saltos de paneles (ModeDock) y sync NO cuentan páginas leídas, NO celebran hitos retroactivos (alinean maxHitRef) y NO abren el diálogo de pausa; las flechas/botones ←→ siguen contando como lectura. Antes un clic adelante en el riel inflaba páginas leídas y disparaba confeti de hitos no leídos.
- Bugs de entorno: caché CSS stale de Turbopack otra vez (trackRadius 999px no cargaba) → rm -rf .next + restart.
- Estado restaurado: sofia→117 (el usuario leyó 78 pág hasta ahí a las 07:03 UTC; mis pruebas lo habían movido a 592), riel→9; 4 sesiones de prueba (0p) eliminadas con ventana >= 07:25 UTC conservando las reales; posición del riel devuelta a Izquierda tras la verificación horizontal.
- Calidad: tsc 0 en src/, eslint 0, consola y dev.log limpios; verificado en sofia (escaneado 657 pág) y riel (digital con capa de texto).

Stage Summary:
- Arrastrar el dock de abajo ya no selecciona texto (bloqueo en 3 capas: preventDefault + gesture-lock síncrono + limpieza de selección); el libro llena toda la pantalla en «Lectura óptima» y existe «Página completa» para ver la hoja entera; el riel es una pista continua limpia sin animaciones, y ahora además se puede arrastrar para saltar con semántica de salto silencioso.
- Explicación dada al usuario: el espacio a los lados venía del tope de 820px (idea de columna de texto impresa); para PDF de layout fijo no aporta, así que óptima = todo el ancho; el scroll vertical es inherente (página más alta que el monitor), y «Página completa» es la alternativa sin scroll.
- Pendiente sugerido: recordar el zoom por libro (localStorage), doble página lado a lado en óptima para monitores anchos.

---
Task ID: 8
Agent: Super Z (main agent)
Task: Fix — la UI oculta por inmersión seguía ocupando su espacio (riel lateral derecho, riel, header, dock): el libro quedaba enjaulado por huecos invisibles.

Work Log:
- Causa raíz: la inmersión solo aplicaba opacity:0 a [data-chrome]; las cajas seguían en el flujo flex (header h-14, asides del riel w-16, franjas del riel top/bottom, dock w-[352px]) y el visor no crecía al ocultarse la UI.
- globals.css: cada caja chrome colapsa su espacio reservado en inmersión (width/height/max-width/max-height/padding/border-width → 0 + overflow hidden) con la misma transición de 0.55s que el fade, más visibility:hidden (fuera del tab-order y del árbol de accesibilidad). Nuevos data-chrome-kind: header / aside / railbar / dock (el dock se pliega con max-width sin desmontarse: conserva el estado de sus paneles).
- Zoom predefinidos ahora RELATIVOS AL VISOR EN VIVO: effectiveScale se deriva del tamaño real del contenedor para optimal/page/wide/mid/far (antes page/alejar fijaban la escala una vez). Al colapsar la UI, la página se re-encuadra sola: «Página completa» pasó de 123% (461×746 en 1248×787) a 142% (531×859 en 1600×900) sin tocar nada; óptima de 316% a 400%.
- ResizeObserver con debounce (140ms, primera medida inmediata) en PdfViewport y DualViewport: la transición de colapso dispara el RO en cada frame y sin debounce se re-renderizaba el PDF decenas de veces; ahora un único render al asentarse.
- Techo MAX_SCALE=4 documentado en la práctica: sofia (escaneo base 374pt) en viewport de 1600px pide 427% → canvas queda en 1496px (93.5% del ancho); evita renders absurdos de escaneos pequeños.
- E2E (agent-browser 1600×900, sofia 657 pág escaneado): riel Derecha w=0, header h=0, dock w=0, riel Abajo h=0, viewport 1600×900 completo en inmersión; despertar restaura 64px/56px/352px y el canvas se re-encuadra a 1182px (316%) con un solo render; visibility:hidden saca el header del snapshot a11y; consola y errores limpios; tsc 0 en src/, eslint 0.
- Estado restaurado: riel → Izquierda, sofia → 117 intacta, 2 sesiones de prueba (0 pág) eliminadas, localStorage v6 verificado.

Stage Summary:
- En inmersión la UI ahora DESAPARECE de verdad: su espacio se libera y el libro llena toda la pantalla en cualquier zoom predefinido, con transición suave y un solo re-render; al despertar todo vuelve a su sitio.
- Decisiones: colapso por tipo de caja (data-chrome-kind) en vez de display:none (mantiene el fade y el estado del dock); zoom predefinidos como derivados del contenedor (se corrigen solos en resize/inmersión); debounce de medidas en ambos visores.
- Pendiente sugerido: recordar el zoom por libro, doble página en monitores anchos.

---
Task ID: 9
Agent: Super Z (main agent)
Task: Fix — el panel «Modo de lectura» se expandía solo al abrir cualquier libro (no recordaba el colapso) + riel vertical invertido para que se llene de abajo hacia arriba.

Work Log:
- Dock persistente: dockOpen en ReaderView pasaba de useState(true) fijo → lazy initializer desde localStorage («riel-dock-open», default abierto si no hay clave, try/catch SSR-safe) + useEffect que persiste cada cambio. Sin riesgo de hydration mismatch (ReaderView solo se monta tras clic del usuario en la biblioteca).
- Riel bottom-up (RailBar): relleno vertical anclado a bottom:0 (antes top:0), gradiente dinámico 180deg→0deg (ámbar abajo = origen, color actual en el borde que sube), perilla espejada a top:(1-shown)% (borde superior del relleno), muescas de hito espejadas top:(1-frac)%, pageAt vertical invertido (1 - frac desde arriba) para que el scrub coincida (abajo=pág 1, arriba=pág final), e icono Milestone movido arriba de la pista (el final del libro ahora queda arriba).
- types.ts: fillV de los 6 temas volteado 180deg→0deg para que los gradientes estáticos también nazcan abajo.
- E2E (agent-browser 1600×900, sofia 657 pág escaneado): geometría verificada (bottomGap=0, altura 17.8% = 117/657, perilla en el borde superior <2px); scrub: clic 5% desde abajo → pág 32, clic 5% desde arriba → pág 624, restauración por el propio riel a 117; dock: colapsado → salir → reabrir = colapsado, incluso tras reload completo; abierto → salir → reabrir = abierto; estado final dejado en colapsado ("0") como describe la preferencia del usuario.
- Falsa alarmas: los clics al fondo del riel los interceptaba el botón overlay de Next DevTools (solo desarrollo); la inmersión (4s) colapsaba el riel entre llamadas CLI — pruebas re-hechas en una sola tanda.
- Estado restaurado: página de sofia 117 (vía riel, salto silencioso), sesión de prueba 10:02 UTC (0 pág) eliminada, la del usuario 09:56 conservada, consola y errores limpios; tsc 0 en src/, eslint 0.

Stage Summary:
- El panel de modos ahora recuerda abierto/colapsado entre libros, sesiones y recargas; el riel vertical se llena de abajo hacia arriba como un recipiente (perilla asciende por el borde del relleno, bandera de meta arriba) y el scrub por clic/arrastre mapea coherente con la nueva dirección.
- Decisión: preferencia de dock global (no por libro) — es una preferencia de layout, no de contenido; fácil de hacer per-libro si el usuario lo pide.
- Pendiente sugerido: recordar zoom por libro, doble página en monitores anchos.

---
Task ID: 10
Agent: Super Z (main agent)
Task: Rediseño de la cabecera del lector — jerarquía por importancia/uso, énfasis en pantalla completa, tooltips Radix, separadores de grupo; prueba de UI + hover + medición.

Work Log:
- Diagnóstico medido: tamaños mezclados (Volver/Ajustes 36px vs resto 32px), fullscreen enterrada como ghost de 32px dentro del grupo de zoom, tooltips nativos lentos (~1.2s), grupos sin separadores.
- Reorganización por matriz de uso: identidad (Volver+título) | navegación mx-auto (‹ input › + MapPin, la acción más frecuente) | PANTALLA COMPLETA (outline + acento ámbar border-primary/40 bg-primary/10 text-primary + etiqueta, «Salir» + secondary cuando activa) | regla | zoom (− % + con iconos Minus/Plus) | regla | Modos+Vocab | regla | chips pasivos | Ajustes. VRule nueva (h-5 w-px bg-border/50) entre grupos.
- Tip component (Radix Tooltip delayDuration 280, side bottom) en TODOS los botones icon-only con atajos: «Pantalla completa (M)», «Página anterior (←)», «Página siguiente (→)», «Reducir zoom (−)», «Aumentar zoom (+)», «Vocabulario guardado», «Ajustes del riel y la lectura», «¿Ya lo leías en otro lado? Marca tu página» (anidado Tooltip>TooltipTrigger>PopoverTrigger>Button, patrón Radix seguro). Título nativo retirado donde hay Tooltip.
- Flechas de navegación cambiadas de texto ←/→ a iconos ChevronLeft/Right; input de página intacto (silencioso).
- Bug de cascada Tailwind v4 descubierto: las utilidades dark:* del variante outline (dark:bg-input/30, dark:border-input, dark:hover:bg-input/50) se emiten DESPUÉS que las utilidades simples y las pisan en dark mode → el acento no aplicaba. Fix: duplicar las variantes dark: en el className (dark:bg-primary/10, dark:border-primary/40, dark:hover:bg-primary/20, dark:hover:border-primary/60) para que tailwind-merge elimine las del base. Verificado en computed style: reposo bg primary/10 + border primary/40 + texto primary.
- Hallazgo de entorno: Tailwind v4 envuelve hover: en @media (hover: hover) y el headless reporta hover:none/pointer:none → NINGÚN hover CSS es verificable en headless (ni los antiguos ghost). Verificación alternativa: clases presentes + base aplicada + tooltips Radix (eventos JS, no CSS hover) funcionando. El server murió dos veces tras rm -rf .next: relanzarlo con (setsid bun run dev &) para que sobreviva entre llamadas.
- E2E (agent-browser 1600×900, sofia): alturas únicas de botones = [32px] (harmonía 100%, antes [32,36]); fullscreen ON (fullscreenElement true, etiqueta «Salir», secondary) y OFF; menú zoom con 5 presets (clic real, Radix usa pointerdown); popover sync OK; toggle Modos colapsar/reabrir OK; sheet vocabulario OK (visual); disabled states en pág. 1 (prev disabled, next enabled) con salto silencioso que no cuenta páginas; tooltips verificados en 5 botones; página restaurada a 117; dock dejado colapsado («0») según preferencia del usuario; 2 sesiones de prueba (10:11 y 10:22 UTC, 0 pág) eliminadas, la real del usuario (09:56) conservada; tsc 0 en src/, eslint 0, consola limpia.
- Capturas: scripts/header-final.png (reposo con acento), scripts/header-fullscreen-on.png (Salir activa), scripts/header-vocab.png (sheet + acento visible), scripts/header-zoom-menu.png.

Stage Summary:
- Cabecera con jerarquía clara por frecuencia de uso: navegación al centro, pantalla completa como acción destacada con acento y etiqueta propia (ya no es un icono perdido en el zoom), grupos separados por reglas sutiles, todo a 32px, tooltips con atajos en cada control.
- Decisión: nav con mx-auto (no absoluto) para no solaparse con el título en ventanas estrechas; énfasis de fullscreen con variantes dark: duplicadas por el orden de cascada de Tailwind v4.
- Pendiente sugerido: centro óptico absoluto de la navegación si el usuario lo desea, y revisar hover de la app en un navegador real (limitación headless, no de la app).

---
Task ID: 11
Agent: Super Z (main agent)
Task: Insignias de colección (badges) — portada real vía API gratuita al terminar un libro, tiers por relectura, validez por título+autor, reinicio de lecturas por libro y global con confirmación.

Work Log:
- Prisma: Book += finishedAt/readCount/badge (1:1); modelo Badge {bookId unique, tier, readings, earnedAt} con onDelete: Cascade. `bun run db:push` OK.
- APIs nuevas: POST /api/books/[id]/finish (valida título+autor; guarda anti-doble-registro de 2 min; upsert de badge con tier=min(4,readings)), PATCH /api/books/[id]/meta (ficha a mano), POST /api/books/[id]/cover (multipart imagen o URL con allowlist covers.openlibrary.org/books.google.com, máx 8 MB), POST /api/books/[id]/reset (transacción: badge+sesiones fuera, pág 1), POST /api/progress/reset-all (transacción global). GET /api/books incluye badge.
- Descubrimiento de entorno: openlibrary.org/archive.org inalcanzables desde el sandbox y googleapis.com con cuota 0 (429 permanente) → la búsqueda de portadas corre EN EL NAVEGADOR DEL USUARIO (lib/cover-search.ts: Open Library search.json → covers -L.jpg → fallback Google Books con upgrade https y zoom=2; timeouts de 9 s; devuelve blob descargado o URL permitida). La imagen se guarda localmente en /public/uploads.
- UI biblioteca: EditBookDialog (título/autor + aviso de elegibilidad + "Buscar portada" + "Subir imagen…" + búsqueda automática al guardar cuando cambió la ficha y ambos campos están), BadgeShelf (medallones circulares .badge-frame con marcos/glow por tier bronce/plata/oro/diamante, resumen, próxima relectura, clic = releer; estado vacío explicativo), chip de tier en la tarjeta, botones hover Editar/Reiniciar/Eliminar, reinicio por libro y "Reiniciar todo" en cabecera — ambos con AlertDialog que enumera qué se borra y qué se conserva.
- UI lector: registerFinish al llegar a la última página NAVEGANDO (los saltos silenciosos de riel/sync/peek/input no cuentan); toasts "Insignia obtenida: Bronce" / "Insignia mejorada a Plata" / "insignia pendiente" si faltan metadatos; onBookChange sincroniza badge al estado raíz.
- Correcciones durante E2E: (1) finishTriedRef bloqueaba para siempre tras un "recent" del servidor → reemplazado por debounce de 4 s en cliente (la ventana anti-inflado la aplica el servidor) y reason "recent" ahora silencioso (evitaba toast espurio de "mejorada"); (2) updateMany con 2 argumentos en reset-all → 1; (3) else sin cerrar en goToPage.
- E2E (agent-browser 1600×900, libro de prueba de 6 págs): fin sin autor = toast "insignia pendiente" + BD limpia; ficha+autor guardados; fin navegando = Bronce (tier 1, readings 1); relectura tras ventana de 2 min = Plata (tier 2, readings 2) con toast correcto; estantería y chip correctos; portada manual aplicada (vía DataTransfer por limitación del CLI con inputs ocultos; mismo camino React+API) visible en diálogo/tarjeta/insignia; "Buscar portada" falla con elegancia en sandbox ("Sin resultados"); reset por libro con diálogo que enumera pág 6/6 + sesiones + insignia (Plata·2) → pág 1, sin badge, ficha/portada conservadas; insignia re-ganada tras reset; reset-all → 6 libros pág 1, 0 badges, 0 sesiones, toast correcto; estantería vacía.
- Estado del usuario restaurado al 100% vía scripts/backup-state.mjs (backup previo: 5 libros/96 sesiones/0 insignias): sofia 117, Riel 9, Gutenberg 1, BrainFM 24, DOSSIER 30; 96 sesiones reales intactas; libro de prueba y portada temporal eliminados con archivos.
- tsc 0 en src/, eslint 0, consola y dev.log limpios. 14 capturas scripts/badges-*.png.

Stage Summary:
- Terminar un libro (navegando de verdad a la última página) ahora acuña una insignia coleccionable con la portada del libro; releerlo la mejora Bronce→Plata→Oro→Diamante; solo cuentan libros con título+autor, que el usuario puede personalizar desde el lápiz de la tarjeta, y al guardar la ficha la app busca la portada real (Open Library → Google Books) en el navegador del usuario y la sustituye, con subida manual como plan B.
- Reinicio de lecturas por libro y global, siempre con confirmación detallada; el reinicio borra progreso/sesiones/insignia pero conserva archivo, ficha, portada, hitos y notas, permitiendo re-coleccionar.
- Decisión: los saltos silenciosos no acuñan insignias (honestidad del progreso); ventana anti-duplicados de 2 min en servidor + debounce 4 s en cliente.
- Pendiente sugerido: estados de carga en la búsqueda de portada por país/idioma, insignias hexagonales con marco ilustrado por tier, y "año de colección" en la estantería.

---
Task ID: 12
Agent: Super Z (main agent)
Task: Re-test sprite — el usuario veía fallas al reiniciar el progreso (por libro y total).

Work Log:
- Reconstrucción forense: dev.log muestra que el usuario ejecutó reset-all ×3 seguidas + reload ×2 + reset por libro + reset-all, todos 200 y con fetchBooks — el API SÍ reiniciaba; la "falla" era visual.
- Causa raíz: la semántica de progreso era currentPage/totalPages ("estás EN la pág. p") → tras reiniciar, los libros quedaban en pág. 1 pero con relleno y % NO nulos (Gutenberg 1/3 = 33%, Riel 1/24 = 4%) → "pág. 1 de 3 · 33%" parecía que el reinicio no funcionó.
- Fix de semántica a «páginas leídas» (estilo Duolingo, pág. 1 = 0 %): progressPct (done→100 %, si no (p-1)/N), RailBar progress/shown (scrub también (p-1)/N, última pág = lleno), pageAt ahora round(frac·N)+1 (la perilla de la pág. p está en (p-1)/N, clic en su posición da su propia pág.), y muescas/etiquetas de hito ahora se iluminan por displayPage >= frontera (misma regla que la celebración — corrige un desfase de 1 pág. preexistente: en la pág. de un hito la muesca quedaba tenue).
- estimateFinishDate: restantes = N-(p-1) para coherencia.
- Guard anti doble clic en el reinicio por libro (resettingOne + spinner + disabled), como ya tenía el reset total.
- E2E (agent-browser 1600×900): reinicio por libro Riel 9→1 con tarjeta "pág. 1 de 24 · 0%", relleno w=0px/opacity 0, chip de insignia fuera; reset-all → 5 libros "pág. 1 · 0%", rieles vacíos, stats 0 días/0 pág/0 min/0 terminados, estantería de insignias en estado vacío; lector con sofia 117: relleno 17,65% (esperado 116/657=17,66%), anclado abajo (gap 0), perilla en el borde superior del relleno; scrub: clic al medio → pág. 329 (fórmula exacta), clic cerca de la meta → pág. 655, clic en frac 116/657 → 115-117 según rect en vivo (mapeo exacto, el rect varía px por la transición); flecha → 118 con relleno 17,81% exacto y 1 sesión creada; salto silencioso a 131 ilumina la muesca del hito 2 (consistente con la celebración); consola y page errors limpios; tsc 0 en src/, eslint 0.
- Estado restaurado: sofia 117 (vía input, salto silencioso), Riel 9, Gutenberg 1, BrainFM 24, DOSSIER 30; 4 sesiones de prueba borradas; insignias 0; la portada real de sofia (buscada por el usuario vía API) conservada.

Stage Summary:
- El reinicio (por libro y total) ahora se VE reiniciar: todo queda a 0 % con el riel vacío, porque el progreso mide páginas leídas y no la página en la que estás parado. De paso el scrub y las muescas de hito quedaron alineados a la misma regla que las celebraciones.
- Nota para el usuario: su "Reiniciar todo" de pruebas borró las 96 sesiones reales (la racha arranca de cero) — las posiciones de lectura se restauraron a las conocidas; si quería todo en pág. 1, un clic lo devuelve (y ahora se ve a 0 %).
- Pendiente sugerido: botón "Deshacer" (snackbar 5 s) tras reiniciar todo, y contadores de lecturas por libro en la ficha.

---
Task ID: 13
Agent: Super Z (main agent)
Task: El usuario no podía subir libros en el preview ("no se me suben los libros") + revisión completa del backend, arreglar bugs y resumen.

Work Log:
- Diagnóstico raíz: GET /api/books devolvía 500 — el cliente Prisma generado (node_modules/.prisma) estaba VIEJO, sin el modelo Badge (error "Unknown field badge for include"). La BD SÍ tenía la tabla Badge y el esquema SÍ lo declaraba. Un reintento de instalación de dependencias habría regenerado node_modules sin pasar por prisma generate.
- Efecto en el usuario: la subida POST SÍ funcionaba (2 copias de sofia quedaron creadas hoy 09:28/09:29 UTC con sus archivos de 30.3MB completos), pero el fetchBooks posterior moría con 500 → biblioteca invisible → el usuario reintentaba y creaba duplicados sin ver nada.
- Fix raíz: bunx prisma generate (cliente regenerado, 490 refs a Badge) + restart del server. Prevención: script postinstall "prisma generate" en package.json para que ninguna instalación vuelva a dejar el cliente viejo.
- Limpieza: scripts/cleanup-dup-books.mjs borró las 2 sofias duplicadas (filas + PDF 30.3MB + cover de cada una). Biblioteca devuelta a los 5 libros reales.
- Revisión backend completa (9 rutas): books GET/POST, [id] PATCH/DELETE, finish, meta, reset, companion POST/DELETE, cover POST, progress/reset-all, dictionary, health. Bugs encontrados y arreglados: (1) DELETE de libro no borraba el PDF compañero → unlink añadido; (2) cover reemplazada no borraba la anterior → removePreviousCover best-effort (solo /uploads/, ignora URLs externas) + guard startsWith en DELETE; (3) POST sin anti-duplicado → 409 si existe mismo fileName+totalPages, con duplicateOf; (4) POST sin límite de tamaño → cap 200MB (413); (5) db.ts logueaba queries en producción también → log:["query"] solo en dev, ["error"] en prod; (6) LibraryView confirmUpload ahora maneja 409 con toast amable "Ya está en tu biblioteca" (cierra diálogo, sin error rojo).
- E2E (agent-browser 1600×900): subida real por UI de badge-test-book.pdf → probe OK, diálogo con portada y título autollenos, toast "Libro en el riel", libro en BD con título/autor/páginas correctos; anti-duplicado: subir test-book.pdf (igual a «El Riel de la Lectura») → toast "Ya está en tu biblioteca", sin libro nuevo; delete por UI con confirmación → 5 libros, y PDF+cover del libro borrado eliminados del disco (cero residuos); smoke del lector: sofia abre en pág 117, canvas 1496px, filtro cálido e inmersión activos, consola y page-errors limpios.
- Estado del usuario intacto: sofia 117, Riel 9, Gutenberg 1, BrainFM 24, DOSSIER 30; 0 sesiones (las borró el usuario con su reset-all de pruebas — es su estado actual); archivos en disco = 5 PDFs + 4 covers + 1 compañero válido (Riel dual), cero huérfanos; tsc 0 en src/, eslint 0; capturas scripts/e2e-dup-toast.png y scripts/e2e-reader-smoke.png.

Stage Summary:
- La causa de "no se suben los libros" nunca fue la subida: era la biblioteca que no cargaba por un cliente Prisma desactualizado. Ya sube, lista, avisa duplicados, borra con limpieza total, y un postinstall evita que el bug regrese.
- Decisión: anti-duplicado por fileName+totalPages (no por hash) — suficiente para el caso real, sin leer el archivo dos veces; si el usuario quiere dos copias del mismo PDF podrá usar "duplicar" como feature futura.
- Pendiente sugerido: indicador de progreso durante la subida de PDFs grandes (30MB+ tarda sin feedback), y botón "Deshacer" tras eliminar un libro.

---
Task ID: 14
Agent: Super Z (main agent)
Task: SDD propose — integrar graphify (Graphify-Labs) y «crapper» (Uncle Bob); teclas no deben desocultar la UI en inmersión; scroll suave hacia arriba al cambiar de página.

Work Log:
- Verificación web: «graphify» de Graphify-Labs EXISTE (YC S26, skill/CLI que convierte el codebase en grafo de conocimiento: graph.html + graph.json + GRAPH_REPORT.md). «Crapper» de Uncle Bob NO EXISTE como herramienta de software (solo Thomas Crapper, el fontanero histórico que Uncle Bob cita en Clean Code como parábola de nombrar); se reportó honesto al usuario y no se fabricó nada.
- Graphify integrado de verdad: pip graphifyy 0.9.88 en venv aislado (.venv-graphify), skill instalado en ~/.claude/skills/graphify y copiado al proyecto (skills/graphify/). Pipeline completo ejecutado sobre src/ (95 archivos, 44.882 palabras, corpus 100% código → AST determinista, 0 tokens LLM): scripts/run-graphify.sh + scripts/finish-graphify.sh (detect → AST 584 nodos/1738 aristas → merge → build → clustering → diagnóstico de salud OK → etiquetado manual de 29 comunidades → graph.json + GRAPH_REPORT.md + graph.html interactivo 650KB + manifest.json). Grafo: 635 nodos, 1734 aristas. Dioses: cn() 240, Button 47, ReaderView 42, LibraryView 32, ModeDock 26, Input 22. Queries CLI verificadas: graphify explain/path funcionan contra graphify-out/graph.json. Fix menor: save_manifest firma correcta (files dict + root kw).
- Teclas en inmersión (ReaderView ~L548): wakeKey hacia show()+arm() — cada tecla DESPERTABA la UI. Ahora keepAsleep = solo arm(): teclas y rueda ejecutan su acción sin revelar el chrome y además reinician el temporizador de ocultación; solo mousemove despierta. Verificado E2E (sofia, 1600×900): tras 7s UI oculta (.chrome-immersed) → ArrowRight cambia 117→118 con UI SIGUE oculta → mouse move SÍ despierta → ArrowLeft vuelve a 117.
- Scroll suave (PdfViewport + DualViewport): efecto que vigila pageNum/mainPage con prevPageRef — al cambiar de página el contenedor hace scrollTo({top:0, behavior:'smooth'}); primera render/restauración (prev===null) sin animación, y si la página no cambió tampoco. E2E midiendo animación: scrollTop 1302 → 32 (350ms) → 0 — desplazamiento suave real, no salto. El caso exacto del usuario (leer abajo del todo → «siguiente») ahora aterriza al inicio de la página nueva con animación.
- Estado del usuario intacto: sofia 117/657, 0 sesiones (1 sesión fantasma de la prueba borrada), dev.log limpio; tsc 0 en src/, eslint 0.

Stage Summary:
- El proyecto ahora tiene su grafo de conocimiento autogenerado y consultable (graphify-out/graph.html en cualquier navegador; graph.json para consultas CLI; GRAPH_REPORT.md con dioses y comunidades etiquetadas), más el skill listo para regenerarlo con /graphify cuando el entorno tenga runtime de skill. Costo: 0 tokens (AST puro).
- Las teclas de lectura son «fantasmas» para la inmersión: navegan sin despertar la UI; solo el mouse la trae de vuelta.
- Cambiar de página ya no te deja plantado abajo: aterrizaje suave al inicio de la página nueva, también en vista dual.
- «Crapper»: no existe — pendiente que el usuario diga qué quería realmente (¿Clean Code? ¿linter más estricto?) para hacerlo con herramienta real.

---
Task ID: 15
Agent: Super Z (main agent)
Task: Aclaración del usuario — «crapper» sí existe (complemento para asegurar la calidad del código generado por IA, útil como spec). Integrarlo de verdad.

Work Log:
- Hallazgo: el usuario tenía razón — existe github.com/unclebob/crapper (mi búsqueda anterior fue mala). Es la herramienta CRAP de Uncle Bob para 6 lenguajes INCLUIDO TypeScript: CRAP = CC² × (1−cobertura)³ + CC; bandas 1–5 bajo / 5–30 mirar / 30+ complejo y sin tests; escribe .metrics/crap.edn; exit 2 si supera --threshold; cobertura vía LCOV (vitest/c8). Repo verificado también: crap4java y crap4clj del mismo autor.
- Integración real: clone del repo en tools/crapper (primera corrida crea su .venv sola). Scripts npm: bun run crap (src completo) y crap:changed. Análisis ejecutado: 344 funciones; línea base — ReaderView 167, PdfViewport 131, DictionaryPopover 72, LibraryView 66, EditBookDialog 63, RailBar 52, PagePeek 37, DualViewport 32... (componentes React agregan todo el JSX+handlers, de ahí su CC).
- Spec para IA: CRAPPER.md en raíz — fórmula, bandas, presupuestos por tipo de unidad (helper ≤8/15, API ≤10/15, componente de vista ≤30/50, shadcn vendido exento), 6 reglas de higiene (guard clauses, extraer hook, extraer subcomponente, switch→mapa...), y trayectoria: código nuevo nace en presupuesto; monstruos históricos a dieta (cada toque extrae una pieza). Sin tests aún, crapper corre con --no-coverage; cuando haya cobertura LCOV se activa --threshold 30 como puerta.
- Primera dieta (sin cambio de comportamiento): extraídos de ReaderView los hooks use-reader-hotkeys.ts (atajos ←→+−FOM) y use-immersive-wake.ts (inmersión: solo el mouse despierta) → ReaderView 167→136 (−19%). Los hooks nuevos quedan bajo presupuesto (≤30).
- ESLint: regla complexity warn 30 (recordatorio vivo, no rompe lint).
- Verificación: tsc 0 en src; E2E smoke — sofia abre, inmersión a los ~6s (INMERSO-si), ArrowRight → pág 118 con UI oculta, scroll top=0, mouse despierta, sin errores de página. Estado restaurado: sofia 117/657, 0 sesiones.

Stage Summary:
- crapper integrado de verdad: herramienta vendida + spec CRAPPER.md + scripts npm + línea base medida + primer refactor de dieta. La métrica queda viva: bun run crap en cualquier momento.
- Graphify (tarea anterior) + crapper = el código ahora tiene grafo de conocimiento Y presupuesto de complejidad.
- Pendiente: suite de tests con cobertura para activar la puerta --threshold 30; dieta de PdfViewport (131), DictionaryPopover (72), LibraryView (66).

---
Task ID: 16
Agent: Super Z (main agent)
Task: «Primera dieta ya hecha: has todas las dietas» — dieta crapper COMPLETA de los seis monstruos históricos (ReaderView 136, PdfViewport 131, DictionaryPopover 72, LibraryView 66, EditBookDialog 63, RailBar 52), sin cambio de comportamiento.

Work Log:
- Línea base confirmada con bun run crap: los 6 monstruos en pie tras la primera dieta (Task 15).
- PdfViewport 131→26: extraídos use-pdf-render (render + red anti-página-en-blanco + capa de texto, helpers isRenderCancelled/sizeCanvas/isCanvasBlank/renderWithSafetyNet), use-ocr-page (máquina de estados OCR completa con caché), use-ocr-lang (idioma persistido), use-copy-text (portapapeles con feedback) y OcrOverlay (todo el JSX OCR con sus 9 testids intactos). OCR NO tocado: misma lógica línea a línea, solo reubicada.
- ReaderView 136→29: extraídos use-book-extras, use-reading-session (cronómetro + guardado debounced/fire-and-forget con takePending compartido + pausas naturales), use-finish-badge (insignia con badgeToast), use-milestone-celebration (hitos + confetti, init usa book.totalPages como el original), use-peek-gesture (getPage() vivo para anclar el gesto — bug evitado), use-zoom-preset (presetScaleFor + ZOOM_TARGETS), use-book-milestones, y subcomponentes ReaderHeader, ReaderStage (error/dual/banner), SyncProgressPopover (controlado: syncOpen vuelve a ReaderView para el guard de inmersión), ZoomControls+Tip, PauseDialog.
- DictionaryPopover 72→<25: use-dictionary-popover (estado+lookup+save) + use-word-selection-events (detección de selección, hint de escaneo, Escape/scroll; onClear vía ref para no re-suscribir) + DictionaryCard + DictionaryEntries.
- LibraryView 66→26: use-library-books (stats con dayKey reutilizado), use-book-upload, use-book-actions + BookCard.tsx (rate ahora con computeDailyRate7d, semántica idéntica) + LibraryConfirmDialogs. La carga inicial volvió al componente (regla nueva react-hooks/refs+set-state-in-effect del plugin v7.0.1: setState trazable en efecto de hook = error; en componente pasa como siempre).
- EditBookDialog 63→28: use-cover-manager (applyHit/runCoverSearch/onPickFile) + busy const + CoverPreview/EligibilityBadge module-level.
- RailBar 52→26: use-rail-scrub (pageAt/handlers/lockSelection) + RailTrack/RailLabels.
- Verificación: tsc 0 en src; eslint 0 (costó domar 20 errores nuevos de react-hooks v7: refs-during-render resuelto destructurando fileInputRef, set-state-in-effect moviendo el fetch inicial al componente); bun run crap → top 30+: solo shadcn exento (chart 40) y no-monstruos bajo tope duro (PagePeek 37, OutlinePanel 32, DualViewport 32).
- E2E (agent-browser 1600×900): biblioteca 5 tarjetas; sofia abre en 117 con canvas; ArrowRight 117→118; inmersión a los ~6.5s (INMERSO) → ArrowRight 119 con UI SIGUE oculta → mouse DESPIERTA; scroll 900 → «Página siguiente» → scrollTop 179 (350ms) → 0 (aterrizaje suave intacto); sync popover salto silencioso a 117; scrub del riel vertical salta (117→124, pageAt verbatim); vuelta a biblioteca 5 tarjetas; console limpio (solo HMR + DevTools), 0 page errors.
- Estado restaurado: 5 sesiones fantasma borradas → 0 sesiones; sofia 117/657, Riel 9/24, Gutenberg 1/3, BrainFM 24/25, DOSSIER 30/84; insignias 0; capturas scripts/e2e-dieta-lector.png y e2e-dieta-biblioteca.png.
- CRAPPER.md actualizado: sección «Estado y trayectoria» ahora registra la dieta completa y la lista de hooks/subcomponentes nuevos.

Stage Summary:
- Los seis monstruos del crapper quedaron dentro del presupuesto de vista (≤30): ReaderView 29 (−83% desde 167), PdfViewport 26 (−80%), DictionaryPopover <25 (−66%+), LibraryView 26 (−61%), EditBookDialog 28 (−56%), RailBar 26 (−50%). Cero cambios de comportamiento verificados por E2E.
- 18 hooks nuevos y 11 subcomponentes: cada unidad con una sola obsesión, todas ≤30 CC. El código nuevo de aquí en adelante nace en presupuesto y los monstruos ya no vuelven a engordar (regla anotada en CRAPPER.md).
- Pendiente (igual que antes): suite de tests con cobertura LCOV para activar la puerta --threshold 30; PagePeek/OutlinePanel/DualViewport (32-37) bajo tope duro pero sobre objetivo, dieta por partes cuando se toquen.

---
Task ID: 17
Agent: Super Z (main agent)
Task: Usuario pide instrucciones de uso («readme-to-use» → LEEME.md) y confirmación de si tras descargar los archivos hay que hacer `bun install` + `bun build` para usar la app.

Work Log:
- Respuesta investigada y PROBADA, no inventada: para uso diario basta `bun install` (postinstall ejecuta prisma generate solo) + `bun run dev`. `bun run build` + `bun run start` es producción opcional.
- Caza de validación (instalación limpia real): copia del proyecto sin node_modules a scripts/clean-test-copy, .env portable con ruta RELATIVA (DATABASE_URL=file:../db/custom.db, relativa a prisma/), y verificación end-to-end: bun install 13s con postinstall generando cliente Prisma con modelo Badge ✓, `next dev` sirve /api/books 200 con los 5 libros ✓, `next build` ✓, `next start` 200 con datos ✓.
- Bug encontrado y arreglado en package.json: los scripts build/start heredados usaban la salida standalone (cp a .next/standalone + `bun .next/standalone/server.js`), pero Next 16.1 ya NO emite server.js en standalone → el arranque de producción fallaba. Ahora: build = "next build", start = "next start -p 3000". Verificado en la copia limpia.
- .env del proyecto cambiado a ruta relativa portable; verificado en el proyecto real (/api/books 200, 5 libros con estado intacto). start.sh de la plataforma la reescribirá a absoluta en el próximo arranque del sandbox (inofensivo aquí); el LEEME cubre cómo dejarla portable en la máquina del usuario.
- LEEME.md en raíz (+ copia en download/): requisitos (Bun, navegador), arranque en 3 comandos, respuesta directa a «¿bun build?» (NO), qué ficheros son tu biblioteca (db/custom.db + public/uploads), casos especiales (.env ausente o con ruta de sandbox, db ausente → bunx prisma db push), troubleshooting (500 → prisma generate, puerto ocupado, OCR necesita internet la 1ª vez), tabla de scripts y mapa del proyecto.
- Paquete de descarga para el usuario: scripts/pack-for-user.sh → download/riel-de-la-lectura-app.tar.gz (48MB, 1362 archivos) con código, bun.lock, prisma, db/custom.db, public/uploads (los 5 PDFs + portadas + compañero), LEEME.md y .env portable dentro; excluye node_modules/.next/.git/skills/venv/logs. Verificado con tar -t: LEEME, .env (relativa), db, schema, PDF worker todos dentro.
- Incidente: el next-server original (2.6GB RSS) fue victima del OOM killer durante el build de la prueba de cuarto limpio (pod de 4GB) — dmesg lo confirma (pid 3261). Los intentos de relanzarlo desde bash (nohup, setsid, keepalive loop) mueren al terminar cada tool call: solo start.sh (root, boot del contenedor) puede dejarlo persistente. El preview queda a la espera del reinicio del sandbox (botón restart → start.sh → dev.sh → servidor vivo). Confesado honesto al usuario.
- Limpieza: scripts/clean-test-copy borrada (52MB + node_modules), dev-keepalive.log borrado. tsc/eslint sin tocar (0 cambios en src/).

Stage Summary:
- La pregunta del usuario tiene respuesta probada en cuarto limpio: descargar → bun install → bun run dev → localhost:3000. Sin build. Producción opcional ahora sí funciona (scripts arreglados para Next 16).
- El proyecto ahora es PORTÁTIL de verdad: .env relativa + LEEME.md + paquete tar.gz con la biblioteca incluida.
- Pendiente: al reiniciar el sandbox, start.sh reescribirá .env a absoluta (solo afecta al sandbox, no al paquete); en próximas sesiones NO lanzar builds junto al dev server (4GB de RAM: el OOM ya mordió una vez).

---
Task ID: 18
Agent: Super Z (main agent)
Task: Tres cazas del usuario — (1) barra de progreso de subida para PDFs grandes, (2) botón «Deshacer» tras borrar, (3) devolver y mejorar la estimación de «¿en qué día termino este libro según mi ritmo?» (estaba viva pero invisible: con 0 sesiones tras el reset-all, el chip nunca aparecía).

Work Log:
- ETA reforzada: en reading.ts nuevos computeDailyRate30d, computeAllTimeRate y pickDailyRate (cadena 7 días → 30 días → toda la historia); estimateFinishDate ahora acepta Pick<BookDTO,...> y hide honesto si nunca hubo ritmo. BookCard usa la cadena (el chip «a tu ritmo, terminas el X» sobrevive aunque no hayas leído en 7 días).
- ETA NUEVA EN EL LECTOR: hook use-finish-eta (carga sesiones una vez, calcula ritmo) + ReaderView pasa etaLabel con la página VIVA (la fecha mejora delante de tus ojos al leer) + ReaderHeader la muestra en el subtítulo («autor · 18% leído · terminas el 11 de enero»). Verificado E2E: sembrada sesión de 42 pág hoy → 6 pág/día → 540 restantes → 90 días → «terminas el 11 de enero» EXACTO en header y en tarjeta; sin sesiones → «— · 18% leído» sin fecha (sin inventar).
- Subida con progreso real: use-book-upload cambió fetch por XHR (upload.onprogress da bytes reales) con uploadPct + uploadPhase (uploading/saving); LibraryView muestra barra Progress + «Subiendo… N%» → «Guardando en el riel…», cancelar bloqueado en vuelo, aria-label añadido al Progress. Verificado E2E con PDF de 25.5MB: «BAR-VISTA ancho=398px texto=Subiendo… 74% indicador=translateX(-26%)» cazado en pleno vuelo; 409 de duplicados sigue intacto («Ya está en tu biblioteca»); PDF de prueba hecho con padding tras %%EOF (scripts/make-big-pdf.py, borrado al final).
- Deshacer tras borrar: nueva src/lib/undo-store.ts (papelera db/undo-trash/<id>/ + instantánea db/undo/<id>.json con ficha+insignia+sesiones+archivos, TTL 30s, sweepExpiredUndo best-effort); DELETE /api/books/[id] ahora mueve archivos a papelera y guarda instantánea (devuelve undoExpiresAt); NUEVA ruta POST /api/books/undo restaura TODO (fila con id original, insignia, sesiones con fechas, y archivos de vuelta a uploads/); sweep en GET /api/books, DELETE y UNDO; use-book-actions (.tsx ahora, llevaba JSX) añade toast de 10s con acción «Deshacer» y undoDelete con mensajes de expiración. Verificado E2E: eliminar gordo test → toast «Libro eliminado» → clic Deshacer → «Libro recuperado» → tarjeta de vuelta + PDF de 26.7MB y portada restaurados en uploads/, papelera vaciada (discardUndo).
- Verificación: tsc 0 en src (arreglado: use-book-actions llevaba JSX en .ts → renombrado .tsx); eslint 0 en src; crapper dentro de presupuesto (ReaderView 30, LibraryView 28, useBookUpload 18, BookCard 16, ReaderHeader 14; undo-store y use-finish-eta pequeños).
- Estado restaurado: 5 libros (sofia 117/657, Riel 9/24, Gutenberg 1/3, BrainFM 24/25, DOSSIER 30/84), 0 sesiones, 0 insignias, papelera y archivos de prueba borrados; captura scripts/e2e-upload-progress.png (muestra el ETA «a tu ritmo, terminas el 11 de enero» en la tarjeta + toast 409).

Stage Summary:
- Las tres presas caídas: la subida ya no es un velo ciego (bytes reales en pantalla), borrar tiene red de seguridad de 30 s con restauración total (ficha+insignia+sesiones+archivos), y la fecha de fin vuelve más fuerte que antes: ahora también vive en el lector con la página viva, con cadena de ritmo 7d→30d→histórico.
- Curiosidad para el usuario: su ETA no estaba «quitada» — estaba muda porque el reset-all borró sus sesiones (0 ritmo = 0 fecha). Ahora con la cadena de respaldo hace falta mucho más silencio para taparla.
- Pendiente: ensanchar la ventana de Deshacer si el usuario la quiere más larga (1 línea: UNDO_TTL_MS); snackbar Deshacer para «Reiniciar todo» (el reset borra sesiones y la ETA vuelve a quedarse muda — mismo remedio).

---
Task ID: 19
Agent: Super Z (main agent)
Task: Propuesta UX de navegación del usuario — (1) mover arriba/abajo con flechas y rueda CONFIGURABLE (salto ajustable, no «abajo abajo» constante), (2) matar el «marco» lateral que queda en Brave aunque la UI se oculte, (3) ocultar la UI con UNA TECLA (que no dependa del mouse).

Work Log:
- CAZA DEL MARCO (raíz verdadera, no lo que parecía): medido E2E a 1920×1080 — la scrollbar clásica reservaba 9px, pero el marco GRANDE era otro: MAX_SCALE=4 recortaba los presets. Sofia (PDF comprimido, página base 374pt) pide escala 4.01 para llenar 1504px → recortada a 4 → canvas 1496px centrado con huecos de 86-212px por lado que crecen al ocultar la UI. Los presets derivan del visor (llenar el ancho acusa como mucho visor×dpr) → tope eliminado para presets (MAX_SCALE=8 solo rige el zoom manual). Ahora óptima llena de verdad: canvas 1502/1504 y 1918/1920 en inmersión.
- Marco derecho: CSS scrollbar-width:none + ::-webkit-scrollbar 0 en [data-viewport="pdf"|"companion"] — reservado 0px (medido offsetWidth-clientWidth=0).
- Zoom manual ahora RELATIVO: zoomBy guarda customRelRef (fracción del ancho del visor) y un efecto re-escala al cambiar containerW — el zoom custom se re-encuadra en inmersión/resize como los presets (fracción 89.16%→89.17%→89.16% verificada).
- Flechas ↑/↓: useReaderHotkeys añade ArrowUp/Down → scrollByStep (fracción configurable del visor, smooth) y en los BORDES gira la página (↓ en fondo → pág siguiente contando como lectura; ↑ en techo → anterior). Refactor en 3 funciones (isBlockedTarget/runReaderKey/hook) para el presupuesto crapper (complexity 32→<30). scrollByStep mide el visor en vivo (querySelector [data-viewport="pdf"]).
- Salto y rueda configurables: settings v7 (migrate con spread de reading/immersion) añade reading.scrollStepPct (10-100%, default 40) y reading.wheelBoost (1=nativa, hasta 4×). PdfViewport intercepta la rueda SOLO si boost≠1 (nativa mantiene la suavidad del navegador; probado: deltaY 120 → +240 exactos a 2×). Slider 80% probado: salto 819px = 80% de 1024.
- Tecla de ocultar UI: immersion.toggleKey (default "h", capturador en ConfigPanel con teclas reservadas bloqueadas: flechas, +, −, F, O, M, Esc, Tab, Espacio, Enter). toggleHideUi en ReaderView: oculta al instante aunque el auto-ocultado esté apagado; si la UI la ocultó la tecla, el mouse NO la despierta (hiddenByKeyRef en use-immersive-wake; wake y keepAsleep la respetan) — solo la misma tecla la devuelve y re-arma el idle (rearmRef). Con paneles abiertos la tecla no esconde nada.
- ConfigPanel: nueva caja «Navegación dentro de la página» (slider salto ↑/↓ con %, slider rueda con nativa/N×) + bloque de tecla en la caja de inmersión (botón capturador «Pulsa una tecla…», hints de reservadas). data-testids para E2E.
- E2E (agent-browser 1920×1080, sofia 117/657): tecla h oculta (1920 completo, huecos 1px) → mouse NO despierta → h devuelve (header 56px); idle 6s con mouse sobre el libro SÍ oculta y mouse despierta (la prueba previa «fallaba» porque el mouse virtual descansaba sobre el chrome — comportamiento correcto por diseño); flechas 410px=40% y 819px=80% exactos; bordes 117→118→117; rueda 2× +240; custom relativo 0.8916→0.8917→0.8916; migración v6→v7 implícita (sliders mostraron defaults tras cargar localStorage viejo); consola y page-errors limpios; tsc 0 en src, eslint 0 (borrado scripts/cleanup-test-session.js con require() que rompía lint).
- Incidente infra: OOM killer volvió a comerse el next-server del boot (1.7GB RSS, dmesg pid 1625) — relanzado con nohup y SOBREVIVIÓ entre tool calls (la muerte entre llamadas de Task 17 era el OOM, no el sandbox). Sin builds cerca no hay muerte.
- Estado restaurado: sofia 117/657, 8 sesiones de prueba borradas (0 sesiones), sliders de vuelta a 40%/nativa en el navegador de pruebas, preset óptimo activo, evidencia scripts/e2e-task19-lectura-optima.png.

Stage Summary:
- El marco era un tope de zoom heredado: los PDFs de página base pequeña (los comprimidos del usuario) no podían llenar la pantalla ni con la UI oculta. Ahora el libro llena de borde a borde en óptima, la scrollbar no roba franja y el zoom manual también se re-encuadra.
- La navegación es del usuario: ↑/↓ con el salto que él elija (10-100% del visor), rueda nativa o amplificada, y las flechas giran la página en los bordes — «abajo abajo» constante terminado.
- La UI ya no depende del mouse: H (o la tecla que elija) la esconde y la trae; el mouse solo manda cuando el escondido fue por inactividad.
- Pendiente menor: los presets «Página completa» y «Alejar» mantienen su aire alrededor por diseño (40/16px); si el usuario quiere ese aire configurable, es un slider más.

---
Task ID: 20
Agent: Super Z (main agent)
Task: Arreglar «teclas muertas»: los hotkeys del lector (flechas, zoom, H) no respondían hasta hacer click en la página del libro. Diagnóstico + fix integral + E2E.

Work Log:
- Síntoma del usuario: «los hotkeys no funcionan, incluso las flechas, hasta darle click en una página del libro».
- Reproducción empírica con Playwright (scripts/test-hotkeys-focus.js): escenario standalone (pestaña) vs iframe. En standalone las flechas funcionaban con foco en BODY (0→410px), pero en IFRAME sin click previo las teclas van al documento padre (limitación del navegador, no del código).
- Rutas de teclas muertas confirmadas con scripts/test-dead-keys.js:
  * RUTA 2 ❌: input de número de página → tras Enter el foco queda en el INPUT → isBlockedTarget bloquea TODO hasta click en la página. EXACTAMENTE el síntoma del usuario.
  * RUTA 1 (dock): el guard isBlockedTarget bloqueaba el dock ENTERO ([data-dock="modes"]) aunque el foco quedara en un botón de preset que no consume flechas.
  * RUTA 3/4 ✅: botones normales del header no bloqueaban (no estaban en el guard).
- FALSA ALARMA investigada y descartada: el botón «Modos» parecía inerte en los tests. Causa real: dockOpen abre POR DEFECTO (localStorage vacío → null !== "0" → true) y los tests lo cerraban con su click inicial. Los 4 scripts de debug (test-debug-dock*) documentan la cadena: click nativo llega, propagación completa P1→P4, fiber con onClick presente. No hay bug en el toggle.
- FIXES (4 piezas):
  1. src/hooks/use-reader-hotkeys.ts — guard granular: ya no bloquea el dock entero; bloquea solo INPUT/TEXTAREA/SELECT/contentEditable, [role="dialog"] (sheets/popovers abiertos) y controles que consumen flechas ([role="slider"/"tab"/"menuitem"/"option"/"combobox"] y closest a slider/menu/listbox/radiogroup/tablist). Los botones sueltos dejan pasar los atajos.
  2. src/components/reader/ReaderHeader.tsx — el input de página suelta el foco con Enter/Escape (preventDefault + blur + focus al visor con preventScroll). Fin de la ruta principal de teclas muertas.
  3. src/components/reader/PdfViewport.tsx — al terminar la carga, si activeElement es BODY, el visor toma el foco (preventScroll): al abrir el libro los atajos ya están vivos sin click previo.
  4. src/components/reader/ReaderView.tsx — contexto embebido (window.self !== window.top): pointerdown en capture hace window.focus() (reclama el foco del iframe) y pastilla fija «Haz click en el libro para activar el teclado» (data-testid="kbd-focus-hint", pointer-events-none, z-50, bottom-center) mientras document.hasFocus() sea false; se oculta sola al recuperar foco (listeners focus/blur + sync inicial).
- E2E post-fix (scripts/test-hotkeys-e2e.js, test-dock-final.js, test-iframe-hint.js):
  * Flecha tras Enter en input página: 0→410 ✅ (foco en el visor). Tras Escape: 0→410 ✅.
  * Flecha tras click en preset del dock: 0→410 ✅ (antes bloqueada).
  * Regresión guard: tab enfocado consume ArrowRight (410→410, no navega página) ✅; slider del sheet de ajustes consume flechas ✅; tras cerrar sheet flecha funciona 410→820 ✅.
  * Tecla H tras click en botón del dock oculta la UI ✅; toggle dock cierra/abre ✅.
  * Standalone sin NINGÚN click: foco cae en el visor (aria-label «Visor de páginas del libro») y flecha 0→410 ✅.
  * IFRAME: sin click teclas muertas (esperado, navegador); tras abrir el libro con UN click: teclas vivas 0→410 ✅; si el padre roba el foco la pastilla aparece ✅; click de vuelta → pastilla desaparece y flecha 410→820 ✅.
  * Consola y pageerrors limpios en todos los runs.
- tsc --noEmit: 0 errores en src (los de examples/ y skills/ son del andamio, preexistentes). eslint en los 4 archivos tocados: 0.
- Estado base: sofía intacta 117/657 (los navegadores de test son perfiles efímeros, los saltos de página no llegaron a persistir). 6 sesiones de lectura en DB del rango 01:01–01:11 UTC — mezcla ambigua de tests y posible lectura real del usuario; NO se borraron por seguridad de la racha. public/iframe-test.html (artefacto de test, 200 bytes) eliminado del bundle; los scripts de iframe lo recrean si hace falta.

Stage Summary:
- Los hotkeys ya no mueren: ni tras el input de página, ni tras botones del dock, ni al abrir el libro (el visor nace con foco). El guard ahora distingue «el foco necesita las teclas» (inputs, sliders, tabs, diálogos) de «el foco está en un botón suelto» (atajos vivos).
- En el preview embebido (iframe del chat): el primer click dentro de la app activa el teclado para siempre, cada pointerdown reclama el foco, y una pastilla avisa cuándo el teclado está en el padre. La limitación inicial del iframe (teclas antes del primer click) es del navegador y no tiene arreglo desde dentro del marco.
- Lección de depuración: dockOpen abre por defecto con localStorage vacío — los tests que clickan «Modos» al empezar lo CIERRAN y simulan un botón roto. Anotado para futuros E2E.
- Pendiente del todo (sin empezar): barra de progreso de subida, botón Deshacer tras borrar, presets «Página completa/Alejar» con aire configurable (propuesta del usuario, menor).

---
Task ID: 34
Agent: Super Z (main agent)
Task: (1) Cada prueba E2E debe partir con el progreso de los libros a cero (incluidos los capturados img), (2) poblar la biblioteca con libros gratuitos (el usuario borró los suyos), (3) fondo secundario «capa 2» estático estilo Brutalismo/Atenas, (4) matar el búho-«gato» y poner un sello ateniense minimalista, (5) tar de todo el proyecto.

Work Log:
- Auditoría: BD vacía (0 libros/sesiones/insignias; el usuario borró todo desde la UI — dev.log muestra DELETE /api/books), upload/ casi vacío (solo companion-es.pdf), EPUB sigue sin soporte (solo PDF; el toast lo dice), dev vivo en :3000.
- CAPA 2 (fondo secundario): generadas 2 imágenes con z-ai image → public/atena-capa2-fachada.png (Partenón brutalista, 1344x768) y public/atena-capa2-busto.png (estatua con casco crestedo, 768x1344). Montadas en layout.tsx como `.atena-capa2` (fixed, inset-0, z-index -10, pointer-events-none): fachada a sangre (opacity .18) + busto anclado abajo-derecha (opacity .17) + viñeta que funde con oklch(0.16 0.04 258). CERO animaciones/transiciones (estática por designio). Verificado E2E: position fixed, z -10, ambas imágenes pintadas, animationName none.
- SELLO: el «búho» del hero se leía como un gato feo → nuevo componente `AtenaSeal` (columna dórica geométrica en marco cuadrado, 6 líneas + capitel/basa, currentColor) en LibraryView; clase CSS .owl-glow renombrada .seal-glow; favicon nuevo public/atena-seal.svg y layout.tsx deja de apuntar al logo CDN de Z.
- LIBROS GRATUITOS: scripts/make-seed-books.py forja en public/uploads: don-quijote-atena.pdf (40 págs, español, platypus, portada recortando la fachada), meditaciones-atena.pdf (24 págs, inglés para diccionario, portada tipográfica), atena-escaneado.pdf (10 págs SOLO-IMAGEN con grano/manchas para OCR, portada del busto) + companion-es.pdf (12 págs) movido a uploads y atado al Quijote (lectura dual). Todo dominio público (Cervantes 1605; Meditations trad. George Long 1862). seed-manifest.json con totalPages reales vía pypdf.
- SEMILLA + REINICIO: scripts/seed-library.mjs (bun) garantiza los 3 libros por fileName y reinicia TODO el progreso (insignias, sesiones, página 1, readCount 0) — igual que POST /api/progress/reset-all pero sin servidor. Biblioteca actual: 3 libros, 0 sesiones, 0 insignias.
- REGLA DE LA CASA en pruebas: 5 suites E2E (test-vn-rebuild, test-hotkeys-e2e, test-dead-keys, test-dock-final, test-iframe-hint) llaman a /api/progress/reset-all ANTES de tocar nada. 8 suites adaptadas al estado cero: ya no exigen «Continuar» (con progreso a cero solo existe «Empezar a leer») → helper startBookButton().
- CAZA EN LA SUITE VN (la nueva biblioteca rompía 5 asertos): (a) la tarjeta viva es vn-card-box, no vn-card; (b) Space sobre tarjeta TERMINADA AVANZA (no pausa) → la prueba de pausa se coloca primero en tarjeta en marcha; (c) el menú de presets no se cierra al elegir uno → el 2º click al gatillo lo cerraba y el preset se desmontaba (click directo + force); (d) 1 click en vn-next sobre la última tarjeta solo TERMINA (el 2º gira la página, sondeo hasta ver el cambio); (e) tras 6 s de reposo la UI se autooculta → mouse.move antes de «Volver a la biblioteca».
- BICHO REAL CAZADO Y MUERTO: pdf.js v6 usa Map.getOrInsertComputed (TC39 reciente) y Chromiums algo viejos explotan en WorkerTransport.getOptionalContentConfig («is not a function») dejando páginas sin pintar. Nuevo src/lib/map-get-or-insert-polyfill.ts importado como PRIMERA línea de pdf-client.ts. Suite VN pasó de 3 page-errors a 0.
- Resultado E2E: test-vn-rebuild 22/22 PASS (era 21/1), test-hotkeys-e2e ✅, test-dead-keys ✅, test-dock-final ✅, cero pageerrors, capa 2 estática verificada, tarjetas/covers pintados (scripts/capa2-biblioteca.png, capa2-lector.png, capa2-novela.png).
- Gates: tsc --noEmit 0 errores en src; eslint src 0; dev.log compila limpio. Estado base restaurado: 3 libros semilla en página 1, 0 sesiones, 0 insignias.
- Entrega: download/atena-proyecto.tar.gz (31.7 MB, 1614 archivos; excluye node_modules/.next/.git/.venv-graphify/.zscripts/skills/tool-results/download y *.log).

Stage Summary:
- La biblioteca nace poblada con 3 libros gratuitos (digital ES, digital EN y un escaneado solo-imagen para OCR) más compañero dual, y NINGUNA prueba puede arrastrar progreso viejo: el reset-all es el primer latido de cada suite.
- La casa ahora tiene piedra: capa 2 estática con Partenón y Atenea en contraste brutalista sobre la noche egeo, sello de columna dórica en el hero y favicon propio — fuera el búho-gato y el logo CDN.
- Regalo colateral: el polyfill de Map.getOrInsertComputed arregla el render de PDF en navegadores viejos, no solo en el laboratorio.
- Pendiente viejo que sigue vivo: EPUB (epub.js) sigue sin soporte real en la app (los toasts lo dicen); cuando toque, las semillas ya incluyen el hábito de poblar la biblioteca por manifest.

---
Task ID: 35
Agent: Super Z (main agent)
Task: «Ataca todos los cambios que se borraron» + batería E2E completa («TestSprite») porque el usuario veía progreso perdido.

Work Log:
- Re-terrizar: auditoría completa del repo. NADA del Task 34 se había perdido: capa 2 en layout.tsx + globals.css (fachada+busto, 0 animaciones), AtenaSeal en LibraryView (columna dórica, 6 líneas), /api/progress/reset-all, polyfill Map.getOrInsertComputed, semillas en public/uploads, scripts de reset por suite. La BD tenía 3 libros; dev vivo en :3000.
- BICHO REAL ENCONTRADO y resucitado: public/iframe-test.html había sido borrado en Task 20 (artefacto de test) → suite test-iframe-hint moría con timeout. Recreado (host de 105 bytes con iframe #app a /). Suite pasa.
- BATERÍA E2E «TestSprite» completa, en orden: test-vn-rebuild 22/22 PASS (hero, encendido letra a letra Lenta 14 letras/1.6s, pausa/reanudar, presets, disolvencia 1 sola capa saliente en ráfaga de 3, retroceso, giro real, Escape, reduced-motion, 0 page errors); test-hotkeys-e2e PASS; test-dead-keys PASS (4 rutas); test-dock-final PASS; test-iframe-hint PASS tras el rescate (pastilla aparece al robar foco, teclas vivas al volver).
- Auditoría matemática re-corrida: python3 scripts/audit_vn_timing.py → «FÓRMULA SANA — 0 bichitos» (T1-T8 verdes: jerarquía coma/punto 2.25, series sin acumular, sin pausa colgante, Instantánea 0ms, linealidad 2.0, WPS efectivo 79% del rótulo).
- Gates: tsc --noEmit filtrado 0 en src; eslint src 0; dev.log limpio.
- Estado base restaurado: scripts/seed-library.mjs → 3 libros (Quijote 40p, Meditaciones 24p, Cuaderno capturado 10p) en página 1, 0 sesiones, 0 insignias. Verificación visual: capa 2 fixed/z-10/pointer-events-none/ambas imágenes/animationName none; sello 6 líneas 0 círculos; 3 tarjetas; 0 pageerrors.
- scripts/dbcheck.mjs añadido (auditoría rápida de BD vía Prisma).
- Tar regenerado: download/atena-proyecto.tar.gz (31.7 MB, 1616 entradas, mismas exclusiones).

Stage Summary:
- El progreso NO se había perdido: todo el Task 34 estaba vivo; el bicho único era el HTML host del iframe de prueba, ya resucitado y con suite en verde.
- Batería completa «TestSprite» 5/5 suites PASS con la regla de la casa (reset-all como primer latido) y 0 page errors en todas.
- Fórmula de ritmo re-auditada con Python math: sana, sin absurdos.
- Entregable fresco: download/atena-proyecto.tar.gz.

---
Task ID: 36
Agent: Super Z (main agent)
Task: «El modo novela tiene muchos fallos: se ve atrás el libro, tiene que verse más cómodo, las cards se ven re mal y el modo auto no parece avanzar de una card».

Work Log:
- Diagnóstico (releído VisualNovelOverlay.tsx + globals.css): (1) el overlay dejaba entrever el libro (98.5% + card translúcida 72%); (2) card plana: borde 1px al 10%, fondo translúcido, tipografía apretada; (3) NO existía modo auto: solo Instantánea avanzaba tarjetas (a medio camino: se detenía en el fin de página sin girar).
- MODO AUTO REAL: VnSettings.auto (persistida, default false, migración merge cubre clientes viejos). Toggle «Auto» (Repeat icon, aria-pressed, data-testid vn-auto) en la barra superior. Nuevo efecto de auto-avance = ÚNICA fuente de avance automático: al terminar la tarjeta espera max(650, base*10) ms (380 ms en Instantánea), avanza, y en la última tarjeta GIRA LA PÁGINA sola (onGoToPage cuenta como lectura). Respeta pausa (playing) y loading; advance/stepBack limpian el temporizador (clearAuto) para que un click manual nunca cause doble salto. El auto-avance huérfano de Instantánea se eliminó: ahora Instantánea + Auto también gira página.
- ESCENARIO CÓMODO: .vn-overlay ahora es opaco por capas (radial egeo + gradiente 93→97% + fachada del Partenón de la capa 2 fantasma detrás + base sólida) — el libro NO se asoma; la identidad Atenas queda de fondo, estática.
- CARDS BRUTALISTAS: borde 2px egeo/32%, base opaca 97%, sombra dura desplazada 10px 12px (brutalismo), radio 0.8rem, padding clamp(1.9-2.9rem), tipografía Fraunces clamp(1.35-1.78rem) con line-height 1.9, tarjeta más ancha (780px), letras apagadas a 0.17.
- E2E nueva scripts/test-vn-auto.js: 18/18 PASS (toggle default OFF→ON, preset Viva por menú, avance automático a tarjeta 2 en 783 ms sin click, pausa congela encendido y al auto, reanudar continúa hasta tarjeta 3, giro de página sola en ~2 s, fachada en el fondo, borde 2px, alpha 0.97, toggle OFF, Escape, 0 page errors).
- Regresión completa: test-vn-rebuild 22/22, hotkeys ✅, dead-keys ✅, dock-final ✅, iframe-hint ✅ (todas con reset-all como primer latido), audit_vn_timing «FÓRMULA SANA — 0 bichitos».
- Gates: tsc filtrado 0 en src, eslint src 0, dev.log limpio. Evidencia scripts/vn-redesign.png (Partenón fantasma + card brutalista).
- Estado base restaurado: 3 libros en página 1, 0 sesiones, 0 insignias. Tar regenerado: download/atena-proyecto.tar.gz.

Stage Summary:
- El modo novela ahora tiene su propio escenario ateniense opaco: el libro desaparece, la card flota sobre el Partenón fantasma con borde brutalista y tipografía cómoda.
- El modo auto existe de verdad: tarjeta tras tarjeta sola, pausa lo congela, y al acabar la página gira solo — un solo motor de avance, sin carreras.
- La Instantánea perdió su avance huérfano y ganó el giro de página cuando Auto está activo.

---
Task ID: 37
Agent: Super Z (main agent)
Task: «Sigue haciendo testing, todavía no quedó a gusto. Instala la skill superpowers y la skill ponytail y úsalas, quizás de esta forma logres arreglar tus issues».

Work Log:
- Skills instaladas desde ClawHub: superpowers (workflow spec-first + systematic-debugging: LEY DE HIERRO «nada de fixes sin causa raíz») y ponytail (dev senior perezoso: el cambio MÍNIMO completo, arregla la causa raíz una vez, test para lógica no trivial). Ambas aplicadas en esta tarea.
- Batería de estrés nueva (scripts/test-vn-stress.js, 15 asertos): libro OCR sin texto, tormenta de 6 clicks con Auto, cambio de preset a mitad de encendido, Escape a mitad de disolvencia, desborde de card a 700px, retroceso en tarjeta 0, sonido OFF, Auto en última página.
- BICHO REAL CAZADO CON LA SONDA (scripts/probe-pdf-load.js): abrir libro → volver → reabrir rechazaba «Error cargando PDF UnknownErrorException» (2 de 3 rondas). Instrumentación temporal en PdfViewport reveló la causa raíz: «this._requestsByChunk.getOrInsertComputed is not a function» — pdf.js v6 usa el upsert TC39 en Map TAMBIÉN EN EL WORKER (pdf.worker.mjs:3106 y 8 sitios más), y el polyfill del Task 34 solo parchaba el hilo principal. En Chromium viejos, la carga por rangos del worker explotaba al reabrir libros.
- FIX ponytail (causa raíz, una vez, en el lugar compartido): scripts/patch-pdf-worker.py inyecta el polyfill Map.getOrInsert/Computed al principio de public/pdf.worker.min.mjs (idempotente, marcador «atena-polyfill», re-ejecutable si se recopia el worker). Sonda tras el parche: 0 errores en 3 rondas.
- Lecciones del suite de estrés (bugs del TEST, no de la app): el último libro leído pasa a ser la primera tarjeta (lastReadAt DESC) → ahora se abre SIEMPRE por nombre; dos botones legítimos «Volver a la biblioteca» (header + ReaderStage) → .first(); numPages se lee del span «de N» del header.
- Suite de estrés final: 15/15 PASS. Regresión completa: vn-rebuild 22/22, vn-auto 18/18, hotkeys ✅, dead-keys ✅, dock ✅, iframe ✅ — 7 suites verdes, 0 errores de consola en todas.
- Gates: tsc filtrado 0 en src; eslint src 0; dev.log limpio (el aviso Fast Refresh era del ciclo de edición, entradas recientes todas 200). Instrumentación PDFLOAD-DEBUG retirada.
- Estado base: 3 libros página 1, 0 sesiones, 0 insignias (reset-all + seed). Tar regenerado.

Stage Summary:
- El fallo esporádico «No se pudo abrir el PDF» en re-aperturas era real y ahora está muerto en su origen: el worker de pdf.js ya respira con el upsert de Map en Chromium viejos. Es el mismo bicho que el Task 34 mató en el hilo principal — ahora también en su otro reino.
- El modo novela sobrevive a tormentas de clicks con Auto, cambios de preset en caliente, Escapes a mitad de disolvencia, viewports de 700px, fin de libro y libros sin texto — 15 asertos de estrés nuevos en verde.
