"use client";

import { useCallback, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { BADGE_TIERS, type BookDTO } from "@/lib/types";

interface FinishResponse {
  badge: { tier: number; readings: number; earnedAt: string } | null;
  first: boolean;
  reason?: string;
}

/** Tostadas de insignia: primera lectura vs. relectura que sube el tier */
function badgeToast(
  data: FinishResponse & { badge: NonNullable<FinishResponse["badge"]> },
  bookTitle: string,
  toast: ReturnType<typeof useToast>["toast"],
  onBookChange?: (book: BookDTO) => void,
  bookRef?: { current: BookDTO }
) {
  const meta = BADGE_TIERS[data.badge.tier] ?? BADGE_TIERS[1];
  if (data.first) {
    toast({
      title: `Insignia obtenida: ${meta.label}`,
      description: `«${bookTitle}» entra en tu colección. Releerlo subirá su tier hasta Diamante.`,
      duration: 9000,
    });
  } else {
    toast({
      title: `Insignia mejorada a ${meta.label}`,
      description: `Lectura nº ${data.badge.readings} completada de «${bookTitle}».`,
      duration: 9000,
    });
  }
  onBookChange?.({
    ...(bookRef?.current ?? ({} as BookDTO)),
    finishedAt: new Date().toISOString(),
    readCount: data.badge.readings,
    badge: { tier: data.badge.tier, readings: data.badge.readings, earnedAt: data.badge.earnedAt },
  });
}

/**
 * Insignia: registro de lectura completada. Los saltos silenciosos (riel, sync,
 * peek) no cuentan: llegar a la última página debe ser navegando de verdad.
 * El cliente solo amortigua ráfagas (< 4 s); la ventana anti-duplicados
 * (< 2 min) la aplica el servidor.
 */
export function useFinishBadge(opts: {
  bookId: string;
  bookTitle: string;
  bookRef: { current: BookDTO };
  onBookChange?: (book: BookDTO) => void;
}) {
  const { bookId, bookTitle, bookRef, onBookChange } = opts;
  const { toast } = useToast();
  const lastFinishCallRef = useRef(0);

  const registerFinish = useCallback(async () => {
    const t = Date.now();
    if (t - lastFinishCallRef.current < 4000) return;
    lastFinishCallRef.current = t;
    try {
      const res = await fetch(`/api/books/${bookId}/finish`, { method: "POST" });
      if (!res.ok) return;
      const data = (await res.json()) as FinishResponse;
      if (data.reason === "missing-metadata") {
        toast({
          title: "Lectura completada — insignia pendiente",
          description: "Añade el título y el autor de este libro (lápiz en su tarjeta) para que las lecturas den insignia.",
          duration: 10000,
        });
        return;
      }
      // "recent": lectura ya registrada hace menos de 2 min (recarga, doble
      // remontaje) — se ignora en silencio, sin tostada ni cambio de estado.
      if (!data.badge || data.reason === "recent") return;
      badgeToast(data as FinishResponse & { badge: NonNullable<FinishResponse["badge"]> }, bookTitle, toast, onBookChange, bookRef);
    } catch {
      // sin conexión: no interrumpe la lectura
    }
  }, [bookId, bookTitle, onBookChange, bookRef, toast]);

  return { registerFinish };
}
