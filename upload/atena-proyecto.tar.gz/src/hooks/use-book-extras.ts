"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useSettings } from "@/lib/settings";
import { getBookMode, setBookMode } from "@/lib/mode-memory";
import type { BookDTO, BookExtras } from "@/lib/types";

/**
 * Extras del libro (notas, pausas, hitos por panel) con patch optimista y
 * persistencia, memoria del último modo usado por libro y estado abierto/
 * colapsado del dock de modos persistido en localStorage.
 */
export function useBookExtras(opts: {
  book: BookDTO;
  onBookChange?: (book: BookDTO) => void;
}) {
  const { book, onBookChange } = opts;
  const modes = useSettings((s) => s.modes);
  const setModePreset = useSettings((s) => s.setModePreset);

  const [extras, setExtras] = useState<BookExtras>(() => book.extras ?? {});
  const extrasRef = useRef<BookExtras>(extras);
  const bookRef = useRef(book);

  // Recuerda si el usuario dejó el panel colapsado: se restaura tal cual en cualquier libro
  const [dockOpen, setDockOpen] = useState<boolean>(() => {
    try {
      return localStorage.getItem("riel-dock-open") !== "0";
    } catch {
      return true;
    }
  });

  useEffect(() => {
    bookRef.current = book;
  }, [book]);

  const patchExtras = useCallback(
    (patch: Partial<BookExtras>) => {
      const merged = { ...extrasRef.current, ...patch };
      extrasRef.current = merged;
      setExtras(merged);
      onBookChange?.({ ...bookRef.current, extras: merged });
      fetch(`/api/books/${book.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ extras: merged }),
      }).catch(() => undefined);
    },
    [book.id, onBookChange]
  );

  // Restaurar el último modo usado en este libro y memorizar cambios futuros
  useEffect(() => {
    const stored = getBookMode(book.id);
    const current = useSettings.getState().modes.preset;
    if (stored && stored !== current) setModePreset(stored);
  }, [book.id, setModePreset]);
  useEffect(() => {
    setBookMode(book.id, modes.preset);
  }, [book.id, modes.preset]);

  // Persistir el estado abierto/colapsado del panel de modos
  useEffect(() => {
    try {
      localStorage.setItem("riel-dock-open", dockOpen ? "1" : "0");
    } catch {
      /* noop */
    }
  }, [dockOpen]);

  return { extras, extrasRef, bookRef, patchExtras, dockOpen, setDockOpen, modes, setModePreset };
}
