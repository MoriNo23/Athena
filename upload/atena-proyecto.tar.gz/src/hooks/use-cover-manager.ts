"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { searchCover, uploadCover, type CoverHit } from "@/lib/cover-search";

type CoverSource = "openlibrary" | "googlebooks";

function sourceLabel(source: CoverSource): string {
  return source === "openlibrary" ? "Open Library" : "Google Books";
}

/**
 * Portada del libro: búsqueda automática en APIs gratuitas (solo con título +
 * autor) y subida manual de imagen. Aplica al instante vía /api/books/[id]/cover
 * y avisa con tostadas; los estados searching/importing bloquean el diálogo.
 */
export function useCoverManager(opts: {
  open: boolean;
  book: { id: string; title: string; author: string | null; coverPath: string | null } | null;
  title: string;
  author: string;
  onSaved: (book: { id: string; title: string; author: string | null; coverPath: string | null }) => void;
}) {
  const { open, book, title, author, onSaved } = opts;
  const { toast } = useToast();
  const [cover, setCover] = useState<string | null>(null);
  const [searching, setSearching] = useState(false);
  const [importing, setImporting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  // al abrir el diálogo, la portada parte de la actual del libro
  useEffect(() => {
    if (!open || !book) return;
    setCover(book.coverPath);
    setSearching(false);
    setImporting(false);
  }, [open, book]);

  /** Sube/aplica el hit encontrado y avisa; devuelve si la portada quedó aplicada */
  const applyHit = useCallback(
    async (hit: CoverHit, meta: { title: string; author: string }): Promise<boolean> => {
      if (!book || !hit) return false;
      const up = await uploadCover(book.id, hit);
      if (!up.ok || !up.coverPath) {
        toast({
          title: "No se pudo aplicar la portada",
          description: up.error ?? "Intenta de nuevo",
          variant: "destructive",
        });
        return false;
      }
      setCover(up.coverPath);
      onSaved({ id: book.id, title: meta.title, author: meta.author || null, coverPath: up.coverPath });
      const src = sourceLabel(hit.source);
      toast({
        title: "Portada actualizada",
        description: hit.downloaded
          ? `Imagen descargada y guardada desde ${src}.`
          : `Enlazada desde ${src}.`,
      });
      return true;
    },
    [book, onSaved, toast]
  );

  /** Busca la portada en la API y la aplica al libro; silent = sin tostadas de aviso */
  const runCoverSearch = useCallback(
    async (silent = false): Promise<boolean> => {
      if (!book) return false;
      const meta = { title: title.trim(), author: author.trim() };
      if (!meta.title || !meta.author) {
        if (!silent) {
          toast({
            title: "Faltan datos para buscar",
            description: "La portada real se busca con título y autor definidos: es lo que pide la API.",
          });
        }
        return false;
      }
      setSearching(true);
      try {
        const hit = await searchCover(meta.title, meta.author);
        if (!hit) {
          if (!silent) {
            toast({
              title: "Sin resultados",
              description: "Ninguna API gratuita encontró esa portada. Puedes subirla como imagen.",
            });
          }
          return false;
        }
        return await applyHit(hit, meta);
      } catch {
        if (!silent) {
          toast({
            title: "Búsqueda fallida",
            description: "No hubo respuesta de las APIs de portadas. Revisa tu conexión e inténtalo de nuevo.",
          });
        }
        return false;
      } finally {
        setSearching(false);
      }
    },
    [book, title, author, applyHit, toast]
  );

  /** Portada manual: sube la imagen elegida y la aplica al instante */
  const onPickFile = useCallback(
    async (file: File | undefined | null) => {
      if (!book || !file) return;
      if (!file.type.startsWith("image/")) {
        toast({ title: "Ese archivo no es una imagen", variant: "destructive" });
        return;
      }
      setImporting(true);
      try {
        const fd = new FormData();
        fd.append("file", file);
        const res = await fetch(`/api/books/${book.id}/cover`, { method: "POST", body: fd });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "Error al subir la imagen");
        setCover(data.book.coverPath);
        onSaved({ id: book.id, title: title.trim() || book.title, author: author.trim() || null, coverPath: data.book.coverPath });
        toast({ title: "Portada aplicada", description: "Imagen personalizada guardada." });
      } catch (e) {
        toast({
          title: "No se pudo aplicar la imagen",
          description: e instanceof Error ? e.message : "Intenta de nuevo",
          variant: "destructive",
        });
      } finally {
        setImporting(false);
      }
    },
    [book, title, author, onSaved, toast]
  );

  return { cover, searching, importing, fileRef, runCoverSearch, onPickFile };
}
