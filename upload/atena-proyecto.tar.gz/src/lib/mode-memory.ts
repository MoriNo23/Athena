"use client";

import { ModePresetId } from "@/lib/types";

/**
 * Recuerda qué modo de lectura usó el usuario por última vez en cada libro.
 * Al reabrir un libro se restaura su modo (una novela no pide el modo paper).
 */
const KEY = "riel-mode-per-book";

export function getBookMode(bookId: string): ModePresetId | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const map = JSON.parse(raw) as Record<string, ModePresetId>;
    return map[bookId] ?? null;
  } catch {
    return null;
  }
}

export function setBookMode(bookId: string, preset: ModePresetId) {
  try {
    const raw = localStorage.getItem(KEY);
    const map = (raw ? JSON.parse(raw) : {}) as Record<string, ModePresetId>;
    map[bookId] = preset;
    localStorage.setItem(KEY, JSON.stringify(map));
  } catch {
    /* noop */
  }
}
