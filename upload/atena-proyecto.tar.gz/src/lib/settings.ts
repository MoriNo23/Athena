"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  AppSettings,
  FilterPreset,
  FilterSettings,
  ImmersionSettings,
  MODE_PRESETS,
  ModePresetId,
  ModeToggleKey,
  ModeToggles,
  RailPosition,
  RailSettings,
  RailTheme,
  ReadingSettings,
  VnSettings,
  VocabEntry,
  VN_DEFAULT_PRESET,
} from "@/lib/types";

export interface ModesSettings {
  preset: ModePresetId;
  toggles: ModeToggles;
  /** la configuración propia que el usuario guardó como su preset Custom */
  customSaved: ModeToggles | null;
  /** minutos de sesión para la sugerencia de pausa en cortes naturales */
  pauseMinutes: number;
}

interface SettingsStore extends AppSettings {
  modes: ModesSettings;
  vocabulary: VocabEntry[];
  setRail: (patch: Partial<RailSettings>) => void;
  setFilters: (patch: Partial<FilterSettings>) => void;
  setPreset: (preset: FilterPreset) => void;
  setReading: (patch: Partial<ReadingSettings>) => void;
  setImmersion: (patch: Partial<ImmersionSettings>) => void;
  setModePreset: (preset: ModePresetId) => void;
  toggleMode: (key: ModeToggleKey) => void;
  saveCustomPreset: () => void;
  setPauseMinutes: (minutes: number) => void;
  setVn: (patch: Partial<VnSettings>) => void;
  addVocab: (entry: VocabEntry) => void;
  removeVocab: (id: string) => void;
  reset: () => void;
}

const defaultSettings: AppSettings = {
  rail: {
    position: "left",
    segments: 10,
    theme: "egeo",
    showLabels: true,
    celebrate: true,
  },
  filters: {
    preset: "papel",
    brightness: 103,
    contrast: 96,
    sepia: 18,
    saturate: 95,
    warmth: 22,
    invert: 0,
  },
  reading: {
    dailyGoal: 20,
    scrollStepPct: 40, // ~2-3 pulsaciones de ↑/↓ por pantalla
    wheelBoost: 1, // rueda nativa del navegador
  },
  immersion: {
    enabled: true,
    idleSeconds: 4,
    toggleKey: "h",
  },
  vn: {
    speedPreset: VN_DEFAULT_PRESET,
    sound: true,
    auto: false,
  },
};

const defaultModes: ModesSettings = {
  preset: "tecnico",
  toggles: { ...MODE_PRESETS.tecnico.toggles },
  customSaved: null,
  pauseMinutes: 25,
};

export const useSettings = create<SettingsStore>()(
  persist(
    (set) => ({
      ...defaultSettings,
      modes: defaultModes,
      vocabulary: [],
      setRail: (patch) =>
        set((s) => ({ rail: { ...s.rail, ...patch } })),
      setFilters: (patch) =>
        set((s) => ({ filters: { ...s.filters, ...patch, preset: "custom" as FilterPreset } })),
      setPreset: (preset) =>
        set((s) => ({ filters: { ...s.filters, ...patchOf(s.filters, preset) } })),
      setReading: (patch) =>
        set((s) => ({ reading: { ...s.reading, ...patch } })),
      setImmersion: (patch) =>
        set((s) => ({ immersion: { ...s.immersion, ...patch } })),
      setModePreset: (preset) =>
        set((s) => ({
          modes: {
            ...s.modes,
            preset,
            // Custom usa la config guardada si existe; si no, se queda con la actual
            toggles:
              preset === "custom"
                ? s.modes.customSaved ?? s.modes.toggles
                : { ...MODE_PRESETS[preset].toggles },
          },
        })),
      toggleMode: (key) =>
        set((s) => ({
          modes: {
            ...s.modes,
            // cualquier cambio manual pasa a Custom (sin borrar lo guardado)
            preset: "custom",
            toggles: { ...s.modes.toggles, [key]: !s.modes.toggles[key] },
          },
        })),
      saveCustomPreset: () =>
        set((s) => ({ modes: { ...s.modes, customSaved: { ...s.modes.toggles }, preset: "custom" } })),
      setPauseMinutes: (minutes) =>
        set((s) => ({ modes: { ...s.modes, pauseMinutes: Math.min(120, Math.max(5, Math.round(minutes))) } })),
      setVn: (patch) =>
        set((s) => ({ vn: { ...s.vn, ...patch } })),
      addVocab: (entry) =>
        set((s) => ({
          // sin duplicados por palabra+idioma
          vocabulary: s.vocabulary.some((v) => v.word.toLowerCase() === entry.word.toLowerCase() && v.lang === entry.lang)
            ? s.vocabulary
            : [entry, ...s.vocabulary].slice(0, 500),
        })),
      removeVocab: (id) => set((s) => ({ vocabulary: s.vocabulary.filter((v) => v.id !== id) })),
      reset: () => set({ ...defaultSettings, modes: defaultModes }),
    }),
    {
      name: "riel-settings-v1",
      version: 8,
      migrate: (persisted, version) => {
        const state = persisted as Partial<AppSettings> & {
          filters?: Partial<FilterSettings>;
          modes?: Partial<ModesSettings>;
          vn?: Partial<VnSettings>;
        };
        // Al venir de versiones sin el campo invert, preserva la intención del preset noche
        const storedInvert = state.filters?.invert;
        const legacyInvert =
          storedInvert != null && storedInvert > 0
            ? storedInvert
            : state.filters?.preset === "noche"
              ? 92
              : 0;
        const base = {
          ...defaultSettings,
          ...state,
          filters: { ...defaultSettings.filters, ...state.filters, invert: legacyInvert },
          // v7: navegación configurable — los objetos viejos no traen los campos nuevos
          reading: { ...defaultSettings.reading, ...state.reading },
          immersion: { ...defaultSettings.immersion, ...state.immersion },
          // v8: modo novela visual
          vn: { ...defaultSettings.vn, ...state.vn },
          modes: { ...defaultModes, ...state.modes } as ModesSettings,
        } as AppSettings & { modes: ModesSettings };
        // v4: introduce la barra dinámica estilo Duolingo como modo de color
        if (version < 4) {
          base.rail = { ...base.rail, theme: "dynamic" };
        }
        // v8: la casa viste de azul Atenas — el riel migrá al tema Egeo
        if (version < 8) {
          base.rail = { ...base.rail, theme: "egeo" };
        }
        // v5: modos de lectura + vocabulario
        if (version < 5) {
          base.modes = { ...defaultModes };
        }
        return base;
      },
    }
  )
);

/** Filtra el objeto de filtros al activar un preset (mantiene compatibilidad) */
function patchOf(current: FilterSettings, preset: FilterPreset): FilterSettings {
  const table: Record<FilterPreset, FilterSettings> = {
    normal: { preset: "normal", brightness: 100, contrast: 100, sepia: 0, saturate: 100, warmth: 0, invert: 0 },
    papel: { preset: "papel", brightness: 103, contrast: 96, sepia: 18, saturate: 95, warmth: 22, invert: 0 },
    sepia: { preset: "sepia", brightness: 100, contrast: 97, sepia: 50, saturate: 90, warmth: 30, invert: 0 },
    noche: { preset: "noche", brightness: 94, contrast: 105, sepia: 0, saturate: 85, warmth: 0, invert: 92 },
    calido: { preset: "calido", brightness: 97, contrast: 100, sepia: 28, saturate: 105, warmth: 45, invert: 0 },
    custom: { ...current, preset: "custom" },
  };
  return table[preset];
}

/** Utilidad: estilo CSS filter a partir de FilterSettings */
export function filterCss(f: FilterSettings): string {
  if (f.preset === "normal") return "none";
  const inv = f.invert ?? 0;
  const parts = [
    inv > 0 ? `invert(${inv / 100}) hue-rotate(180deg)` : "",
    `brightness(${f.brightness}%)`,
    `contrast(${f.contrast}%)`,
    f.sepia > 0 ? `sepia(${f.sepia / 100})` : "",
    `saturate(${f.saturate}%)`,
  ].filter(Boolean);
  return parts.length ? parts.join(" ") : "none";
}
