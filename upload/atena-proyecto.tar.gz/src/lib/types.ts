export interface BadgeDTO {
  tier: number; // 1 Bronce · 2 Plata · 3 Oro · 4 Diamante
  readings: number;
  earnedAt: string;
  updatedAt?: string;
}

export interface BookDTO {
  id: string;
  title: string;
  author: string | null;
  fileName: string;
  filePath: string;
  coverPath: string | null;
  totalPages: number;
  currentPage: number;
  /** tramos/hitos de este libro; null = usar el global de ajustes */
  milestones: number | null;
  /** PDF compañero para lectura dual (traducción u otra edición) */
  companionPath: string | null;
  companionPages: number | null;
  /** datos de los modos de lectura, por libro */
  extras: BookExtras | null;
  /** colección de insignias: cuándo terminó el libro y cuántas lecturas completas lleva */
  finishedAt: string | null;
  readCount: number;
  badge: BadgeDTO | null;
  createdAt: string;
  lastReadAt: string | null;
}

// ---------- Insignias ----------

export const BADGE_TIERS: Record<number, { key: string; label: string; hint: string }> = {
  1: { key: "bronce", label: "Bronce", hint: "1 lectura completada" },
  2: { key: "plata", label: "Plata", hint: "2 lecturas completadas" },
  3: { key: "oro", label: "Oro", hint: "3 lecturas completadas" },
  4: { key: "diamante", label: "Diamante", hint: "4 o más lecturas" },
};

/** Tier que corresponde a N lecturas completadas (tope: Diamante) */
export function tierForReadings(readings: number): number {
  return Math.min(4, Math.max(1, Math.round(readings)));
}

// ---------- Modos de lectura ----------

/** Subfeatures activables; T = corriente técnica, L = corriente literatura, C = común */
export interface ModeToggles {
  threePass: boolean; // [T] lectura en tres pasadas (Keshav)
  notation: boolean; // [T] notación viva: tabla de símbolos
  codeRunner: boolean; // [T] código que se ejecuta al lado
  resultsTable: boolean; // [T] tabla viva de resultados
  reproAudit: boolean; // [T] auditoría de reproducibilidad
  xray: boolean; // [L] fichas que siguen tu punto de lectura
  naturalPauses: boolean; // [L] pausas en cortes naturales
  argumentSkeleton: boolean; // [L] esqueleto argumental + predicción
  lockedNotes: boolean; // [L] notas con candado de spoilers
  dualRead: boolean; // [L] dos ediciones/traducciones a la vez
  outline: boolean; // [C] esquema del PDF (índice navegable)
  dictionary: boolean; // [C] definir palabra al seleccionarla
}

export type ModePresetId = "tecnico" | "literatura" | "custom";
export type ModeToggleKey = keyof ModeToggles;

export const MODE_PRESETS: Record<
  ModePresetId,
  { label: string; tagline: string; toggles: ModeToggles }
> = {
  tecnico: {
    label: "Técnico",
    tagline: "Papers y libros técnicos: el lector busca algo. La app suma capas.",
    toggles: {
      threePass: true,
      notation: true,
      codeRunner: true,
      resultsTable: true,
      reproAudit: true,
      xray: false,
      naturalPauses: false,
      argumentSkeleton: false,
      lockedNotes: false,
      dualRead: false,
      outline: true,
      dictionary: true,
    },
  },
  literatura: {
    label: "Literatura",
    tagline: "Novelas y ensayos: el lector sigue algo. La app quita fricción.",
    toggles: {
      threePass: false,
      notation: false,
      codeRunner: false,
      resultsTable: false,
      reproAudit: false,
      xray: true,
      naturalPauses: true,
      argumentSkeleton: true,
      lockedNotes: true,
      dualRead: true,
      outline: true,
      dictionary: true,
    },
  },
  custom: {
    label: "Custom",
    tagline: "Tu propia configuración guardada.",
    toggles: {
      threePass: false,
      notation: false,
      codeRunner: false,
      resultsTable: false,
      reproAudit: false,
      xray: false,
      naturalPauses: false,
      argumentSkeleton: false,
      lockedNotes: false,
      dualRead: false,
      outline: true,
      dictionary: true,
    },
  },
};

export const MODE_TOGGLE_META: Record<
  ModeToggleKey,
  { label: string; stream: "T" | "L" | "C"; hint: string }
> = {
  threePass: { label: "Tres pasadas", stream: "T", hint: "Guía Keshav: decidir → entender → reconstruir" },
  notation: { label: "Notación viva", stream: "T", hint: "Símbolos con su definición y página" },
  codeRunner: { label: "Código al lado", stream: "T", hint: "Ejecuta ejemplos JS en un sandbox" },
  resultsTable: { label: "Tabla de resultados", stream: "T", hint: "Compara métricas mientras lees" },
  reproAudit: { label: "Auditoría de reproducibilidad", stream: "T", hint: "Qué falta para reproducir el experimento" },
  xray: { label: "Fichas (X-Ray)", stream: "L", hint: "Quién aparece hasta donde llegaste, sin spoilers" },
  naturalPauses: { label: "Pausas en cortes", stream: "L", hint: "Te sugiere pausar al terminar la página, nunca a mitad" },
  argumentSkeleton: { label: "Esqueleto + predicción", stream: "L", hint: "Predice la tesis y compárala al final" },
  lockedNotes: { label: "Notas con candado", stream: "L", hint: "Notas futuras, veladas hasta llegar" },
  dualRead: { label: "Lectura dual", stream: "L", hint: "Dos ediciones o idiomas lado a lado" },
  outline: { label: "Esquema del PDF", stream: "C", hint: "Índice navegable si el PDF lo trae" },
  dictionary: { label: "Diccionario", stream: "C", hint: "Selecciona una palabra para definirla (ES/EN)" },
};

// ---------- Extras por libro (persistidos en BD) ----------

export interface SymbolEntry {
  id: string;
  symbol: string;
  meaning: string;
  page: number;
}

export interface ResultEntry {
  id: string;
  method: string;
  dataset: string;
  metric: string;
  value: string;
  page: number | null;
}

export type ReproState = "pendiente" | "ok" | "na";

export interface XrayCard {
  id: string;
  name: string;
  aliases: string;
  note: string;
  unlockPage: number; // aparece desde esta página
}

export interface LockedNote {
  id: string;
  text: string;
  unlockPage: number; // se desbloquea en esta página
  createdAt: string;
}

export interface BookExtras {
  threePass?: {
    checked: Record<string, boolean>; // "p1-0", "p2-1"...
    notes: string;
  };
  notation?: SymbolEntry[];
  codeSnippet?: { code: string };
  results?: ResultEntry[];
  repro?: { states: Record<string, ReproState>; notes: string };
  xray?: XrayCard[];
  pause?: { recap: string; pausesTaken: number };
  prediction?: { text: string; savedAt: string };
  conclusion?: { text: string; savedAt: string };
  lockedNotes?: LockedNote[];
}

// ---------- Vocabulario global ----------

export interface VocabEntry {
  id: string;
  word: string;
  lang: "es" | "en";
  short: string; // definición recortada
  bookId: string;
  bookTitle: string;
  page: number;
  createdAt: string;
}

// ---------- Diccionario (respuesta normalizada del proxy) ----------

export interface DictDef {
  d: string;
  ex?: string;
}

export interface DictEntry {
  pos: string; // categoría gramatical legible
  defs: DictDef[];
  synonyms?: string[];
}

export interface DictionaryResult {
  word: string;
  lang: "es" | "en";
  found: boolean;
  phonetic?: string;
  audio?: string;
  origin?: string;
  entries: DictEntry[];
  source: string;
}

export interface SessionDTO {
  id: string;
  bookId: string;
  pagesRead: number;
  minutes: number;
  date: string;
}

export interface GlobalStats {
  streak: number;
  pagesToday: number;
  minutesToday: number;
  pages7d: number;
  minutes7d: number;
  days7d: number;
  booksFinished: number;
}

export type ZoomPresetId = "optimal" | "page" | "wide" | "mid" | "far";

export type RailPosition = "bottom" | "top" | "left" | "right";

export type RailTheme = "egeo" | "dynamic" | "amber" | "emerald" | "rose" | "violet" | "cyan";

export type FilterPreset =
  | "normal"
  | "papel"
  | "sepia"
  | "noche"
  | "calido"
  | "custom";

export interface FilterSettings {
  preset: FilterPreset;
  brightness: number; // %
  contrast: number; // %
  sepia: number; // %
  saturate: number; // %
  warmth: number; // 0-100 opacidad del tinte cálido superpuesto
  invert: number; // 0-100 inversión de colores (modo noche)
}

export interface RailSettings {
  position: RailPosition;
  segments: number; // nº de tramos = nº de hitos
  theme: RailTheme;
  showLabels: boolean;
  celebrate: boolean;
}

export interface ReadingSettings {
  dailyGoal: number; // páginas/día
  /** salto de scroll con ↑/↓ como % del alto visible del visor (10-100) */
  scrollStepPct: number;
  /** multiplicador de la rueda del mouse (1 = rueda nativa del navegador) */
  wheelBoost: number;
}

/** Modo inmersión: la interfaz se desvanece si el mouse queda quieto */
export interface ImmersionSettings {
  enabled: boolean;
  idleSeconds: number; // 2-12 s de inactividad antes de ocultar
  /** tecla que oculta/muestra la interfaz al instante (independiente del mouse) */
  toggleKey: string;
}

/** Modo novela visual: tarjetas a pantalla completa que se encienden letra a letra */
export interface VnSettings {
  /** id del preset de velocidad (VN_SPEED_PRESETS en src/lib/vn.ts) */
  speedPreset: string;
  /** tic de tipeo por letra */
  sound: boolean;
  /** modo auto: al terminar una tarjeta avanza solo (y gira la página al acabar) */
  auto: boolean;
}

export interface AppSettings {
  rail: RailSettings;
  filters: FilterSettings;
  reading: ReadingSettings;
  immersion: ImmersionSettings;
  vn: VnSettings;
}

// ---------- Modo novela visual: velocidades ----------

export interface VnSpeedPreset {
  id: string;
  label: string;
  /** palabras por segundo; null = Instantánea (todo de golpe) */
  wps: number | null;
}

export const VN_SPEED_PRESETS: VnSpeedPreset[] = [
  { id: "0-8", label: "Contemplativa · 0,8 pal/s", wps: 0.8 },
  { id: "1-5", label: "Lenta · 1,5 pal/s", wps: 1.5 },
  { id: "2-5", label: "Natural · 2,5 pal/s", wps: 2.5 },
  { id: "4", label: "Viva · 4 pal/s", wps: 4 },
  { id: "instant", label: "Instantánea", wps: null },
];

export const VN_DEFAULT_PRESET = "1-5";

export function vnPresetById(id: string): VnSpeedPreset {
  return VN_SPEED_PRESETS.find((p) => p.id === id) ?? VN_SPEED_PRESETS[1];
}

export const RAIL_THEMES: Record<
  RailTheme,
  { label: string; fill: string; fillV: string; glow: string; cursor: string; soft: string }
> = {
  egeo: {
    label: "Egeo",
    // Azul Atenas: de abismo a espuma del mar Egeo según avanza la lectura
    fill: "linear-gradient(90deg, oklch(0.5 0.12 260), oklch(0.72 0.12 235))",
    fillV: "linear-gradient(0deg, oklch(0.5 0.12 260), oklch(0.72 0.12 235))",
    glow: "oklch(0.7 0.13 240 / 55%)",
    cursor: "oklch(0.82 0.11 235)",
    soft: "oklch(0.7 0.13 240 / 14%)",
  },
  dynamic: {
    label: "Dinámico (progreso)",
    // El color lo calcula RailBar según el avance (naranja → verde);
    // estos valores son la referencia para swatches y glow base.
    fill: "linear-gradient(90deg, oklch(0.75 0.14 55), oklch(0.8 0.15 145))",
    fillV: "linear-gradient(0deg, oklch(0.75 0.14 55), oklch(0.8 0.15 145))",
    glow: "oklch(0.8 0.15 130 / 55%)",
    cursor: "oklch(0.85 0.16 130)",
    soft: "oklch(0.8 0.15 130 / 14%)",
  },
  amber: {
    label: "Ámbar",
    fill: "linear-gradient(90deg, oklch(0.72 0.12 75), oklch(0.83 0.14 85))",
    fillV: "linear-gradient(0deg, oklch(0.72 0.12 75), oklch(0.83 0.14 85))",
    glow: "oklch(0.79 0.13 82 / 55%)",
    cursor: "oklch(0.85 0.15 85)",
    soft: "oklch(0.79 0.13 82 / 14%)",
  },
  emerald: {
    label: "Esmeralda",
    fill: "linear-gradient(90deg, oklch(0.6 0.12 150), oklch(0.76 0.15 155))",
    fillV: "linear-gradient(0deg, oklch(0.6 0.12 150), oklch(0.76 0.15 155))",
    glow: "oklch(0.72 0.14 145 / 55%)",
    cursor: "oklch(0.8 0.15 152)",
    soft: "oklch(0.72 0.14 145 / 14%)",
  },
  rose: {
    label: "Rosa",
    fill: "linear-gradient(90deg, oklch(0.62 0.15 15), oklch(0.75 0.16 22))",
    fillV: "linear-gradient(0deg, oklch(0.62 0.15 15), oklch(0.75 0.16 22))",
    glow: "oklch(0.7 0.16 25 / 55%)",
    cursor: "oklch(0.78 0.16 22)",
    soft: "oklch(0.7 0.16 25 / 14%)",
  },
  violet: {
    label: "Violeta",
    fill: "linear-gradient(90deg, oklch(0.58 0.15 300), oklch(0.72 0.15 310))",
    fillV: "linear-gradient(0deg, oklch(0.58 0.15 300), oklch(0.72 0.15 310))",
    glow: "oklch(0.72 0.14 310 / 55%)",
    cursor: "oklch(0.78 0.14 312)",
    soft: "oklch(0.72 0.14 310 / 14%)",
  },
  cyan: {
    label: "Turquesa",
    fill: "linear-gradient(90deg, oklch(0.6 0.1 195), oklch(0.78 0.12 200))",
    fillV: "linear-gradient(0deg, oklch(0.6 0.1 195), oklch(0.78 0.12 200))",
    glow: "oklch(0.78 0.12 200 / 55%)",
    cursor: "oklch(0.82 0.12 202)",
    soft: "oklch(0.78 0.12 200 / 14%)",
  },
};

/**
 * Tema dinámico estilo Duolingo: el color del tramo avanza por una rampa
 * cálida → verde según el avance global del libro. Devuelve color oklch.
 */
export function dynamicSegmentColor(progressInSegment: number, overallProgress: number): string {
  const p = Math.min(1, Math.max(0, overallProgress));
  // Hue: 55 (ámbar/naranja) al empezar → 150 (verde) cerca del final
  const hue = 55 + (150 - 55) * p;
  // El tramo activo se aclara un poco a medida que se llena (feedback sutil)
  const light = 0.7 + 0.1 * Math.min(1, Math.max(0, progressInSegment));
  const chroma = 0.13 + 0.03 * p;
  return `oklch(${light.toFixed(3)} ${chroma.toFixed(3)} ${hue.toFixed(1)})`;
}

export function dynamicCursorColor(overallProgress: number): string {
  const p = Math.min(1, Math.max(0, overallProgress));
  const hue = 55 + (150 - 55) * p;
  return `oklch(0.85 0.16 ${hue.toFixed(1)})`;
}

export const FILTER_PRESETS: Record<
  FilterPreset,
  { label: string; filters: FilterSettings; css: string }
> = {
  normal: {
    label: "Normal",
    css: "none",
    filters: { preset: "normal", brightness: 100, contrast: 100, sepia: 0, saturate: 100, warmth: 0, invert: 0 },
  },
  papel: {
    label: "Papel",
    css: "brightness(1.03) contrast(0.96) sepia(0.18) saturate(0.95)",
    filters: { preset: "papel", brightness: 103, contrast: 96, sepia: 18, saturate: 95, warmth: 22, invert: 0 },
  },
  sepia: {
    label: "Sepia",
    css: "brightness(1.0) contrast(0.97) sepia(0.5) saturate(0.9)",
    filters: { preset: "sepia", brightness: 100, contrast: 97, sepia: 50, saturate: 90, warmth: 30, invert: 0 },
  },
  noche: {
    label: "Noche",
    css: "invert(0.92) hue-rotate(180deg) brightness(0.94) contrast(1.05) saturate(0.85)",
    filters: { preset: "noche", brightness: 94, contrast: 105, sepia: 0, saturate: 85, warmth: 0, invert: 92 },
  },
  calido: {
    label: "Cálido",
    css: "brightness(0.97) contrast(1.0) sepia(0.28) saturate(1.05)",
    filters: { preset: "calido", brightness: 97, contrast: 100, sepia: 28, saturate: 105, warmth: 45, invert: 0 },
  },
  custom: {
    label: "Personalizado",
    css: "none",
    filters: { preset: "custom", brightness: 100, contrast: 100, sepia: 0, saturate: 100, warmth: 0, invert: 0 },
  },
};
