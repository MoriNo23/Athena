"use client";

import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { useSettings } from "@/lib/settings";
import { BadgeShelf } from "@/components/library/BadgeShelf";
import { EditBookDialog } from "@/components/library/EditBookDialog";
import { BookCard } from "@/components/library/BookCard";
import { LibraryConfirmDialogs } from "@/components/library/LibraryConfirmDialogs";
import { useLibraryBooks } from "@/hooks/use-library-books";
import { useBookUpload } from "@/hooks/use-book-upload";
import { useBookActions } from "@/hooks/use-book-actions";
import { formatMinutes } from "@/lib/reading";
import {
  Clock3,
  Flame,
  Loader2,
  Plus,
  RotateCcw,
  Target,
  Trophy,
  UploadCloud,
} from "lucide-react";
import type { BookDTO } from "@/lib/types";

export type { BookWithSessions } from "@/hooks/use-library-books";

/** Sello de Atena: columna dórica geométrica en marco cuadrado.
    Minimalista y brutalista — piedra, no caricatura. */
function AtenaSeal({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden>
      {/* marco del sello */}
      <rect x="6" y="6" width="52" height="52" stroke="currentColor" strokeWidth="2.6" />
      {/* capitel: ábaco + equino */}
      <rect x="21" y="15" width="22" height="3.6" stroke="currentColor" strokeWidth="2.2" />
      <line x1="24" y1="22.5" x2="40" y2="22.5" stroke="currentColor" strokeWidth="2.2" />
      {/* fuste con tres estrías */}
      <line x1="26.5" y1="22.5" x2="26.5" y2="41.5" stroke="currentColor" strokeWidth="2.2" />
      <line x1="32" y1="22.5" x2="32" y2="41.5" stroke="currentColor" strokeWidth="2.2" />
      <line x1="37.5" y1="22.5" x2="37.5" y2="41.5" stroke="currentColor" strokeWidth="2.2" />
      {/* basa y estilóbato */}
      <line x1="24" y1="45.5" x2="40" y2="45.5" stroke="currentColor" strokeWidth="2.2" />
      <line x1="18" y1="50.5" x2="46" y2="50.5" stroke="currentColor" strokeWidth="2.2" />
    </svg>
  );
}

interface LibraryViewProps {
  onOpen: (book: BookDTO) => void;
}

export function LibraryView({ onOpen }: LibraryViewProps) {
  const rail = useSettings((s) => s.rail);
  const dailyGoal = useSettings((s) => s.reading.dailyGoal);

  const { books, fetchBooks, updateBook, stats } = useLibraryBooks();

  // Carga inicial de la biblioteca
  useEffect(() => {
    fetchBooks();
  }, [fetchBooks]);

  const {
    dragOver,
    setDragOver,
    probing,
    uploading,
    uploadPct,
    uploadPhase,
    pendingFile,
    setPendingFile,
    formTitle,
    setFormTitle,
    formAuthor,
    setFormAuthor,
    fileInputRef,
    startUploadFlow,
    confirmUpload,
  } = useBookUpload({ onUploaded: fetchBooks });
  const {
    deleteTarget,
    setDeleteTarget,
    editTarget,
    setEditTarget,
    resetTarget,
    setResetTarget,
    resetAllOpen,
    setResetAllOpen,
    resettingAll,
    resettingOne,
    confirmDelete,
    confirmReset,
    confirmResetAll,
  } = useBookActions({ onBooksChanged: fetchBooks });

  return (
    <div className="mx-auto w-full max-w-6xl px-8 py-8">
      {/* ---- Hero de Atenea ---- */}
      <header className="atena-hero mb-8 flex items-center justify-between gap-6 px-8 py-7 animate-fade-up">
        <div className="flex min-w-0 items-center gap-5">
          <AtenaSeal className="seal-glow h-16 w-16 shrink-0 text-primary" />
          <div className="min-w-0">
            <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-primary/80">
              Casa de la sabiduría
            </p>
            <h1 className="font-display text-4xl font-semibold tracking-tight">Atena</h1>
            <p className="mt-1 max-w-xl text-sm text-muted-foreground">
              La diosa de la estrategia custodia tu biblioteca: riel de progreso, hitos, racha y un
              modo novela que enciende las páginas letra a letra.
            </p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10 text-muted-foreground hover:text-foreground"
            onClick={() => setResetAllOpen(true)}
            aria-label="Reiniciar todo el progreso"
            title="Reiniciar todo el progreso"
            data-testid="reset-all"
          >
            <RotateCcw className="h-4.5 w-4.5" />
          </Button>
          <Button size="lg" className="gap-2 shadow-lg shadow-primary/20" onClick={() => fileInputRef.current?.click()}>
            <Plus className="h-5 w-5" /> Añadir libro
          </Button>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept="application/pdf,.pdf"
          className="hidden"
          onChange={(e) => {
            void startUploadFlow(e.target.files?.[0]);
            e.target.value = "";
          }}
        />
      </header>

      {/* ---- Franja de hábitos ---- */}
      <section className="mb-8 grid grid-cols-4 gap-4 animate-fade-up" style={{ animationDelay: "60ms" }}>
        <StatCard icon={<Flame className="h-4.5 w-4.5 text-primary" />} label="Racha" value={`${stats.streak} ${stats.streak === 1 ? "día" : "días"}`} hint={stats.streak > 1 ? "¡No la rompas hoy!" : "Lee hoy para empezar"} />
        <StatCard icon={<Target className="h-4.5 w-4.5 text-primary" />} label="Meta diaria" value={`${stats.pagesToday}/${dailyGoal} pág`} hint={stats.pagesToday >= dailyGoal ? "¡Meta cumplida! 🏆" : `${Math.max(0, dailyGoal - stats.pagesToday)} para cumplirla`} />
        <StatCard icon={<Clock3 className="h-4.5 w-4.5 text-primary" />} label="Tiempo hoy" value={formatMinutes(stats.minutesToday)} hint="Cada minuto cuenta" />
        <StatCard icon={<Trophy className="h-4.5 w-4.5 text-primary" />} label="Libros terminados" value={String(stats.finished)} hint={`de ${books?.length ?? 0} en tu biblioteca`} />
      </section>

      {/* ---- Insignias (colección) ---- */}
      {books !== null && books.length > 0 && <BadgeShelf books={books} onOpen={onOpen} />}

      {/* ---- Zona de subida ---- */}
      <section
        className={`mb-8 rounded-xl border border-dashed p-6 text-center transition-all animate-fade-up ${
          dragOver ? "border-primary bg-primary/8 scale-[1.01]" : "border-border/70 hover:border-primary/40"
        }`}
        style={{ animationDelay: "120ms" }}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          void startUploadFlow(e.dataTransfer.files?.[0]);
        }}
      >
        {probing ? (
          <div className="flex items-center justify-center gap-3 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Analizando el PDF…
          </div>
        ) : (
          <>
            <UploadCloud className="mx-auto mb-2 h-6 w-6 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              Arrastra un <span className="text-foreground font-medium">PDF</span> aquí o{" "}
              <button className="text-primary underline-offset-4 hover:underline" onClick={() => fileInputRef.current?.click()}>
                elige un archivo
              </button>{" "}
              · tu progreso se guarda solo
            </p>
          </>
        )}
      </section>

      {/* ---- Biblioteca ---- */}
      <section>
        {books === null ? (
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-36 rounded-xl" />
            ))}
          </div>
        ) : books.length === 0 ? (
          <div className="rounded-xl border border-border/60 bg-card/40 px-6 py-14 text-center animate-fade-up">
            <h2 className="font-display text-2xl font-medium">Tu biblioteca está vacía</h2>
            <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">
              Sube tu primer PDF y divídelo en tramos: verás el riel llenarse a cada página,
              hitos que se celebran y una fecha de finalización a tu ritmo. Empezar es la parte difícil; el riel hace el resto.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {books.map((book, idx) => (
              <BookCard
                key={book.id}
                book={book}
                segments={book.milestones ?? rail.segments}
                theme={rail.theme}
                onOpen={() => onOpen(book)}
                onDelete={() => setDeleteTarget(book)}
                onEdit={() => setEditTarget(book)}
                onReset={() => setResetTarget(book)}
                style={{ animationDelay: `${140 + idx * 50}ms` }}
              />
            ))}
          </div>
        )}
      </section>

      {/* ---- Diálogo de subida ---- */}
      <Dialog open={!!pendingFile} onOpenChange={(open) => !open && !uploading && setPendingFile(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">Nuevo libro en el riel</DialogTitle>
            <DialogDescription>
              {pendingFile ? `${pendingFile.numPages} páginas detectadas` : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="flex gap-4">
              {pendingFile?.cover && (
                <img
                  src={pendingFile.cover}
                  alt="Portada generada"
                  className="h-36 w-auto rounded-md border border-border/60 page-frame"
                />
              )}
              <div className="grid flex-1 content-center gap-4">
                <div className="grid gap-1.5">
                  <Label htmlFor="book-title">Título</Label>
                  <Input id="book-title" value={formTitle} onChange={(e) => setFormTitle(e.target.value)} placeholder="Título del libro" />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="book-author">Autor (opcional)</Label>
                  <Input id="book-author" value={formAuthor} onChange={(e) => setFormAuthor(e.target.value)} placeholder="Nombre del autor" />
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <div className="w-full">
              {uploading && (
                <div className="mb-3 grid gap-1.5" data-testid="upload-progress">
                  <Progress value={uploadPct} role="progressbar" aria-label="Progreso de subida del PDF" />
                  <p className="text-xs text-muted-foreground">
                    {uploadPhase === "saving"
                      ? "Guardando en el riel…"
                      : `Subiendo… ${uploadPct}%`}
                  </p>
                </div>
              )}
              <div className="flex justify-end gap-2">
                <Button variant="ghost" onClick={() => setPendingFile(null)} disabled={uploading}>
                  Cancelar
                </Button>
                <Button onClick={() => void confirmUpload()} disabled={uploading || !formTitle.trim()} className="gap-2">
                  {uploading && <Loader2 className="h-4 w-4 animate-spin" />}
                  {uploading ? "Subiendo…" : "Añadir al riel"}
                </Button>
              </div>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---- Edición de ficha (título/autor/portada real) ---- */}
      <EditBookDialog
        book={editTarget}
        open={!!editTarget}
        onOpenChange={(o) => !o && setEditTarget(null)}
        onSaved={(saved) =>
          updateBook({
            id: saved.id,
            title: saved.title,
            author: saved.author,
            coverPath: saved.coverPath,
          })
        }
      />

      {/* ---- Confirmaciones destructivas ---- */}
      <LibraryConfirmDialogs
        deleteTarget={deleteTarget}
        onClearDelete={() => setDeleteTarget(null)}
        onConfirmDelete={() => void confirmDelete()}
        resetTarget={resetTarget}
        onClearReset={() => setResetTarget(null)}
        onConfirmReset={() => void confirmReset()}
        resettingOne={resettingOne}
        resetAllOpen={resetAllOpen}
        onResetAllOpenChange={setResetAllOpen}
        onConfirmResetAll={() => void confirmResetAll()}
        resettingAll={resettingAll}
      />
    </div>
  );
}

function StatCard({ icon, label, value, hint }: { icon: React.ReactNode; label: string; value: string; hint: string }) {
  return (
    <div className="rounded-xl border border-border/60 bg-card/50 p-4">
      <div className="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
        {icon}
        {label}
      </div>
      <div className="font-display text-2xl font-semibold">{value}</div>
      <div className="mt-0.5 text-xs text-muted-foreground">{hint}</div>
    </div>
  );
}
