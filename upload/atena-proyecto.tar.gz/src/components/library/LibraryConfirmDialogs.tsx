"use client";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { BADGE_TIERS } from "@/lib/types";
import type { BookWithSessions } from "@/hooks/use-library-books";
import { Loader2 } from "lucide-react";

interface LibraryConfirmDialogsProps {
  deleteTarget: BookWithSessions | null;
  onClearDelete: () => void;
  onConfirmDelete: () => void;
  resetTarget: BookWithSessions | null;
  onClearReset: () => void;
  onConfirmReset: () => void;
  resettingOne: boolean;
  resetAllOpen: boolean;
  onResetAllOpenChange: (open: boolean) => void;
  onConfirmResetAll: () => void;
  resettingAll: boolean;
}

/** Confirmaciones destructivas: borrar libro, reiniciar sus lecturas y reiniciar todo */
export function LibraryConfirmDialogs({
  deleteTarget,
  onClearDelete,
  onConfirmDelete,
  resetTarget,
  onClearReset,
  onConfirmReset,
  resettingOne,
  resetAllOpen,
  onResetAllOpenChange,
  onConfirmResetAll,
  resettingAll,
}: LibraryConfirmDialogsProps) {
  return (
    <>
      {/* ---- Confirmación de borrado ---- */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && onClearDelete()}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar “{deleteTarget?.title}”?</AlertDialogTitle>
            <AlertDialogDescription>
              Se borrará el archivo y todo su progreso en el riel. Esta acción no se puede deshacer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Conservar</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-white hover:bg-destructive/90" onClick={onConfirmDelete}>
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ---- Confirmación de reinicio por libro ---- */}
      <AlertDialog open={!!resetTarget} onOpenChange={(open) => !open && onClearReset()}>
        <AlertDialogContent data-testid="reset-book-dialog">
          <AlertDialogHeader>
            <AlertDialogTitle>¿Reiniciar las lecturas de “{resetTarget?.title}”?</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-1.5">
                <p>Se borrará de este libro:</p>
                <ul className="list-disc space-y-0.5 pl-4">
                  <li>
                    Tu página actual (pág. {resetTarget?.currentPage} de {resetTarget?.totalPages})
                  </li>
                  <li>El historial de sesiones de lectura</li>
                  <li>
                    Su insignia{resetTarget?.badge ? ` (${BADGE_TIERS[resetTarget.badge.tier]?.label ?? ""} · ${resetTarget.badge.readings} lecturas)` : ""}, si la tiene
                  </li>
                </ul>
                <p className="pt-1 text-xs">
                  Se conservan el archivo, la ficha, la portada, los hitos y tus notas. No se puede deshacer.
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Conservar progreso</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={onConfirmReset}
              disabled={resettingOne}
              data-testid="reset-book-confirm"
            >
              {resettingOne ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              Reiniciar lecturas
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ---- Confirmación de reinicio total ---- */}
      <AlertDialog open={resetAllOpen} onOpenChange={onResetAllOpenChange}>
        <AlertDialogContent data-testid="reset-all-dialog">
          <AlertDialogHeader>
            <AlertDialogTitle>¿Reiniciar TODO el progreso?</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-1.5">
                <p>En todos los libros se borrará:</p>
                <ul className="list-disc space-y-0.5 pl-4">
                  <li>La página donde vas en cada libro (todos vuelven a la 1)</li>
                  <li>Todo el historial de sesiones — incluida tu racha</li>
                  <li>Toda la colección de insignias, con sus tiers</li>
                </ul>
                <p className="pt-1 text-xs">
                  Los archivos, fichas, portadas y notas se conservan. Esta acción no se puede deshacer.
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Conservar todo</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={onConfirmResetAll}
              disabled={resettingAll}
              data-testid="reset-all-confirm"
            >
              {resettingAll ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              Reiniciar todo
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
