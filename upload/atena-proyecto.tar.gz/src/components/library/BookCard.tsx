"use client";

import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { RailBar } from "@/components/rail/RailBar";
import { estimateFinishDate, formatDateEs, groupSessionsByDay, pickDailyRate, progressPct } from "@/lib/reading";
import { BADGE_TIERS, RailTheme } from "@/lib/types";
import type { BookWithSessions } from "@/hooks/use-library-books";
import { BookOpen, Medal, Pencil, RotateCcw, Trash2 } from "lucide-react";

interface BookCardProps {
  book: BookWithSessions;
  segments: number;
  theme: RailTheme;
  onOpen: () => void;
  onDelete: () => void;
  onEdit: () => void;
  onReset: () => void;
  style?: React.CSSProperties;
}

/** Tarjeta de libro de la biblioteca: portada, mini-riel, ritmo y acciones */
export function BookCard({ book, segments, theme, onOpen, onDelete, onEdit, onReset, style }: BookCardProps) {
  const pct = progressPct(book);
  const done = book.currentPage >= book.totalPages;

  const rate = useMemo(() => pickDailyRate(groupSessionsByDay(book.sessions)), [book.sessions]);
  const eta = useMemo(() => (rate ? estimateFinishDate(book, rate.pages) : null), [book, rate]);

  return (
    <article
      className="group flex gap-5 rounded-xl border border-border/60 bg-card/50 p-5 transition-all hover:border-primary/40 hover:bg-card/80 animate-fade-up"
      style={style}
    >
      <button
        className="relative h-40 w-28 shrink-0 overflow-hidden rounded-md border border-border/60 page-frame transition-transform group-hover:scale-[1.03]"
        onClick={onOpen}
        aria-label={`Abrir ${book.title}`}
      >
        {book.coverPath ? (
          <img src={book.coverPath} alt={`Portada de ${book.title}`} className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-secondary">
            <BookOpen className="h-8 w-8 text-muted-foreground" />
          </div>
        )}
        {done && (
          <div className="absolute inset-0 flex items-end justify-center bg-gradient-to-t from-black/70 to-transparent pb-2">
            <span className="rounded-full bg-primary px-2 py-0.5 text-[10px] font-semibold text-primary-foreground">
              TERMINADO
            </span>
          </div>
        )}
      </button>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="truncate font-display text-lg font-semibold leading-snug">{book.title}</h3>
            <p className="truncate text-sm text-muted-foreground">{book.author || "Autor desconocido"}</p>
            {book.badge && (
              <span className={`badge-chip tier-${BADGE_TIERS[book.badge.tier]?.key ?? "bronce"} mt-1.5`} data-testid="card-badge-chip">
                <Medal className="h-3 w-3" />
                {BADGE_TIERS[book.badge.tier]?.label ?? "Bronce"} · {book.badge.readings} {book.badge.readings === 1 ? "lectura" : "lecturas"}
              </span>
            )}
          </div>
          <div className="flex shrink-0 items-center gap-0.5">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground opacity-0 transition-opacity hover:text-foreground group-hover:opacity-100"
              onClick={onEdit}
              aria-label={`Editar ficha de ${book.title}`}
              title="Editar ficha y portada"
              data-testid="card-edit"
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground opacity-0 transition-opacity hover:text-foreground group-hover:opacity-100"
              onClick={onReset}
              aria-label={`Reiniciar lecturas de ${book.title}`}
              title="Reiniciar lecturas"
              data-testid="card-reset"
            >
              <RotateCcw className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 shrink-0 text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
              onClick={onDelete}
              aria-label={`Eliminar ${book.title}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="mt-3">
          <RailBar
            totalPages={book.totalPages}
            currentPage={book.currentPage}
            settings={{ position: "bottom", segments: Math.min(segments, 14), theme, showLabels: false, celebrate: false }}
            compact
          />
        </div>

        <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
          <span className="tabular-nums">
            pág. {book.currentPage} de {book.totalPages} · <span className="font-medium text-foreground">{pct}%</span>
          </span>
          {eta && !done && (
            <span className="italic">a tu ritmo, terminas el {formatDateEs(eta)}</span>
          )}
        </div>

        <div className="mt-auto pt-3">
          <Button onClick={onOpen} className="w-full gap-2" variant={done ? "secondary" : "default"}>
            <BookOpen className="h-4 w-4" />
            {done ? "Volver a leer" : book.currentPage > 1 ? "Continuar" : "Empezar a leer"}
          </Button>
        </div>
      </div>
    </article>
  );
}
