"use client";

import { useEffect, useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useSettings } from "@/lib/settings";
import { BookDTO, FilterPreset, RailPosition, RailTheme, RAIL_THEMES } from "@/lib/types";
import { RESERVED_HOTKEYS } from "@/hooks/use-reader-hotkeys";
import { BookMarked, Check, Eye, EyeOff, Keyboard, LayoutPanelLeft, MoveVertical, Mouse, RotateCcw, Sparkles, Target } from "lucide-react";

interface ConfigPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** libro abierto en el lector; habilita la sección de hitos individuales */
  book?: BookDTO | null;
  /** aplica cambios persistidos del libro (hitos individuales) */
  onPatchBook?: (patch: { milestones?: number | null }) => void;
}

const POSITIONS: { value: RailPosition; label: string }[] = [
  { value: "left", label: "Izquierda" },
  { value: "bottom", label: "Abajo" },
  { value: "top", label: "Arriba" },
  { value: "right", label: "Derecha" },
];

const PRESETS: { value: FilterPreset; label: string }[] = [
  { value: "normal", label: "Normal" },
  { value: "papel", label: "Papel" },
  { value: "sepia", label: "Sepia" },
  { value: "calido", label: "Cálido" },
  { value: "noche", label: "Noche" },
];

/** Etiqueta humana de una tecla (" " → Espacio, letras en mayúscula) */
function formatKey(k: string): string {
  if (k === " ") return "Espacio";
  if (k.length === 1) return k.toUpperCase();
  return k.charAt(0).toUpperCase() + k.slice(1);
}

export function ConfigPanel({ open, onOpenChange, book, onPatchBook }: ConfigPanelProps) {
  const rail = useSettings((s) => s.rail);
  const setRail = useSettings((s) => s.setRail);
  const filters = useSettings((s) => s.filters);
  const setFilters = useSettings((s) => s.setFilters);
  const setPreset = useSettings((s) => s.setPreset);
  const dailyGoal = useSettings((s) => s.reading.dailyGoal);
  const scrollStepPct = useSettings((s) => s.reading.scrollStepPct);
  const wheelBoost = useSettings((s) => s.reading.wheelBoost);
  const setReading = useSettings((s) => s.setReading);
  const immersion = useSettings((s) => s.immersion);
  const setImmersion = useSettings((s) => s.setImmersion);

  // Captura de la tecla de inmersión manual: la próxima tecla libre queda asignada
  const [capturing, setCapturing] = useState(false);
  const [keyHint, setKeyHint] = useState<string | null>(null);
  useEffect(() => {
    if (!capturing) return;
    const onKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.key === "Escape") {
        setCapturing(false);
        setKeyHint(null);
        return;
      }
      if (e.ctrlKey || e.metaKey || e.altKey) return; // combinaciones: se ignora
      if (RESERVED_HOTKEYS.has(e.key.toLowerCase())) {
        setKeyHint(`«${formatKey(e.key)}» ya dispara otra acción del lector`);
        return;
      }
      setImmersion({ toggleKey: e.key.length === 1 ? e.key.toLowerCase() : e.key });
      setCapturing(false);
      setKeyHint(null);
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [capturing, setImmersion]);

  const perBookActive = book?.milestones != null;
  const effectiveSegments = book?.milestones ?? rail.segments;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-sm">
        <SheetHeader>
          <SheetTitle className="font-display text-xl">Ajustes del riel</SheetTitle>
          <SheetDescription>
            Configura cómo se llena tu riel y cómo quieres leer. Todo se guarda solo.
          </SheetDescription>
        </SheetHeader>

        <div className="grid gap-7 px-4 pb-10">
          {/* ---------- El riel ---------- */}
          <section aria-label="Configuración del riel">
            <div className="mb-3 flex items-center gap-2">
              <LayoutPanelLeft className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-semibold uppercase tracking-wide">El riel</h3>
            </div>

            <div className="grid gap-5">
              {/* --- Hitos individuales de este libro --- */}
              {book && onPatchBook && (
                <div className="grid gap-3 rounded-lg border border-primary/25 bg-primary/5 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="gap-1.5 text-sm">
                        <BookMarked className="h-3.5 w-3.5 text-primary" /> Hitos de este libro
                      </Label>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        Cada libro guarda sus propios hitos
                      </p>
                    </div>
                    <Switch
                      checked={perBookActive}
                      onCheckedChange={(v) => onPatchBook({ milestones: v ? rail.segments : null })}
                      aria-label="Usar hitos personalizados para este libro"
                    />
                  </div>
                  {perBookActive ? (
                    <div className="grid gap-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">Tramos de «{book.title}»</span>
                        <span className="tabular-nums text-sm font-medium text-primary">{book.milestones}</span>
                      </div>
                      <Slider
                        value={[book.milestones ?? rail.segments]}
                        min={2}
                        max={40}
                        step={1}
                        onValueChange={([v]) => onPatchBook({ milestones: v })}
                        aria-label="Hitos de este libro"
                      />
                    </div>
                  ) : (
                    <p className="text-xs text-muted-foreground">
                      Hereda los {rail.segments} tramos globales. Activa el interruptor para
                      dividir «{book.title}» a tu manera.
                    </p>
                  )}
                </div>
              )}

              <div className="grid gap-2">
                <Label>Posición</Label>
                <div className="grid grid-cols-4 gap-1.5">
                  {POSITIONS.map((p) => (
                    <button
                      key={p.value}
                      onClick={() => setRail({ position: p.value })}
                      className={`rounded-md border px-2 py-1.5 text-xs transition-colors ${
                        rail.position === p.value
                          ? "border-primary bg-primary/15 text-primary font-medium"
                          : "border-border/70 text-muted-foreground hover:border-primary/40 hover:text-foreground"
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid gap-2">
                <div className="flex items-center justify-between">
                  <Label>Tramos globales</Label>
                  <span className="tabular-nums text-sm text-primary font-medium">{rail.segments}</span>
                </div>
                <Slider
                  value={[rail.segments]}
                  min={4}
                  max={24}
                  step={1}
                  onValueChange={([v]) => setRail({ segments: v })}
                  aria-label="Número de tramos por defecto"
                />
                <p className="text-xs text-muted-foreground">
                  {perBookActive
                    ? "Es el valor por defecto para libros nuevos; este libro usa los suyos."
                    : "Default para libros nuevos. Cada libro puede tener los suyos arriba."}
                </p>
              </div>

              <div className="grid gap-2">
                <Label>Color del riel</Label>
                <div className="flex gap-2">
                  {(Object.keys(RAIL_THEMES) as RailTheme[]).map((t) => (
                    <button
                      key={t}
                      title={RAIL_THEMES[t].label}
                      onClick={() => setRail({ theme: t })}
                      aria-label={`Color ${RAIL_THEMES[t].label}`}
                      className={`relative h-8 w-8 rounded-full ring-2 transition-all ${
                        rail.theme === t ? "ring-primary scale-110" : "ring-transparent hover:scale-105"
                      }`}
                      style={{ background: RAIL_THEMES[t].fill }}
                    >
                      {rail.theme === t && (
                        <Check className="absolute inset-0 m-auto h-4 w-4 text-white drop-shadow" />
                      )}
                    </button>
                  ))}
                </div>
                {rail.theme === "dynamic" && (
                  <p className="text-xs text-muted-foreground">
                    La barra avanza de naranja a verde a medida que te acercas al final,
                    con destello en el tramo que estás llenando.
                  </p>
                )}
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="labels-switch">Mostrar números de página</Label>
                  <p className="text-xs text-muted-foreground">Etiquetas junto a cada hito</p>
                </div>
                <Switch
                  id="labels-switch"
                  checked={rail.showLabels}
                  onCheckedChange={(v) => setRail({ showLabels: v })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="celebrate-switch" className="gap-1.5">
                    <Sparkles className="h-3.5 w-3.5 text-primary" /> Celebrar hitos
                  </Label>
                  <p className="text-xs text-muted-foreground">Confeti al completar cada tramo</p>
                </div>
                <Switch
                  id="celebrate-switch"
                  checked={rail.celebrate}
                  onCheckedChange={(v) => setRail({ celebrate: v })}
                />
              </div>
            </div>
          </section>

          <Separator />

          {/* ---------- Comodidad visual ---------- */}
          <section aria-label="Comodidad visual">
            <div className="mb-3 flex items-center gap-2">
              <Eye className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-semibold uppercase tracking-wide">Comodidad visual</h3>
            </div>

            <div className="grid gap-5">
              <div className="grid gap-2">
                <Label>Modo de lectura</Label>
                <div className="flex flex-wrap gap-1.5">
                  {PRESETS.map((p) => (
                    <button
                      key={p.value}
                      onClick={() => setPreset(p.value)}
                      className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
                        filters.preset === p.value
                          ? "border-primary bg-primary/15 text-primary font-medium"
                          : "border-border/70 text-muted-foreground hover:border-primary/40 hover:text-foreground"
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">
                  «Papel» y «Cálido» reducen la luz azul; «Noche» invierte el PDF para leer en la oscuridad.
                </p>
              </div>

              <div className="grid gap-4 rounded-lg border border-border/50 bg-card/40 p-4">
                <FilterSlider
                  label="Brillo"
                  value={filters.brightness}
                  min={40}
                  max={140}
                  onChange={(v) => setFilters({ brightness: v })}
                  format={(v) => `${v}%`}
                />
                <FilterSlider
                  label="Contraste"
                  value={filters.contrast}
                  min={50}
                  max={150}
                  onChange={(v) => setFilters({ contrast: v })}
                  format={(v) => `${v}%`}
                />
                <FilterSlider
                  label="Sepia"
                  value={filters.sepia}
                  min={0}
                  max={100}
                  onChange={(v) => setFilters({ sepia: v })}
                  format={(v) => `${v}%`}
                />
                <FilterSlider
                  label="Saturación"
                  value={filters.saturate}
                  min={0}
                  max={150}
                  onChange={(v) => setFilters({ saturate: v })}
                  format={(v) => `${v}%`}
                />
                <FilterSlider
                  label="Inversión (modo noche)"
                  value={filters.invert ?? 0}
                  min={0}
                  max={100}
                  onChange={(v) => setFilters({ invert: v })}
                  format={(v) => `${v}%`}
                />
                <FilterSlider
                  label="Tinte cálido"
                  value={filters.warmth}
                  min={0}
                  max={100}
                  onChange={(v) => setFilters({ warmth: v })}
                  format={(v) => `${v}%`}
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="justify-start gap-2 text-muted-foreground"
                  onClick={() => setPreset("normal")}
                >
                  <RotateCcw className="h-3.5 w-3.5" /> Restablecer filtros
                </Button>
              </div>

              {/* Navegación: cuánto avanza cada flecha y cada giro de rueda */}
              <div className="grid gap-4 rounded-lg border border-border/50 bg-card/40 p-4">
                <div>
                  <Label className="gap-1.5">
                    <MoveVertical className="h-3.5 w-3.5 text-primary" /> Navegación dentro de la página
                  </Label>
                  <p className="mt-0.5 text-xs leading-snug text-muted-foreground">
                    Salto más grande = menos pulsaciones de flecha y menos reacomodo de la vista.
                  </p>
                </div>
                <div className="grid gap-1.5">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs">Salto con ↑ / ↓</Label>
                    <span className="tabular-nums text-xs text-muted-foreground" data-testid="scroll-step-value">
                      {scrollStepPct}% del visor
                    </span>
                  </div>
                  <Slider
                    value={[scrollStepPct]}
                    min={10}
                    max={100}
                    step={5}
                    onValueChange={([v]) => setReading({ scrollStepPct: v })}
                    aria-label="Tamaño del salto con las flechas arriba y abajo"
                    data-testid="scroll-step-slider"
                  />
                  <p className="text-xs text-muted-foreground">
                    En el borde de la página, la flecha pasa a la siguiente: lectura continua.
                  </p>
                </div>
                <div className="grid gap-1.5">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs gap-1.5">
                      <Mouse className="h-3 w-3" /> Rueda del mouse
                    </Label>
                    <span className="tabular-nums text-xs text-muted-foreground" data-testid="wheel-boost-value">
                      {wheelBoost === 1 ? "nativa" : `${wheelBoost}×`}
                    </span>
                  </div>
                  <Slider
                    value={[wheelBoost]}
                    min={1}
                    max={4}
                    step={0.5}
                    onValueChange={([v]) => setReading({ wheelBoost: v })}
                    aria-label="Multiplicador de la rueda del mouse"
                    data-testid="wheel-boost-slider"
                  />
                  <p className="text-xs text-muted-foreground">
                    «Nativa» respeta la suavidad del navegador; los multiplicadores amplifican cada giro.
                  </p>
                </div>
              </div>

              {/* Modo inmersión: la UI se desvanece por inactividad del mouse */}
              <div className="grid gap-4 rounded-lg border border-border/50 bg-card/40 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <Label htmlFor="immersion-switch" className="gap-1.5">
                      <EyeOff className="h-3.5 w-3.5 text-primary" /> Modo inmersión
                    </Label>
                    <p className="mt-0.5 text-xs leading-snug text-muted-foreground">
                      Si el mouse queda quieto, la interfaz se desvanece: solo tu libro. Un
                      movimiento la devuelve; la tecla de abajo la esconde o la trae al instante.
                    </p>
                  </div>
                  <Switch
                    id="immersion-switch"
                    checked={immersion.enabled}
                    onCheckedChange={(v) => setImmersion({ enabled: v })}
                    data-testid="immersion-switch"
                  />
                </div>
                {immersion.enabled && (
                  <div className="grid gap-1.5">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs">Espera antes de ocultar</Label>
                      <span className="tabular-nums text-xs text-muted-foreground" data-testid="immersion-seconds">
                        {immersion.idleSeconds}s
                      </span>
                    </div>
                    <Slider
                      value={[immersion.idleSeconds]}
                      min={2}
                      max={12}
                      step={1}
                      onValueChange={([v]) => setImmersion({ idleSeconds: v })}
                      aria-label="Segundos de inactividad antes de ocultar la interfaz"
                      data-testid="immersion-slider"
                    />
                  </div>
                )}
                <div className="grid gap-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="toggle-key-button" className="text-xs gap-1.5">
                      <Keyboard className="h-3.5 w-3.5 text-primary" /> Tecla para ocultar / mostrar
                    </Label>
                    <Button
                      id="toggle-key-button"
                      variant={capturing ? "default" : "outline"}
                      size="sm"
                      className="h-7 min-w-16 tabular-nums"
                      onClick={() => {
                        setCapturing((v) => !v);
                        setKeyHint(null);
                      }}
                      data-testid="toggle-key-button"
                    >
                      {capturing ? "Pulsa una tecla…" : formatKey(immersion.toggleKey)}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {capturing
                      ? "Esc para cancelar. Las teclas con otra función (flechas, +, −, F, O, M) están reservadas."
                      : "Funciona aunque el auto-ocultado esté apagado: la UI no depende del mouse."}
                  </p>
                  {keyHint && <p className="text-xs font-medium text-destructive">{keyHint}</p>}
                </div>
              </div>
            </div>
          </section>

          <Separator />

          {/* ---------- Hábito ---------- */}
          <section aria-label="Meta diaria">
            <div className="mb-3 flex items-center gap-2">
              <Target className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-semibold uppercase tracking-wide">Tu hábito</h3>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="goal-input">Meta diaria (páginas)</Label>
              <Input
                id="goal-input"
                type="number"
                min={1}
                max={500}
                value={dailyGoal}
                onChange={(e) => {
                  const v = parseInt(e.target.value, 10);
                  if (Number.isFinite(v)) setReading({ dailyGoal: Math.min(500, Math.max(1, v)) });
                }}
                className="w-28"
              />
              <p className="text-xs text-muted-foreground">
                Cumplirla alimenta tu racha. Con 20 pág/día terminas un libro de 300 en 15 días.
              </p>
            </div>
          </section>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function FilterSlider({
  label,
  value,
  min,
  max,
  onChange,
  format,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
  format: (v: number) => string;
}) {
  return (
    <div className="grid gap-1.5">
      <div className="flex items-center justify-between">
        <Label className="text-xs">{label}</Label>
        <span className="tabular-nums text-xs text-muted-foreground">{format(value)}</span>
      </div>
      <Slider
        value={[value]}
        min={min}
        max={max}
        step={1}
        onValueChange={([v]) => onChange(v)}
        aria-label={label}
      />
    </div>
  );
}
