"use client";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { ZOOM_TARGETS } from "@/hooks/use-zoom-preset";
import { Check, Minus, Plus, ZoomIn } from "lucide-react";
import type { ZoomPresetId } from "@/lib/types";

interface ZoomControlsProps {
  effectiveScale: number;
  activeZoom: ZoomPresetId | "custom" | null;
  onZoomBy: (factor: number) => void;
  onPreset: (id: ZoomPresetId) => void;
}

/** Zoom fino: − / % + menú de predefinidos, todos relativos al visor */
export function ZoomControls({ effectiveScale, activeZoom, onZoomBy, onPreset }: ZoomControlsProps) {
  return (
    <div className="flex items-center gap-0.5">
        <Tip label="Reducir zoom (−)">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onZoomBy(1 / 1.12)} aria-label="Reducir zoom">
            <Minus className="h-4 w-4" />
          </Button>
        </Tip>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 gap-1.5 px-2 text-xs tabular-nums"
              title="Zoom predefinidos"
              data-testid="zoom-menu"
            >
              <ZoomIn className="h-3.5 w-3.5" />
              {Math.round(effectiveScale * 100)}%
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="center" className="w-72">
            {ZOOM_TARGETS.map((z) => (
              <DropdownMenuItem
                key={z.id}
                onClick={() => onPreset(z.id)}
                className="items-start gap-2 py-2"
                data-testid={`zoom-${z.id}`}
              >
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium">
                    {z.label}
                    {activeZoom === z.id ? " · activo" : ""}
                  </p>
                  <p className="text-[11px] leading-snug text-muted-foreground">{z.hint}</p>
                </div>
                {activeZoom === z.id && <Check className="mt-0.5 h-3.5 w-3.5 text-primary" />}
              </DropdownMenuItem>
            ))}
            <DropdownMenuSeparator />
            <p className="px-2 py-1.5 text-[11px] leading-snug text-muted-foreground">
              Manual: botones + −, Ctrl + rueda o teclas + / − · «O» óptima · «F» página completa
            </p>
          </DropdownMenuContent>
        </DropdownMenu>
        <Tip label="Aumentar zoom (+)">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onZoomBy(1.12)} aria-label="Aumentar zoom">
            <Plus className="h-4 w-4" />
          </Button>
        </Tip>
      </div>
  );
}

/** Tooltip de cabecera: etiqueta + atajo, aparición rápida y con estilo de la app */
export function Tip({ label, children }: { label: React.ReactNode; children: React.ReactElement }) {
  return (
    <Tooltip delayDuration={280}>
      <TooltipTrigger asChild>{children}</TooltipTrigger>
      <TooltipContent side="bottom" className="text-xs">
        {label}
      </TooltipContent>
    </Tooltip>
  );
}
