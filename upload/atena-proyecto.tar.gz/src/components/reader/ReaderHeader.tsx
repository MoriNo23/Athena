"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SyncProgressPopover } from "@/components/reader/SyncProgressPopover";
import { Tip, ZoomControls } from "@/components/reader/ZoomControls";
import { cn } from "@/lib/utils";
import type { BookDTO, ZoomPresetId } from "@/lib/types";
import {
  ArrowLeft,
  BookOpenText,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Flame,
  Languages,
  Maximize,
  Minimize2,
  PanelRightOpen,
  Settings2,
  Target,
} from "lucide-react";
import type { RefObject } from "react";

/** Regla vertical sutil que separa grupos funcionales de la cabecera */
function VRule() {
  return <div className="mx-1 h-5 w-px shrink-0 bg-border/50" aria-hidden />;
}

interface ReaderHeaderProps {
  book: BookDTO;
  pct: number;
  numPages: number;
  pageNum: number;
  goToPage: (target: number, opts?: { silent?: boolean }) => void;
  onBack: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  effectiveScale: number;
  activeZoom: ZoomPresetId | "custom" | null;
  onZoomBy: (factor: number) => void;
  onPreset: (id: ZoomPresetId) => void;
  dockVisible: boolean;
  onToggleDock: () => void;
  /** modo novela visual abierto (para marcar el botón activo) */
  vnOpen: boolean;
  onToggleVn: () => void;
  vocabularyCount: number;
  onOpenVocabulary: () => void;
  todayStreak: number;
  pagesToday: number;
  dailyGoal: number;
  sessionMinutes: number;
  /** "terminas el 3 de noviembre" a ritmo real, o null si aún no hay ritmo */
  etaLabel: string | null;
  onOpenSettings: () => void;
  syncOpen: boolean;
  onSyncOpenChange: (open: boolean) => void;
  currentPageRef: RefObject<number>;
  onSilentJump: (page: number) => void;
  onCancelScheduledSave: () => void;
  onFlushSave: (page: number) => void;
}

/** Cabecera del lector: identidad, navegación, sync, fullscreen, zoom, paneles y hábito */
export function ReaderHeader({
  book,
  pct,
  numPages,
  pageNum,
  goToPage,
  onBack,
  isFullscreen,
  onToggleFullscreen,
  effectiveScale,
  activeZoom,
  onZoomBy,
  onPreset,
  dockVisible,
  onToggleDock,
  vnOpen,
  onToggleVn,
  vocabularyCount,
  onOpenVocabulary,
  todayStreak,
  pagesToday,
  dailyGoal,
  sessionMinutes,
  etaLabel,
  onOpenSettings,
  syncOpen,
  onSyncOpenChange,
  currentPageRef,
  onSilentJump,
  onCancelScheduledSave,
  onFlushSave,
}: ReaderHeaderProps) {
  return (
    <header data-chrome data-chrome-kind="header" className="flex h-14 shrink-0 items-center gap-1 border-b border-border/60 bg-card/40 px-3">
      {/* Identidad: volver + título (uso bajo, tamaño contenido) */}
      <Tip label="Volver a la biblioteca">
        <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={onBack} aria-label="Volver a la biblioteca">
          <ArrowLeft className="h-4 w-4" />
        </Button>
      </Tip>
      <div className="mr-2 min-w-0">
        <h2 className="truncate font-display text-sm font-semibold leading-tight">
          {book.title}
        </h2>
        <p className="truncate text-[11px] text-muted-foreground">
          {book.author || "—"} · {pct}% leído
          {etaLabel && <span className="text-foreground/80"> · {etaLabel}</span>}
        </p>
      </div>

      {/* Navegación de lectura: la acción más frecuente, al centro */}
      <div className="mx-auto flex items-center gap-1">
        <Tip label="Página anterior (←)">
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => goToPage(pageNum - 1)} disabled={pageNum <= 1} aria-label="Página anterior">
            <ChevronLeft className="h-4 w-4" />
          </Button>
        </Tip>
        <div className="flex items-center gap-1.5 rounded-md border border-border/60 bg-background/60 px-2 py-1">
          <Input
            type="number"
            min={1}
            max={numPages}
            value={pageNum}
            onChange={(e) => {
              const v = parseInt(e.target.value, 10);
              if (Number.isFinite(v)) goToPage(v, { silent: true });
            }}
            // Enter/Escape devuelven el foco al libro: si se queda aquí dentro,
            // los atajos (flechas, zoom, H) quedan «muertos» hasta click en la página
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === "Escape") {
                e.preventDefault();
                e.currentTarget.blur();
                document.querySelector<HTMLElement>('[data-viewport="pdf"]')?.focus({ preventScroll: true });
              }
            }}
            className="h-6 w-14 border-0 bg-transparent p-0 text-center text-sm tabular-nums focus-visible:ring-0"
            aria-label="Número de página"
          />
          <span className="text-xs text-muted-foreground tabular-nums">de {numPages}</span>
        </div>
        <Tip label="Página siguiente (→)">
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => goToPage(pageNum + 1)} disabled={pageNum >= numPages} aria-label="Página siguiente">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </Tip>

        {/* Sincronizar progreso: lo leía en otro lado (papel/otra app) */}
        <SyncProgressPopover
          open={syncOpen}
          onOpenChange={onSyncOpenChange}
          numPages={numPages}
          currentPageRef={currentPageRef}
          onSilentJump={onSilentJump}
          onCancelScheduledSave={onCancelScheduledSave}
          onFlushSave={onFlushSave}
        />
      </div>

      {/* Pantalla completa: la acción de vista más útil — acento, etiqueta y sitio propio */}
      <Tip label="Pantalla completa (M)">
        <Button
          variant={isFullscreen ? "secondary" : "outline"}
          size="sm"
          className={cn(
            "h-8 shrink-0 gap-1.5 text-xs font-medium",
            !isFullscreen &&
              // dark:* duplicados: sin ellos, dark:bg-input/30 y dark:hover:bg-input/50
              // del variante outline ganan en el orden de cascada de Tailwind v4
              "border-primary/40 bg-primary/10 text-primary shadow-none hover:border-primary/60 hover:bg-primary/20 dark:border-primary/40 dark:bg-primary/10 dark:hover:border-primary/60 dark:hover:bg-primary/20"
          )}
          onClick={onToggleFullscreen}
          aria-label={isFullscreen ? "Salir de pantalla completa" : "Pantalla completa"}
          data-testid="toggle-fullscreen"
        >
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
          {isFullscreen ? "Salir" : "Pantalla completa"}
        </Button>
      </Tip>
      <VRule />

      {/* Zoom fino: predefinidos + manual */}
      <ZoomControls effectiveScale={effectiveScale} activeZoom={activeZoom} onZoomBy={onZoomBy} onPreset={onPreset} />
      <VRule />

      {/* Paneles: modos de lectura + vocabulario */}
      <div className="flex items-center gap-1">
        <Button
          variant={dockVisible ? "secondary" : "ghost"}
          size="sm"
          className="h-8 shrink-0 gap-1.5 text-xs"
          onClick={onToggleDock}
          aria-label={dockVisible ? "Cerrar modos de lectura" : "Abrir modos de lectura"}
          data-testid="toggle-dock"
        >
          <PanelRightOpen className="h-4 w-4" />
          Modos
        </Button>
        <Button
          variant={vnOpen ? "secondary" : "ghost"}
          size="sm"
          className="h-8 shrink-0 gap-1.5 text-xs"
          onClick={onToggleVn}
          aria-label="Modo novela visual: la página se lee en tarjetas letra a letra"
          data-testid="vn-toggle"
        >
          <BookOpenText className="h-4 w-4" />
          Novela
        </Button>
        <Tip label="Vocabulario guardado">
          <Button
            variant="ghost"
            size="icon"
            className="relative h-8 w-8 shrink-0"
            onClick={onOpenVocabulary}
            aria-label="Abrir vocabulario"
            data-testid="open-vocabulary"
          >
            <Languages className="h-4 w-4" />
            {vocabularyCount > 0 && (
              <span
                className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[9px] font-bold text-primary-foreground tabular-nums"
                data-testid="vocab-count"
              >
                {vocabularyCount > 99 ? "99+" : vocabularyCount}
              </span>
            )}
          </Button>
        </Tip>
      </div>

      <VRule />

      {/* Hábito: información pasiva, sin competir con las acciones */}
      <div className="flex shrink-0 items-center gap-2 text-xs text-muted-foreground">
        <span className="flex items-center gap-1" title={`Racha de ${todayStreak} días`}>
          <Flame className={`h-3.5 w-3.5 ${todayStreak > 0 ? "text-primary" : ""}`} />
          {todayStreak}
        </span>
        <span className="flex items-center gap-1" title="Meta diaria">
          <Target className="h-3.5 w-3.5" />
          {pagesToday}/{dailyGoal}
        </span>
        <span className="flex items-center gap-1 tabular-nums" title="Sesión actual">
          <Clock3 className="h-3.5 w-3.5" />
          {sessionMinutes}m
        </span>
      </div>

      <Tip label="Ajustes del riel y la lectura">
        <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={onOpenSettings} aria-label="Abrir ajustes del riel">
          <Settings2 className="h-4 w-4" />
        </Button>
      </Tip>
    </header>
  );
}
