"use client";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Coffee } from "lucide-react";

interface PauseDialogProps {
  open: boolean;
  pageNum: number;
  pauseMinutes: number;
  draft: string;
  onDraftChange: (value: string) => void;
  /** abrir nunca (solo cerrar): cierre = seguir leyendo */
  onClose: () => void;
  onTake: () => void;
}

/** Diálogo de pausa en corte natural: guarda un recordatorio de dónde ibas */
export function PauseDialog({ open, pageNum, pauseMinutes, draft, onDraftChange, onClose, onTake }: PauseDialogProps) {
  return (
    <Dialog open={open} onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent className="sm:max-w-md" data-testid="pause-dialog">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display">
            <Coffee className="h-4 w-4 text-primary" /> Fin de sesión sugerido
          </DialogTitle>
          <DialogDescription>
            Llevas {Math.round(pauseMinutes)} minutos leyendo y acabas de terminar la página {pageNum}.
            Este es un corte natural: escribe un recordatorio de dónde vas y vuelve cuando quieras.
          </DialogDescription>
        </DialogHeader>
        <Textarea
          value={draft}
          onChange={(e) => onDraftChange(e.target.value)}
          rows={3}
          placeholder="Al volver, esto te reengancha: ¿qué está pasando ahora, qué saben tus personajes hasta aquí?"
          className="text-xs"
          data-testid="pause-dialog-recap"
        />
        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="ghost" size="sm" onClick={onClose}>
            Seguir un rato más
          </Button>
          <Button size="sm" onClick={onTake} data-testid="pause-take">
            Guardar y pausar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
