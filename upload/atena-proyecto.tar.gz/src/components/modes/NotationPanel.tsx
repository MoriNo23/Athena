"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2 } from "lucide-react";
import { ModePanelProps, uid } from "@/components/modes/panel-props";
import type { SymbolEntry } from "@/lib/types";

/** Notación viva: cada símbolo con su definición y la página donde se definió */
export function NotationPanel({ extras, onPatch, goToPage, pageNum }: ModePanelProps) {
  const symbols = extras.notation ?? [];
  const [symbol, setSymbol] = useState("");
  const [meaning, setMeaning] = useState("");

  const add = () => {
    if (!symbol.trim()) return;
    const entry: SymbolEntry = {
      id: uid("s"),
      symbol: symbol.trim().slice(0, 40),
      meaning: meaning.trim().slice(0, 300),
      page: pageNum,
    };
    onPatch({ notation: [...symbols, entry] });
    setSymbol("");
    setMeaning("");
  };

  const remove = (id: string) => onPatch({ notation: symbols.filter((s) => s.id !== id) });

  const sorted = [...symbols].sort((a, b) => a.page - b.page);

  return (
    <div className="grid gap-3">
      <p className="text-xs leading-relaxed text-muted-foreground">
        Cada símbolo se define una vez y reaparece por todo el libro. Guárdalo aquí y salta a la
        página donde se definió con un clic.
      </p>

      <form
        className="grid gap-2 rounded-lg border border-border/50 bg-card/40 p-3"
        onSubmit={(e) => {
          e.preventDefault();
          add();
        }}
      >
        <div className="grid grid-cols-[88px_1fr] gap-2">
          <Input
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
            placeholder="ε, O(n log n)…"
            aria-label="Símbolo"
            className="h-8 font-mono text-sm"
          />
          <Input
            value={meaning}
            onChange={(e) => setMeaning(e.target.value)}
            placeholder="Significado (qué es, dónde se usa)"
            aria-label="Significado del símbolo"
            className="h-8 text-xs"
          />
        </div>
        <div className="flex items-center justify-between">
          <span className="text-[11px] text-muted-foreground">Se guarda con la página actual ({pageNum})</span>
          <Button type="submit" size="sm" className="h-7 gap-1 text-xs" disabled={!symbol.trim()}>
            <Plus className="h-3.5 w-3.5" /> Añadir
          </Button>
        </div>
      </form>

      {sorted.length === 0 ? (
        <p className="py-6 text-center text-xs text-muted-foreground" data-testid="notation-empty">
          Todavía no hay símbolos. Prueba con uno del capítulo que estés leyendo.
        </p>
      ) : (
        <ul className="grid gap-1.5">
          {sorted.map((s) => (
            <li
              key={s.id}
              className="group flex items-start justify-between gap-2 rounded-lg border border-border/40 bg-card/30 px-3 py-2"
              data-testid="notation-entry"
            >
              <div className="min-w-0">
                <span className="font-mono text-sm font-semibold text-primary">{s.symbol}</span>
                <p className="mt-0.5 break-words text-xs leading-snug text-foreground/90">{s.meaning}</p>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <button
                  onClick={() => goToPage(s.page)}
                  className="rounded-md border border-border/50 px-1.5 py-0.5 text-[11px] tabular-nums text-muted-foreground transition-colors hover:border-primary/50 hover:text-primary"
                  title={`Ir a la página ${s.page}`}
                >
                  pág. {s.page}
                </button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100 hover:text-destructive"
                  onClick={() => remove(s.id)}
                  aria-label={`Eliminar símbolo ${s.symbol}`}
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
