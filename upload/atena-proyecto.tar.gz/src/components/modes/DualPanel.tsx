"use client";

import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BookCopy, Loader2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ModePanelProps } from "@/components/modes/panel-props";
import { probePdf } from "@/lib/pdf-client";
import type { BookDTO } from "@/lib/types";

interface DualPanelProps extends ModePanelProps {
  book: BookDTO;
  /** sincroniza el libro con la raíz (companionPath) */
  onBookChange?: (book: BookDTO) => void;
}

/** Dos traducciones a la vez: sube el PDF compañero y se alinea por progreso */
export function DualPanel({ book, onBookChange, numPages }: DualPanelProps) {
  const { toast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const hasCompanion = !!book.companionPath;

  const upload = async (file: File) => {
    setUploading(true);
    try {
      const probe = await probePdf(file);
      const form = new FormData();
      form.append("file", file);
      form.append("pages", String(probe.numPages));
      const res = await fetch(`/api/books/${book.id}/companion`, { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok || !data.book) throw new Error(data.error ?? "error");
      onBookChange?.({ ...book, companionPath: data.book.companionPath, companionPages: data.book.companionPages });
      toast({
        title: "Compañero sincronizado",
        description: `${file.name} (${probe.numPages} pág.) se alineará por progreso con las ${numPages} páginas del libro.`,
        duration: 4500,
      });
    } catch (e) {
      console.error(e);
      toast({ title: "No se pudo subir el compañero", description: e instanceof Error ? e.message : undefined, duration: 4000 });
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const removeCompanion = async () => {
    try {
      const res = await fetch(`/api/books/${book.id}/companion`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "error");
      onBookChange?.({ ...book, companionPath: null, companionPages: null });
      toast({ title: "Compañero quitado", duration: 2500 });
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="grid gap-3">
      <p className="text-xs leading-relaxed text-muted-foreground">
        Para leer en dos idiomas o comparar ediciones: alinea párrafo a página el original con la
        traducción, sincronizados por el avance del libro.
      </p>

      {!hasCompanion ? (
        <div className="grid gap-2 rounded-lg border border-dashed border-border/50 bg-card/30 p-4 text-center" data-testid="dual-upload-zone">
          <BookCopy className="mx-auto h-6 w-6 text-muted-foreground/60" />
          <p className="text-xs text-muted-foreground">
            Sube el segundo PDF (otra traducción, el original, otra edición).
          </p>
          <Input
            ref={fileRef}
            type="file"
            accept="application/pdf,.pdf"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void upload(f);
            }}
            aria-label="Subir PDF compañero"
          />
          <Button
            size="sm"
            variant="outline"
            className="mx-auto h-7 gap-1.5 text-xs"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
          >
            {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <BookCopy className="h-3.5 w-3.5" />}
            {uploading ? "Subiendo…" : "Elegir PDF"}
          </Button>
        </div>
      ) : (
        <div className="grid gap-2 rounded-lg border border-border/50 bg-card/40 p-3" data-testid="dual-active">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <p className="truncate text-xs font-medium">PDF compañero activo</p>
              <p className="text-[11px] text-muted-foreground">
                {book.companionPages} pág. · sincroniza por progreso con este libro ({numPages} pág.)
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 shrink-0 text-muted-foreground hover:text-destructive"
              onClick={removeCompanion}
              aria-label="Quitar PDF compañero"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>
          <p className="text-[11px] leading-relaxed text-muted-foreground/80">
            La página del compañero se calcula como tu avance relativo: pág. actual ÷ total del
            libro × total del compañero. Útil para traducciones que no coinciden página a página.
          </p>
        </div>
      )}
    </div>
  );
}
