"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { RotateCcw } from "lucide-react";
import { ModePanelProps } from "@/components/modes/panel-props";

/** Lectura en tres pasadas (Keshav, "How to Read a Paper") */

interface Pass {
  id: string;
  key: string;
  title: string;
  time: string;
  goal: string;
  items: string[];
}

const PASSES: Pass[] = [
  {
    id: "p1",
    key: "p1",
    title: "Primera pasada — ojear",
    time: "5–10 min",
    goal: "Decidir si merece la pena. La vista general, no el contenido.",
    items: [
      "Leer título, resumen e introducción con cuidado",
      "Recorrer encabezados de sección y conclusiones",
      "Mirar figuras, tablas y ejemplos destacados",
      "Echar un ojo rápido a las referencias que ya conozcas",
    ],
  },
  {
    id: "p2",
    key: "p2",
    title: "Segunda pasada — leer con atención",
    time: "~1 h",
    goal: "Entender el argumento completo, sin demostraciones ni detalles.",
    items: [
      "Mirar con atención figuras, diagramas y tablas",
      "Marcar (o ignorar a conciencia) las demostraciones",
      "Anotar en Notación los términos cuyo significado ignores",
      "Anotar las preguntas que quieras resolver en la tercera pasada",
    ],
  },
  {
    id: "p3",
    key: "p3",
    title: "Tercera pasada — reconstruir",
    time: "2–4 h (lectores expertos)",
    goal: "Volver a crear el trabajo como si fueras a implementarlo.",
    items: [
      "Recrear mentalmente las suposiciones del trabajo",
      "Identificar la idea brillante: la base sobre la que se apoya",
      "Señalar supuestos ocultos, citas que faltan y debilidades",
      "Reconstruir la estructura completa en papel, de memoria",
    ],
  },
];

export function ThreePassPanel({ extras, onPatch, goToPage, numPages }: ModePanelProps) {
  const state = extras.threePass ?? { checked: {}, notes: "" };
  const [notes, setNotes] = useState(state.notes);

  const completedPass = PASSES.filter((p) => p.items.every((_, i) => state.checked[`${p.key}-${i}`])).length;

  const setCheck = (key: string, v: boolean | string) => {
    const checked = { ...state.checked, [key]: v === true };
    onPatch({ threePass: { ...state, checked } });
  };

  const saveNotes = () => {
    if (notes !== state.notes) onPatch({ threePass: { ...state, notes } });
  };

  const reset = () => {
    setNotes("");
    onPatch({ threePass: { checked: {}, notes: "" } });
  };

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <div className="flex gap-1" aria-label="Progreso de pasadas">
          {PASSES.map((p, i) => (
            <span
              key={p.key}
              data-testid={`pass-bubble-${p.key}`}
              className={`flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-semibold tabular-nums ${
                i < completedPass
                  ? "bg-primary text-primary-foreground"
                  : i === completedPass
                    ? "border border-primary text-primary"
                    : "border border-border/60 text-muted-foreground"
              }`}
            >
              {i + 1}
            </span>
          ))}
        </div>
        <Button variant="ghost" size="sm" className="h-7 gap-1 text-xs text-muted-foreground" onClick={reset}>
          <RotateCcw className="h-3 w-3" /> Reiniciar
        </Button>
      </div>

      <p className="text-xs leading-relaxed text-muted-foreground">
        Empieza por la primera: si el paper no sobrevive a ella, descártalo en cinco minutos y pasa
        al siguiente. Cada pasada se puede repetir tantas veces como quieras.
      </p>

      {PASSES.map((pass) => {
        const done = pass.items.every((_, i) => state.checked[`${pass.key}-${i}`]);
        const active = PASSES.indexOf(pass) === completedPass;
        return (
          <div
            key={pass.key}
            className={`grid gap-2.5 rounded-lg border p-3.5 ${
              done
                ? "border-primary/25 bg-primary/5 opacity-80"
                : active
                  ? "border-border/70 bg-card/40"
                  : "border-border/40 opacity-70"
            }`}
            data-testid={`pass-${pass.key}`}
          >
            <div>
              <div className="flex items-baseline justify-between gap-2">
                <h4 className="text-sm font-semibold leading-snug">{pass.title}</h4>
                <span className="shrink-0 text-[10px] uppercase tracking-wide text-muted-foreground">{pass.time}</span>
              </div>
              <p className="mt-0.5 text-xs text-muted-foreground">{pass.goal}</p>
            </div>
            <ul className="grid gap-2">
              {pass.items.map((item, i) => {
                const key = `${pass.key}-${i}`;
                return (
                  <li key={key} className="flex items-start gap-2">
                    <Checkbox
                      id={`cb-${key}`}
                      checked={!!state.checked[key]}
                      onCheckedChange={(v) => setCheck(key, v)}
                      className="mt-0.5"
                      aria-label={item}
                    />
                    <label
                      htmlFor={`cb-${key}`}
                      className={`cursor-pointer text-xs leading-snug ${state.checked[key] ? "text-muted-foreground line-through" : ""}`}
                    >
                      {item}
                    </label>
                  </li>
                );
              })}
            </ul>
            {pass.key === "p2" && (
              <button
                onClick={() => goToPage(Math.max(1, Math.round(numPages * 0.5)))}
                className="justify-self-start text-[11px] text-primary underline-offset-2 hover:underline"
              >
                Ir a la mitad del libro para retomar la pasada →
              </button>
            )}
            {done && <p className="text-[11px] font-medium text-primary">✓ Pasada completada</p>}
          </div>
        );
      })}

      <div className="grid gap-1.5">
        <label htmlFor="threepass-notes" className="text-xs font-medium text-muted-foreground">
          Notas del proceso (preguntas, hallazgos, debilidades)
        </label>
        <Textarea
          id="threepass-notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          onBlur={saveNotes}
          rows={4}
          placeholder="Ej.: el supuesto de la sección 4 depende del dataset A, pero la tabla 3 usa B…"
          className="text-xs"
        />
      </div>
    </div>
  );
}
