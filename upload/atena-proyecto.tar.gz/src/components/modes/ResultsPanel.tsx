"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2 } from "lucide-react";
import { ModePanelProps, uid } from "@/components/modes/panel-props";
import type { ResultEntry } from "@/lib/types";

/** Tabla viva de resultados: marca dataset + métrica + valor mientras lees y compáralos */
export function ResultsPanel({ extras, onPatch, goToPage, pageNum }: ModePanelProps) {
  const rows = extras.results ?? [];
  const [method, setMethod] = useState("");
  const [dataset, setDataset] = useState("");
  const [metric, setMetric] = useState("");
  const [value, setValue] = useState("");
  const [open, setOpen] = useState(false);

  const add = () => {
    if (!method.trim() && !value.trim()) return;
    const row: ResultEntry = {
      id: uid("r"),
      method: method.trim() || "—",
      dataset: dataset.trim() || "—",
      metric: metric.trim() || "—",
      value: value.trim() || "—",
      page: pageNum,
    };
    onPatch({ results: [...rows, row] });
    setMethod("");
    setDataset("");
    setMetric("");
    setValue("");
  };

  const remove = (id: string) => onPatch({ results: rows.filter((r) => r.id !== id) });

  return (
    <div className="grid gap-3">
      <p className="text-xs leading-relaxed text-muted-foreground">
        Es la tabla que construirías a mano en una hoja de cálculo al hacer una revisión de
        literatura. Marca un resultado y quedará con su fuente.
      </p>

      {!open ? (
        <Button variant="outline" size="sm" className="h-7 w-fit gap-1 text-xs" onClick={() => setOpen(true)}>
          <Plus className="h-3.5 w-3.5" /> Añadir resultado
        </Button>
      ) : (
        <form
          className="grid gap-2 rounded-lg border border-border/50 bg-card/40 p-3"
          onSubmit={(e) => {
            e.preventDefault();
            add();
            setOpen(false);
          }}
          data-testid="results-form"
        >
          <div className="grid grid-cols-2 gap-2">
            <Input value={method} onChange={(e) => setMethod(e.target.value)} placeholder="Método / modelo" className="h-8 text-xs" aria-label="Método o modelo" />
            <Input value={dataset} onChange={(e) => setDataset(e.target.value)} placeholder="Dataset" className="h-8 text-xs" aria-label="Dataset" />
            <Input value={metric} onChange={(e) => setMetric(e.target.value)} placeholder="Métrica (F1, BLEU…)" className="h-8 text-xs" aria-label="Métrica" />
            <Input value={value} onChange={(e) => setValue(e.target.value)} placeholder="Valor (87.3…)" className="h-8 text-xs" aria-label="Valor" />
          </div>
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-muted-foreground">Fuente: pág. {pageNum}</span>
            <div className="flex gap-1.5">
              <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" size="sm" className="h-7 gap-1 text-xs">
                <Plus className="h-3.5 w-3.5" /> Añadir
              </Button>
            </div>
          </div>
        </form>
      )}

      {rows.length === 0 ? (
        <p className="py-6 text-center text-xs text-muted-foreground" data-testid="results-empty">
          Sin resultados marcados todavía. La tabla se llena mientras lees.
        </p>
      ) : (
        <div className="overflow-hidden rounded-lg border border-border/50">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-border/50 bg-card/60 text-[10px] uppercase tracking-wide text-muted-foreground">
                <th className="px-2.5 py-2 font-medium">Método</th>
                <th className="px-2.5 py-2 font-medium">Dataset</th>
                <th className="px-2.5 py-2 font-medium">Métrica</th>
                <th className="px-2.5 py-2 text-right font-medium">Valor</th>
                <th className="px-1.5 py-2" />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-b border-border/30 last:border-0 hover:bg-card/40" data-testid="results-row">
                  <td className="px-2.5 py-2 font-medium">{r.method}</td>
                  <td className="px-2.5 py-2 text-muted-foreground">{r.dataset}</td>
                  <td className="px-2.5 py-2 text-muted-foreground">{r.metric}</td>
                  <td className="px-2.5 py-2 text-right font-mono tabular-nums">{r.value}</td>
                  <td className="whitespace-nowrap px-1.5 py-2 text-right">
                    {r.page != null && (
                      <button
                        onClick={() => goToPage(r.page as number)}
                        className="mr-1 rounded-md border border-border/40 px-1.5 py-0.5 text-[10px] tabular-nums text-muted-foreground transition-colors hover:border-primary/50 hover:text-primary"
                        title={`Ir a la página ${r.page}`}
                      >
                        {r.page}
                      </button>
                    )}
                    <button
                      onClick={() => remove(r.id)}
                      className="text-muted-foreground/60 transition-colors hover:text-destructive"
                      aria-label="Eliminar fila"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
