"use client";

import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Layers3,
  ListTree,
  ListChecks,
  Sigma,
  Table2,
  TerminalSquare,
  UsersRound,
  Coffee,
  GitBranch,
  Lock,
  BookCopy,
  Settings2,
  PanelRightClose,
  Save,
  Check,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSettings } from "@/lib/settings";
import { MODE_PRESETS, MODE_TOGGLE_META, ModePresetId, ModeToggleKey, BookDTO, BookExtras } from "@/lib/types";
import { ModePanelProps } from "@/components/modes/panel-props";
import { ThreePassPanel } from "@/components/modes/ThreePassPanel";
import { NotationPanel } from "@/components/modes/NotationPanel";
import { CodeRunnerPanel } from "@/components/modes/CodeRunnerPanel";
import { ResultsPanel } from "@/components/modes/ResultsPanel";
import { ReproPanel } from "@/components/modes/ReproPanel";
import { XrayPanel } from "@/components/modes/XrayPanel";
import { PausesPanel } from "@/components/modes/PausesPanel";
import { SkeletonPanel } from "@/components/modes/SkeletonPanel";
import { LockedNotesPanel } from "@/components/modes/LockedNotesPanel";
import { DualPanel } from "@/components/modes/DualPanel";
import { OutlinePanel } from "@/components/modes/OutlinePanel";
import type { PDFDocumentProxy } from "pdfjs-dist";

/** Icono y panel por subfeature */
const TOGGLE_UI: Record<ModeToggleKey, { icon: React.ComponentType<{ className?: string }>; tabLabel: string }> = {
  threePass: { icon: Layers3, tabLabel: "Pasadas" },
  notation: { icon: Sigma, tabLabel: "Símbolos" },
  codeRunner: { icon: TerminalSquare, tabLabel: "Código" },
  resultsTable: { icon: Table2, tabLabel: "Resultados" },
  reproAudit: { icon: ListChecks, tabLabel: "Repro" },
  xray: { icon: UsersRound, tabLabel: "Fichas" },
  naturalPauses: { icon: Coffee, tabLabel: "Pausas" },
  argumentSkeleton: { icon: GitBranch, tabLabel: "Esqueleto" },
  lockedNotes: { icon: Lock, tabLabel: "Notas 🔒" },
  dualRead: { icon: BookCopy, tabLabel: "Dual" },
  outline: { icon: ListTree, tabLabel: "Esquema" },
  dictionary: { icon: BookCopy, tabLabel: "Diccionario" },
};

// dictionary no tiene pestaña propia: su toggle vive en las opciones y el popover
// aparece directamente al seleccionar palabras en el PDF.

interface ModeDockProps extends ModePanelProps {
  book: BookDTO;
  onBookChange?: (book: BookDTO) => void;
  doc: PDFDocumentProxy | null;
  sessionSeconds: number;
  onClose: () => void;
}

export function ModeDock({
  book,
  onBookChange,
  extras,
  onPatch,
  goToPage,
  pageNum,
  numPages,
  doc,
  sessionSeconds,
  onClose,
}: ModeDockProps) {
  const { toast } = useToast();
  const modes = useSettings((s) => s.modes);
  const setModePreset = useSettings((s) => s.setModePreset);
  const toggleMode = useSettings((s) => s.toggleMode);
  const saveCustomPreset = useSettings((s) => s.saveCustomPreset);
  const [optionsOpen, setOptionsOpen] = useState(false);

  const activeKeys = useMemo(
    () => (Object.keys(MODE_TOGGLE_META) as ModeToggleKey[]).filter((k) => modes.toggles[k] && k !== "dictionary"),
    [modes.toggles]
  );

  const defaultTab = activeKeys[0] ?? "outline";

  const applyPreset = (id: ModePresetId) => {
    setModePreset(id);
    if (id === "custom" && !modes.customSaved) {
      toast({
        title: "Modo Custom",
        description: "Ajusta los interruptores a tu gusto y guarda tu propia configuración.",
        duration: 3500,
      });
    }
  };

  const handleSaveCustom = () => {
    saveCustomPreset();
    toast({
      title: "Preset guardado",
      description: "Esta es ahora tu configuración Custom. Cámbiala cuando quieras y vuelve a guardar.",
      duration: 3500,
    });
  };

  return (
    <aside
      className="flex w-[352px] shrink-0 flex-col border-l border-border/60 bg-card/30"
      data-dock="modes"
      data-testid="mode-dock"
      aria-label="Modos de lectura"
    >
      {/* Cabecera: presets + opciones */}
      <div className="border-b border-border/60 px-4 py-3">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-display text-sm font-semibold tracking-wide">Modo de lectura</h3>
          <div className="flex items-center gap-1">
            <Popover open={optionsOpen} onOpenChange={setOptionsOpen}>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="h-7 w-7" aria-label="Opciones de subfeatures" title="Activar/desactivar subfeatures">
                  <Settings2 className="h-4 w-4" />
                </Button>
              </PopoverTrigger>
              <PopoverContent side="bottom" align="end" className="w-80 p-3" data-testid="mode-options">
                <div className="grid gap-2.5">
                  <p className="text-xs font-medium text-muted-foreground">
                    Todas las subfeatures son opcionales: activa las que necesites ahora.
                  </p>
                  {(Object.keys(MODE_TOGGLE_META) as ModeToggleKey[]).map((key) => {
                    const meta = MODE_TOGGLE_META[key];
                    return (
                      <div key={key} className="flex items-start justify-between gap-2" data-testid={`mode-toggle-${key}`}>
                        <div className="min-w-0">
                          <p className="text-xs font-medium leading-tight">
                            {meta.label}
                            <span
                              className={`ml-1.5 rounded px-1 py-px text-[9px] font-bold uppercase ${
                                meta.stream === "T"
                                  ? "bg-cyan-500/15 text-cyan-400"
                                  : meta.stream === "L"
                                    ? "bg-rose-500/15 text-rose-400"
                                    : "bg-primary/15 text-primary"
                              }`}
                              title={meta.stream === "T" ? "Corriente técnica" : meta.stream === "L" ? "Corriente literatura" : "Común"}
                            >
                              {meta.stream}
                            </span>
                          </p>
                          <p className="mt-0.5 text-[11px] leading-snug text-muted-foreground">{meta.hint}</p>
                        </div>
                        <Switch
                          checked={modes.toggles[key]}
                          onCheckedChange={() => toggleMode(key)}
                          className="mt-0.5 shrink-0"
                          aria-label={meta.label}
                        />
                      </div>
                    );
                  })}
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-1 h-8 w-full gap-1.5 text-xs"
                    onClick={() => {
                      handleSaveCustom();
                    }}
                  >
                    <Save className="h-3.5 w-3.5" /> Guardar como mi preset Custom
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose} aria-label="Cerrar panel de modos" title="Cerrar panel">
              <PanelRightClose className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Selector de presets */}
        <div className="mt-2.5 grid grid-cols-3 gap-1.5" data-testid="mode-presets">
          {(Object.keys(MODE_PRESETS) as ModePresetId[]).map((id) => (
            <button
              key={id}
              onClick={() => applyPreset(id)}
              className={`flex items-center justify-center gap-1 rounded-md border px-2 py-1.5 text-xs transition-colors ${
                modes.preset === id
                  ? "border-primary bg-primary/15 font-medium text-primary"
                  : "border-border/70 text-muted-foreground hover:border-primary/40 hover:text-foreground"
              }`}
              aria-pressed={modes.preset === id}
            >
              {modes.preset === id && id !== "custom" && <Check className="h-3 w-3" />}
              {MODE_PRESETS[id].label}
            </button>
          ))}
        </div>
        <p className="mt-1.5 line-clamp-2 text-[11px] leading-snug text-muted-foreground" data-testid="mode-tagline">
          {modes.preset === "custom" && modes.customSaved
            ? "Tu configuración guardada."
            : MODE_PRESETS[modes.preset].tagline}
        </p>
      </div>

      {/* Pestañas de paneles activos */}
      {activeKeys.length === 0 ? (
        <div className="grid flex-1 place-content-center gap-2 p-8 text-center text-xs text-muted-foreground">
          <Layers3 className="mx-auto h-7 w-7 opacity-40" />
          <p className="font-medium">Ninguna subfeature activa.</p>
          <p>
            Abre las opciones (engranaje) y activa las que quieras, o elige el preset Técnico o
            Literatura.
          </p>
        </div>
      ) : (
        <TooltipProvider delayDuration={300}>
          <Tabs defaultValue={defaultTab} className="flex min-h-0 flex-1 flex-col gap-0">
            <div className="border-b border-border/60 px-2 pt-2">
              <TabsList className="h-8 w-full justify-start overflow-x-auto rounded-none bg-transparent p-0">
                {activeKeys.map((key) => {
                  const ui = TOGGLE_UI[key];
                  const Icon = ui.icon;
                  return (
                    <TabsTrigger
                      key={key}
                      value={key}
                      className="gap-1.5 rounded-t-md px-2.5 py-1.5 text-[11px] data-[state=active]:bg-card data-[state=active]:shadow-none"
                      title={MODE_TOGGLE_META[key].label}
                    >
                      <Icon className="h-3.5 w-3.5" />
                      {ui.tabLabel}
                    </TabsTrigger>
                  );
                })}
              </TabsList>
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4">
              {activeKeys.map((key) => (
                <TabsContent key={key} value={key} className="mt-0">
                  {key === "threePass" && <ThreePassPanel extras={extras} onPatch={onPatch} goToPage={goToPage} pageNum={pageNum} numPages={numPages} />}
                  {key === "notation" && <NotationPanel extras={extras} onPatch={onPatch} goToPage={goToPage} pageNum={pageNum} numPages={numPages} />}
                  {key === "codeRunner" && <CodeRunnerPanel extras={extras} onPatch={onPatch} goToPage={goToPage} pageNum={pageNum} numPages={numPages} />}
                  {key === "resultsTable" && <ResultsPanel extras={extras} onPatch={onPatch} goToPage={goToPage} pageNum={pageNum} numPages={numPages} />}
                  {key === "reproAudit" && <ReproPanel extras={extras} onPatch={onPatch} goToPage={goToPage} pageNum={pageNum} numPages={numPages} />}
                  {key === "xray" && <XrayPanel extras={extras} onPatch={onPatch} goToPage={goToPage} pageNum={pageNum} numPages={numPages} />}
                  {key === "naturalPauses" && <PausesPanel extras={extras} onPatch={onPatch} goToPage={goToPage} pageNum={pageNum} numPages={numPages} sessionSeconds={sessionSeconds} />}
                  {key === "argumentSkeleton" && <SkeletonPanel extras={extras} onPatch={onPatch} goToPage={goToPage} pageNum={pageNum} numPages={numPages} />}
                  {key === "lockedNotes" && <LockedNotesPanel extras={extras} onPatch={onPatch} goToPage={goToPage} pageNum={pageNum} numPages={numPages} />}
                  {key === "dualRead" && <DualPanel extras={extras} onPatch={onPatch} goToPage={goToPage} pageNum={pageNum} numPages={numPages} book={book} onBookChange={onBookChange} />}
                  {key === "outline" && <OutlinePanel doc={doc} goToPage={goToPage} currentPage={pageNum} />}
                </TabsContent>
              ))}
            </div>
          </Tabs>
        </TooltipProvider>
      )}
    </aside>
  );
}
