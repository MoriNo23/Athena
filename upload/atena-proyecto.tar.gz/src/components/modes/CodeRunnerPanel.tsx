"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Play, RotateCcw } from "lucide-react";
import { ModePanelProps } from "@/components/modes/panel-props";

/** Código que se ejecuta al lado: sandbox de JS aislado (iframe sin same-origin) */

const SAMPLE = `// Ejemplo: ajusta los parámetros y mira qué pasa
const paginasPorDia = 20;
const totalPaginas = 320;
const dias = Math.ceil(totalPaginas / paginasPorDia);
console.log("Terminarías en", dias, "días =",(dias/7).toFixed(1),"semanas");

for (let d = 1; d <= dias; d++) {
  console.log(\`día \${d}: pág. \${Math.min(d * paginasPorDia, totalPaginas)}\`);
}`;

interface RunOutput {
  lines: { kind: "log" | "error"; text: string }[];
  done: boolean;
}

export function CodeRunnerPanel({ extras, onPatch }: ModePanelProps) {
  const code = extras.codeSnippet?.code ?? SAMPLE;
  const [editorCode, setEditorCode] = useState(code);
  const [output, setOutput] = useState<RunOutput | null>(null);
  const [running, setRunning] = useState(false);
  const frameRef = useRef<HTMLIFrameElement | null>(null);
  const listenRef = useRef(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Guardar código con debounce en los extras del libro
  useEffect(() => {
    if (editorCode === code) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      onPatch({ codeSnippet: { code: editorCode } });
    }, 900);
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, [editorCode, code, onPatch]);

  useEffect(
    () => () => {
      listenRef.current = false;
    },
    []
  );

  const run = () => {
    setRunning(true);
    setOutput({ lines: [], done: false });
    listenRef.current = true;

    const html = `<!doctype html><html><head><meta charset="utf-8"></head><body><script>
const send=(type,args)=>parent.postMessage({__rielRunner:true,type,args: Array.isArray(args) ? args : [String(args)]},"*");
["log","info","warn"].forEach(k=>{const o=console[k].bind(console);console[k]=(...a)=>{send("log",a.map(x=>{try{return typeof x==="string"?x:JSON.stringify(x)}catch{return String(x)}}).join(" "));}});
console.error=(...a)=>{send("error",a.map(String).join(" "));};
window.onerror=(m,s,l)=>send("error",[m+(l?" (línea "+l+")":"")]);
try{
${editorCode}
}catch(e){send("error",[String(e)]);}
send("done",[]);
<\/script></body></html>`;

    // recarga el iframe con nuevo srcdoc para ejecutar
    const frame = frameRef.current;
    if (frame) frame.srcdoc = html;

    // failsafe: si no llega "done" en 4 s, corta
    setTimeout(() => {
      if (listenRef.current) {
        listenRef.current = false;
        setRunning(false);
        setOutput((o) => (o && !o.done ? { ...o, done: true, lines: [...o.lines, { kind: "error", text: "Tiempo agotado (¿bucle infinito?)" }] } : o));
      }
    }, 4000);
  };

  // Escucha los mensajes del sandbox
  useEffect(() => {
    const handler = (e: MessageEvent) => {
      const d = e.data as { __rielRunner?: boolean; type?: string; args?: unknown } | null;
      if (!d || !d.__rielRunner) return;
      if (!listenRef.current) return;
      const args = Array.isArray(d.args) ? d.args.map(String) : d.args != null ? [String(d.args)] : [];
      if (d.type === "done") {
        listenRef.current = false;
        setRunning(false);
        setOutput((o) => (o ? { ...o, done: true } : o));
      } else {
        setOutput((o) =>
          o ? { ...o, lines: [...o.lines, { kind: d.type === "error" ? "error" : "log", text: args.join(" ") }] } : o
        );
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  const lineCount = useMemo(() => output?.lines.length ?? 0, [output]);

  return (
    <div className="grid gap-3">
      <p className="text-xs leading-relaxed text-muted-foreground">
        Los ejemplos de libros técnicos corren aquí al margen, sin copiarlos a otra ventana. El
        código se ejecuta aislado, sin acceso a tus datos ni al resto de la app.
      </p>

      <Textarea
        value={editorCode}
        onChange={(e) => setEditorCode(e.target.value)}
        rows={9}
        spellCheck={false}
        aria-label="Editor de código JavaScript"
        className="resize-y font-mono text-xs leading-relaxed"
        data-testid="code-editor"
      />

      <div className="flex items-center gap-2">
        <Button size="sm" className="h-7 gap-1.5 text-xs" onClick={run} disabled={running}>
          <Play className="h-3 w-3" /> {running ? "Ejecutando…" : "Ejecutar"}
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 gap-1 text-xs text-muted-foreground"
          onClick={() => setEditorCode(SAMPLE)}
          title="Restaurar el ejemplo"
        >
          <RotateCcw className="h-3 w-3" /> Ejemplo
        </Button>
        <span className="ml-auto text-[11px] text-muted-foreground">JavaScript · sandbox</span>
      </div>

      {output && (
        <div
          className="max-h-44 overflow-y-auto rounded-lg border border-border/50 bg-black/40 p-2.5 font-mono text-[11px] leading-relaxed"
          data-testid="code-output"
          aria-live="polite"
        >
          {lineCount === 0 ? (
            <p className="text-muted-foreground">— sin salida todavía —</p>
          ) : (
            output.lines.map((l, i) => (
              <p key={i} className={`whitespace-pre-wrap break-words ${l.kind === "error" ? "text-red-400" : "text-emerald-300/90"}`}>
                {l.text}
              </p>
            ))
          )}
        </div>
      )}

      {/* iframe sandbox oculto donde corre el código */}
      <iframe
        ref={frameRef}
        title="Sandbox de código"
        sandbox="allow-scripts"
        className="hidden h-0 w-0"
      />
    </div>
  );
}
