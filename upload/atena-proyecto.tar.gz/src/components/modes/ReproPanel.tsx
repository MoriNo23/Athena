"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { CircleSlash2, CircleCheck, CircleAlert } from "lucide-react";
import { ModePanelProps } from "@/components/modes/panel-props";
import type { ReproState } from "@/lib/types";

/** Auditoría de reproducibilidad: qué falta para reproducir el experimento */

const ITEMS: { id: string; label: string }[] = [
  { id: "seed", label: "Semilla aleatoria declarada" },
  { id: "libs", label: "Versiones de librerías / entorno" },
  { id: "data", label: "Dataset y versión exacta" },
  { id: "split", label: "División train / val / test" },
  { id: "hyper", label: "Hiperparámetros (lr, batch, épocas…)" },
  { id: "hardware", label: "Hardware y tiempo de cómputo" },
  { id: "code", label: "Código disponible (repo)" },
  { id: "preprocess", label: "Preprocesamiento y filtrado de datos" },
];

const NEXT_STATE: Record<ReproState, ReproState> = { pendiente: "ok", ok: "na", na: "pendiente" };

export function ReproPanel({ extras, onPatch }: ModePanelProps) {
  const state = extras.repro ?? { states: {}, notes: "" };
  const [notes, setNotes] = useState(state.notes);

  const cycle = (id: string) => {
    const current = state.states[id] ?? "pendiente";
    onPatch({ repro: { ...state, states: { ...state.states, [id]: NEXT_STATE[current] } } });
  };

  const saveNotes = () => {
    if (notes !== state.notes) onPatch({ repro: { ...state, notes } });
  };

  const okCount = ITEMS.filter((i) => state.states[i.id] === "ok").length;
  const naCount = ITEMS.filter((i) => state.states[i.id] === "na").length;
  const relevant = ITEMS.length - naCount;
  const missing = relevant - okCount;

  return (
    <div className="grid gap-3">
      <div className="flex items-center justify-between">
        <p className="text-xs leading-relaxed text-muted-foreground">
          La app lee la lista, tú la revisas a mano: un falso «todo está especificado» es peor que no
          tener la lista.
        </p>
      </div>

      <div className="grid gap-1" role="group" aria-label="Ítems de reproducibilidad">
        {ITEMS.map((item) => {
          const s = state.states[item.id] ?? "pendiente";
          return (
            <button
              key={item.id}
              onClick={() => cycle(item.id)}
              className="flex items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs transition-colors hover:bg-card/60"
              data-testid={`repro-${item.id}`}
              data-state={s}
              title="Clic para cambiar: pendiente → ok → no aplica"
            >
              {s === "ok" ? (
                <CircleCheck className="h-4 w-4 shrink-0 text-emerald-400" />
              ) : s === "na" ? (
                <CircleSlash2 className="h-4 w-4 shrink-0 text-muted-foreground/60" />
              ) : (
                <CircleAlert className="h-4 w-4 shrink-0 text-amber-400/90" />
              )}
              <span className={s === "ok" ? "text-foreground" : s === "na" ? "text-muted-foreground/60 line-through" : "text-foreground/90"}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>

      <div className="flex items-center justify-between rounded-lg border border-border/50 bg-card/40 px-3 py-2 text-xs">
        <span className="text-muted-foreground">Especificado</span>
        <span className="tabular-nums font-medium text-primary" data-testid="repro-progress">
          {okCount}/{relevant}
          {naCount > 0 && <span className="ml-1 text-[10px] font-normal text-muted-foreground">({naCount} n/a)</span>}
        </span>
      </div>
      {missing > 0 && (
        <p className="text-[11px] leading-relaxed text-amber-400/90">
          {missing === 1 ? "Falta 1 pieza" : `Faltan ${missing} piezas`} para intentar reproducir el
          experimento tal como está escrito.
        </p>
      )}

      <div className="grid gap-1.5">
        <label htmlFor="repro-notes" className="text-xs font-medium text-muted-foreground">
          Notas (qué encontraste, dónde)
        </label>
        <Textarea
          id="repro-notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          onBlur={saveNotes}
          rows={3}
          placeholder="Ej.: la semilla está solo en el repo, no en el paper…"
          className="text-xs"
        />
      </div>
    </div>
  );
}
